import * as THREE from "three";
import { applyDamage, type KartState } from "../kart/Kart";
import type { PickupPoint } from "../physics/types";
import { BOX_TIERS, WEAPON_STYLE } from "@shared/catalog";
import type { WeaponId } from "@shared/protocol";
import { ASSET_FILES, cloneAsset, toGameSpace } from "../assets/AssetManager";
import { rollWeapon } from "@shared/sim/weapons";

interface Shot {
  live: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  life: number;
  owner: string;
  kind: WeaponId;
}

interface Orb {
  live: boolean;
  x: number;
  z: number;
  t: number;
  respawn: number;
}

export class WeaponSystem {
  private shots: Shot[] = [];
  private orbs: Orb[] = [];
  private shotMesh: THREE.InstancedMesh;
  private orbMesh: THREE.InstancedMesh;
  private dummy = new THREE.Object3D();
  private tmpColor = new THREE.Color();
  /** One loaded template per weapon kind; each shot slot makes its own clone the first time it needs a kind. */
  private templates = new Map<WeaponId, THREE.Object3D>();
  private slotModels: Map<WeaponId, THREE.Object3D>[] = Array.from({ length: 24 }, () => new Map<WeaponId, THREE.Object3D>());
  readonly group = new THREE.Group();

  constructor() {
    const shotGeo = new THREE.SphereGeometry(0.22, 6, 6);
    const shotMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.shotMesh = new THREE.InstancedMesh(shotGeo, shotMat, 24);
    const orbGeo = new THREE.OctahedronGeometry(0.55, 0);
    const orbMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.orbMesh = new THREE.InstancedMesh(orbGeo, orbMat, 16);
    this.shotMesh.frustumCulled = false;
    this.orbMesh.frustumCulled = false;
    this.group.add(this.shotMesh, this.orbMesh);
    this.loadModels();
    for (let i = 0; i < 24; i++) {
      this.shots.push({ live: false, x: 0, y: 0, z: 0, vx: 0, vz: 0, life: 0, owner: "", kind: "bomb" });
      this.shotMesh.setColorAt(i, new THREE.Color(WEAPON_STYLE.bomb.color));
    }
    for (let i = 0; i < 16; i++) {
      this.orbs.push({ live: false, x: 0, z: 0, t: 0, respawn: 0 });
      this.orbMesh.setColorAt(i, new THREE.Color(BOX_TIERS.common.color));
    }
  }

  private loadModels(): void {
    for (const [kind, file] of Object.entries(ASSET_FILES.weapons) as [WeaponId, string][]) {
      cloneAsset(file).then((model) => {
        if (!model) {
          console.error(`Weapon model failed to load: ${file}`);
          return;
        }
        this.templates.set(kind, toGameSpace(model));
      });
    }
  }

  reset(pickups: PickupPoint[]): void {
    this.shots.forEach((s) => (s.live = false));
    this.orbs.forEach((o) => (o.live = false));
    pickups.forEach((p, i) => {
      const orb = this.orbs[i];
      if (!orb) return;
      orb.live = true;
      orb.x = p.x;
      orb.z = p.z;
      orb.t = i * 0.4;
    });
  }

  fire(kart: KartState): void {
    if (!kart.wantFire) return;
    const shot = this.shots.find((s) => !s.live);
    if (!shot) return;
    kart.ammo -= 1;
    kart.cooldown = 0.55;
    kart.wantFire = false;
    const fx = Math.sin(kart.yaw);
    const fz = Math.cos(kart.yaw);
    shot.live = true;
    shot.owner = kart.id;
    shot.kind = kart.weapon ?? "bomb";
    shot.x = kart.x + fx * 1.6;
    shot.y = kart.y + 0.4;
    shot.z = kart.z + fz * 1.6;
    shot.vx = fx * 34;
    shot.vz = fz * 34;
    shot.life = 1.15;
  }

  update(karts: KartState[], dt: number): void {
    for (const kart of karts) {
      if (kart.wantFire) this.fire(kart);
      if (!kart.alive || kart.ammo > 0) continue;
      for (const orb of this.orbs) {
        if (!orb.live) continue;
        if (Math.hypot(orb.x - kart.x, orb.z - kart.z) < 1.6) {
          orb.live = false;
          orb.respawn = 6.5;
          kart.ammo = 3;
          kart.weapon = rollWeapon(false, Math.random).id;
        }
      }
    }

    for (const shot of this.shots) {
      if (!shot.live) continue;
      shot.life -= dt;
      shot.x += shot.vx * dt;
      shot.z += shot.vz * dt;
      if (shot.life <= 0) {
        shot.live = false;
        continue;
      }
      for (const kart of karts) {
        if (!kart.alive || kart.id === shot.owner) continue;
        if (Math.hypot(kart.x - shot.x, kart.z - shot.z) < 1.15) {
          applyDamage(kart, 22);
          const owner = karts.find((k) => k.id === shot.owner);
          if (owner) {
            owner.damageDealt += 22;
            if (!kart.alive) owner.elims += 1;
          }
          kart.kbX += Math.sign(shot.vx) * 10;
          kart.kbZ += Math.sign(shot.vz) * 10;
          shot.live = false;
          break;
        }
      }
    }

    const dummy = this.dummy;
    this.shots.forEach((s, i) => {
      const slot = this.slotModels[i]!;
      const kind = s.live ? s.kind : null;
      for (const [k, obj] of slot) obj.visible = k === kind;
      if (kind && this.templates.has(kind)) {
        let obj = slot.get(kind);
        if (!obj) {
          obj = this.templates.get(kind)!.clone(true);
          obj.scale.setScalar(0.5);
          this.group.add(obj);
          slot.set(kind, obj);
        }
        obj.visible = true;
        obj.position.set(s.x, s.y, s.z);
        obj.rotation.y = Math.atan2(s.vx, s.vz);
      }
      if (true) dummy.scale.set(0, 0, 0);
      else {
        const style = WEAPON_STYLE[s.kind];
        dummy.scale.setScalar(style.size / 0.22);
        dummy.position.set(s.x, s.y, s.z);
        this.shotMesh.setColorAt(i, this.tmpColor.set(style.color));
      }
      dummy.updateMatrix();
      this.shotMesh.setMatrixAt(i, dummy.matrix);
    });
    this.orbs.forEach((o, i) => {
      o.t += dt;
      if (!o.live) dummy.scale.set(0, 0, 0);
      else {
        dummy.scale.set(1, 1, 1);
        dummy.position.set(o.x, 1.1 + Math.sin(o.t * 3) * 0.25, o.z);
        dummy.rotation.y = o.t;
      }
      dummy.updateMatrix();
      this.orbMesh.setMatrixAt(i, dummy.matrix);
    });
    this.shotMesh.instanceMatrix.needsUpdate = true;
    if (this.shotMesh.instanceColor) this.shotMesh.instanceColor.needsUpdate = true;
    this.orbMesh.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.shotMesh.geometry.dispose();
    this.orbMesh.geometry.dispose();
    (this.shotMesh.material as THREE.Material).dispose();
    (this.orbMesh.material as THREE.Material).dispose();
  }
}

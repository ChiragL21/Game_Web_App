import * as THREE from "three";
import { lambert, paint } from "../engine/materials";
import type { PickupPoint } from "../physics/types";

export class PickupCubes {
  readonly group = new THREE.Group();
  private cubes: THREE.Group[] = [];

  load(points: PickupPoint[]): void {
    this.clear();
    points.forEach((p) => {
      const cube = lootCube();
      cube.position.set(p.x, 1.05, p.z);
      this.cubes.push(cube);
      this.group.add(cube);
    });
  }

  update(t: number): void {
    this.cubes.forEach((c, i) => {
      c.rotation.y = t * 1.15 + i;
      c.position.y = 1.05 + Math.sin(t * 2.8 + i) * 0.2;
    });
  }

  clear(): void {
    this.cubes.forEach((c) => {
      c.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
      this.group.remove(c);
    });
    this.cubes = [];
  }
}

function lootCube(): THREE.Group {
  const g = new THREE.Group();
  const bodyGeo = new THREE.BoxGeometry(1.05, 1.05, 1.05);
  paint(bodyGeo, 0xff6a3d, 0.03);
  const body = new THREE.Mesh(bodyGeo, lambert);
  g.add(body);
  const faceGeo = new THREE.PlaneGeometry(0.72, 0.72);
  paint(faceGeo, 0xfff4cc, 0.01);
  for (const rot of [0, Math.PI / 2, Math.PI, -Math.PI / 2]) {
    const face = new THREE.Mesh(faceGeo, lambert);
    face.position.set(Math.sin(rot) * 0.53, 0, Math.cos(rot) * 0.53);
    face.rotation.y = rot;
    g.add(face);
    const q = question();
    q.position.copy(face.position).multiplyScalar(1.02);
    q.rotation.y = rot;
    g.add(q);
  }
  return g;
}

function question(): THREE.Group {
  const q = new THREE.Group();
  const matCol = 0x2563eb;
  const stem = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.28, 3, 8), lambert);
  paint(stem.geometry, matCol, 0);
  stem.position.y = 0.06;
  const hook = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.05, 6, 10, Math.PI * 1.4), lambert);
  paint(hook.geometry, matCol, 0);
  hook.position.set(0, 0.22, 0);
  hook.rotation.z = 0.4;
  const dot = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), lambert);
  paint(dot.geometry, matCol, 0);
  dot.position.y = -0.22;
  q.add(stem, hook, dot);
  return q;
}

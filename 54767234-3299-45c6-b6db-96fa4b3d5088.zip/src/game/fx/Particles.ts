import * as THREE from "three";

interface Particle {
  live: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
}

export class ParticlePool {
  readonly mesh: THREE.InstancedMesh;
  private items: Particle[] = [];
  private dummy = new THREE.Object3D();
  private budget: number;

  constructor(budget = 40) {
    this.budget = budget;
    const geo = new THREE.BoxGeometry(0.16, 0.16, 0.16);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffd29d });
    this.mesh = new THREE.InstancedMesh(geo, mat, budget);
    this.mesh.frustumCulled = false;
    for (let i = 0; i < budget; i++) this.items.push({ live: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, max: 1 });
  }

  setBudget(n: number): void {
    this.budget = Math.min(this.items.length, n);
  }

  burst(x: number, y: number, z: number, color = 0xffd29d, count = 8): void {
    (this.mesh.material as THREE.MeshBasicMaterial).color.setHex(color);
    let spawned = 0;
    for (const p of this.items) {
      if (p.live || spawned >= count) continue;
      p.live = true;
      p.x = x;
      p.y = y;
      p.z = z;
      p.vx = (Math.random() - 0.5) * 8;
      p.vy = Math.random() * 6 + 1;
      p.vz = (Math.random() - 0.5) * 8;
      p.life = 0.35 + Math.random() * 0.3;
      p.max = p.life;
      spawned += 1;
    }
  }

  trail(x: number, y: number, z: number): void {
    const p = this.items.find((i) => !i.live);
    if (!p) return;
    p.live = true;
    p.x = x;
    p.y = y;
    p.z = z;
    p.vx = 0;
    p.vy = 0.4;
    p.vz = 0;
    p.life = 0.22;
    p.max = 0.22;
  }

  update(dt: number): void {
    const dummy = this.dummy;
    this.items.forEach((p, i) => {
      if (!p.live || i >= this.budget) {
        dummy.scale.set(0, 0, 0);
        dummy.position.set(0, -10, 0);
      } else {
        p.life -= dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.z += p.vz * dt;
        p.vy -= 12 * dt;
        if (p.life <= 0) p.live = false;
        const s = Math.max(0, p.life / p.max);
        dummy.scale.setScalar(s);
        dummy.position.set(p.x, p.y, p.z);
      }
      dummy.updateMatrix();
      this.mesh.setMatrixAt(i, dummy.matrix);
    });
    this.mesh.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
  }
}

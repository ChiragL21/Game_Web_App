import * as THREE from "three";
import { ArenaBuilder, type Theme } from "./builder";

const tropical: Theme = { fog: 0xc8f4ff, sky: 0x8ed0ff, groundA: 0x86f04a, groundB: 0x4fdc36, accent: 0xff8a3d, trim: 0xff4d8d, wall: 0xff9f43 };
const neon: Theme = { fog: 0xd7e6f5, sky: 0x9ed0ff, groundA: 0x9aa3ad, groundB: 0xc5ccd3, accent: 0xff4d9a, trim: 0x22d3ee, wall: 0x3b82f6 };
const desert: Theme = { fog: 0xffe08a, sky: 0x7ec8ff, groundA: 0xffc14d, groundB: 0xff9a32, accent: 0xff5a1f, trim: 0xfacc15, wall: 0xf97316 };
const frozen: Theme = { fog: 0xe0f2fe, sky: 0x93c5fd, groundA: 0xf0f9ff, groundB: 0x7dd3fc, accent: 0x38bdf8, trim: 0xffffff, wall: 0x60a5fa };
const industrial: Theme = { fog: 0x93c5fd, sky: 0x7dd3fc, groundA: 0x94a3b8, groundB: 0xcbd5e1, accent: 0xfacc15, trim: 0x3b82f6, wall: 0x2563eb };
const toyland: Theme = { fog: 0xfbcfe8, sky: 0xb8e0ff, groundA: 0x7cff4a, groundB: 0x46d832, accent: 0xf472b6, trim: 0xfacc15, wall: 0xfb7185 };

export function buildTropicalIsland(): ArenaBuilder {
  const b = new ArenaBuilder("tropical-island", "Splash Park", tropical).setBounds(80).ground(80);
  b.pool(4, 2, 36, 24, 0x2eb8e6);
  b.island(6, 4, 8.2, 0xf6d36a);
  b.ribbon(new THREE.Vector3(-10, 7.2, 10), new THREE.Vector3(2, 4.4, 6), new THREE.Vector3(12, 1.1, 0), 0xff4d6d, 3.2);
  b.ribbon(new THREE.Vector3(-8, 7.0, 14), new THREE.Vector3(6, 3.6, 10), new THREE.Vector3(16, 1.0, 4), 0xff6b81, 2.6);
  b.box(-12, 3.6, 12, 6.5, 7.2, 6.5, 0xf4d35e);
  b.curb(-18, -8, 22, 0.15, 0xff8a3d);
  b.curb(22, 8, 18, -0.4, 0xff8a3d);
  b.curb(-6, 22, 20, 0.05, 0xff8a3d);
  b.curb(16, -16, 16, 0.6, 0xff8a3d);
  b.ramp(-22, -20, 7, 11, 2.2, 0.3, 0xf59e0b);
  [
    [-22, -26], [-8, 28], [26, -18], [30, 14], [-30, 18], [10, -32], [-26, 26], [20, 30], [14, -26], [-32, -6], [2, 16], [12, 8],
  ].forEach(([x, z]) => b.palm(x, z));
  b.palm(4, 6);
  b.palm(9, 2);
  b.ringWalls(0.2, 1.8);
  placeLoop(b, 28);
  b.spawn(-14, -20, 0.45).spawn(-28, 18, 2.2).spawn(26, -22, -0.5).spawn(24, 26, 3.5)
    .spawn(0, -32, 0).spawn(0, 32, Math.PI).spawn(-32, 0, Math.PI / 2).spawn(32, 0, -Math.PI / 2);
  b.pickup(-16, 4).pickup(18, 8).pickup(2, -18).pickup(10, 16).pickup(-10, 16).pickup(16, -12);
  return b;
}

export function buildNeonCity(): ArenaBuilder {
  const b = new ArenaBuilder("neon-city", "Color Circuit", neon).setBounds(80).ground(80);
  b.stripes(0, 10, 16, 9, 0);
  b.stripes(0, -8, 16, 9, 0);
  b.blocks(8, 4, 6, 0, 0xef4444);
  b.blocks(-10, -2, 5, Math.PI / 2, 0x22c55e);
  b.curb(-16, 12, 14, 0.2, 0xff8a3d);
  b.curb(18, -10, 16, -0.3, 0x60a5fa);
  b.hill(-28, -8, 8, 0xf9a8d4);
  b.hill(30, 12, 9, 0xc4b5fd);
  b.hill(22, -26, 7, 0x86efac);
  b.roundedWall(-6, 0, 12, Math.PI / 2, 1.6, 1.3, 0x2563eb);
  b.roundedWall(6, 0, 12, Math.PI / 2, 1.6, 1.3, 0x22c55e);
  b.ringWalls(0.25, 1.8);
  placeGrid(b);
  b.spawn(-8, -22, 0.15).spawn(24, -24, 2.2).spawn(-24, 24, -0.5).spawn(24, 24, 3.4)
    .spawn(0, -32, 0).spawn(0, 32, Math.PI);
  b.pickup(-12, -8).pickup(12, 10).pickup(-10, 12).pickup(14, -12).pickup(0, 16).pickup(0, -16);
  return b;
}

export function buildDesertCanyon(): ArenaBuilder {
  const b = new ArenaBuilder("desert-canyon", "Desert Canyon", desert).setBounds(80).ground(80);
  b.zone("sand", -12, 12, -12, 12, 0xeab308);
  b.sphere(0, 3.2, 0, 5.5, 0xd97706);
  b.ramp(-18, 0, 8, 16, 6, Math.PI / 2, 0xf59e0b);
  b.ramp(18, 0, 8, 16, 6, -Math.PI / 2, 0xf59e0b);
  b.curb(-10, -28, 30, 0, 0xf97316);
  b.curb(10, 28, 30, 0, 0xf97316);
  b.ringWalls(0.3, 2.4);
  placeLoop(b, 32);
  b.spawn(-20, -24, 0.6).spawn(24, 24, 3.9).spawn(-24, 24, 2.3).spawn(24, -24, -0.5)
    .spawn(-20, 0, Math.PI / 2).spawn(20, 0, -Math.PI / 2);
  b.pickup(-30, 0).pickup(30, 0).pickup(0, -36).pickup(0, 36).pickup(-22, 22).pickup(22, -22);
  return b;
}

export function buildFrozenArena(): ArenaBuilder {
  const b = new ArenaBuilder("frozen-arena", "Frozen Arena", frozen).setBounds(80).ground(80);
  b.zone("ice", -22, 22, -22, 22, 0xbae6fd);
  b.sphere(0, 2.2, 0, 3.6, 0xe0f2fe);
  b.ramp(-26, -8, 7, 14, 3.5, 0.5, 0xf8fafc);
  b.ramp(26, 8, 7, 14, 3.5, 3.6, 0xf8fafc);
  b.curb(-30, 20, 10, 0.2, 0x7dd3fc);
  b.curb(28, -22, 10, 0.2, 0x38bdf8);
  b.ringWalls(0.2, 2.4);
  placeLoop(b, 30);
  b.spawn(-20, -24, 0.5).spawn(24, 24, 3.8).spawn(-24, 24, 2.4).spawn(24, -24, -0.6)
    .spawn(0, -32, 0).spawn(0, 32, Math.PI);
  b.pickup(-16, 0).pickup(16, 0).pickup(0, -16).pickup(0, 16).pickup(24, 24).pickup(-24, -24);
  return b;
}

export function buildIndustrialZone(): ArenaBuilder {
  const b = new ArenaBuilder("industrial-zone", "Industrial Zone", industrial).setBounds(80).ground(80);
  b.zone("boost", 16, 22, -28, 28, 0xfacc15);
  b.zone("boost", -22, -16, -28, 28, 0xfacc15);
  for (let i = 0; i < 6; i++) {
    const z = -24 + i * 9;
    b.curb(-8, z, 6, 0, i % 2 ? 0xef4444 : 0x2563eb);
    b.curb(8, z + 4, 6, 0, i % 2 ? 0xfacc15 : 0x22c55e);
  }
  b.sphere(0, 2.4, 0, 3.2, 0x64748b);
  b.ramp(0, -18, 6, 12, 4, 0, 0xfacc15);
  b.ringWalls(0.2, 2.4);
  placeGrid(b);
  b.spawn(-20, -24, 0.6).spawn(24, -24, 2.4).spawn(-24, 24, -0.7).spawn(24, 24, 3.6)
    .spawn(0, -32, 0).spawn(19, 0, Math.PI);
  b.pickup(-19, 0).pickup(19, 12).pickup(0, 20).pickup(-12, -20).pickup(12, -8).pickup(0, -28);
  return b;
}

export function buildToyland(): ArenaBuilder {
  const b = new ArenaBuilder("toyland", "Toyland", toyland).setBounds(80).ground(80);
  b.stripes(4, 0, 18, 10, 0);
  b.hill(-22, -16, 9, 0xf9a8d4);
  b.hill(24, -12, 8, 0xa78bfa);
  b.hill(-18, 20, 7, 0x86efac);
  b.hill(20, 18, 8, 0xfde68a);
  b.blocks(6, 8, 7, 0, 0xfb7185);
  b.curb(-8, 4, 14, 0.4, 0xff8a3d);
  b.sphere(0, 2.2, -6, 3.2, 0x60a5fa);
  b.ramp(-28, 0, 8, 16, 4.5, Math.PI / 2, 0xa78bfa);
  b.ringWalls(0.2, 1.8);
  placeLoop(b, 26);
  b.spawn(-10, -20, 0.2).spawn(24, 24, 3.9).spawn(-24, 24, 2.2).spawn(24, -24, -0.5)
    .spawn(0, -32, 0).spawn(0, 32, Math.PI);
  b.pickup(-18, 8).pickup(16, -8).pickup(0, 18).pickup(0, -18).pickup(10, 4).pickup(-10, 0);
  return b;
}

function placeLoop(b: ArenaBuilder, radius: number): void {
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    b.waypoint(Math.sin(a) * radius, Math.cos(a) * radius);
  }
}

function placeGrid(b: ArenaBuilder): void {
  const pts = [-30, -15, 0, 15, 30];
  for (const x of pts) for (const z of pts) b.waypoint(x, z);
}

export const ARENA_FACTORIES: Record<string, () => ArenaBuilder> = {
  "tropical-island": buildTropicalIsland,
  "neon-city": buildNeonCity,
  "desert-canyon": buildDesertCanyon,
  "frozen-arena": buildFrozenArena,
  "industrial-zone": buildIndustrialZone,
  toyland: buildToyland,
};

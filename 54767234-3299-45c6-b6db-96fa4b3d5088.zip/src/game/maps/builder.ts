import * as THREE from "three";
import { lambert, lambertAlpha, paint, toon } from "../engine/materials";
import type { Collider, ColliderKind, PickupPoint, RampCollider, SpawnPoint, Waypoint, Zone } from "../physics/types";

export interface Theme {
  fog: number;
  sky: number;
  groundA: number;
  groundB: number;
  accent: number;
  trim: number;
  wall: number;
}

export class ArenaBuilder {
  readonly group = new THREE.Group();
  readonly colliders: Collider[] = [];
  readonly ramps: RampCollider[] = [];
  readonly zones: Zone[] = [];
  readonly spawns: SpawnPoint[] = [];
  readonly pickups: PickupPoint[] = [];
  readonly waypoints: Waypoint[] = [];
  readonly instanced: THREE.InstancedMesh[] = [];
  bounds = { minX: -40, maxX: 40, minZ: -40, maxZ: 40 };

  constructor(readonly id: string, readonly name: string, readonly theme: Theme) {
    this.group.name = id;
  }

  setBounds(size = 80): this {
    const h = size / 2;
    this.bounds = { minX: -h, maxX: h, minZ: -h, maxZ: h };
    return this;
  }

  ground(size = 80, checker = true): this {
    const segs = checker ? 16 : 24;
    const plane = new THREE.PlaneGeometry(size, size, segs, segs);
    plane.rotateX(-Math.PI / 2);
    const geo = checker ? plane.toNonIndexed() : plane;
    if (checker) checkerPaint(geo, this.theme.groundA, this.theme.groundB, size / segs);
    else colorGround(geo, this.theme.groundA, this.theme.groundB);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.receiveShadow = false;
    this.group.add(mesh);
    return this;
  }

  fogPlane(size: number, y: number, color: number, opacity = 0.55): this {
    const geo = new THREE.PlaneGeometry(size, size);
    geo.rotateX(-Math.PI / 2);
    paint(geo, color);
    const mat = lambertAlpha.clone();
    mat.opacity = opacity;
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = y;
    this.group.add(mesh);
    return this;
  }

  box(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    color: number,
    opts?: { yaw?: number; collider?: boolean; kind?: ColliderKind },
  ): this {
    const yaw = opts?.yaw ?? 0;
    const mesh = makeBox(w, h, d, color);
    mesh.position.set(x, y, z);
    mesh.rotation.y = yaw;
    this.group.add(mesh);
    if (opts?.collider !== false) {
      this.colliders.push({
        type: "obb",
        cx: x,
        cy: y,
        cz: z,
        halfW: w / 2,
        halfH: h / 2,
        halfD: d / 2,
        yaw,
        kind: opts?.kind ?? "solid",
      });
    }
    return this;
  }

  wall(x: number, z: number, length: number, yaw: number, height = 2.2, thickness = 0.9, color?: number): this {
    return this.roundedWall(x, z, length, yaw, height, thickness, color ?? this.theme.wall);
  }

  roundedWall(x: number, z: number, length: number, yaw: number, height = 2.2, thickness = 0.95, color?: number): this {
    const col = color ?? this.theme.wall;
    const r = Math.max(0.45, thickness * 0.55);
    const cyl = Math.max(0.4, length - r * 2);
    const geo = new THREE.CapsuleGeometry(r, cyl, 5, 12);
    paint(geo, col, 0.03);
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.rotation.z = Math.PI / 2;
    mesh.rotation.y = yaw;
    mesh.position.set(x, r * 0.95, z);
    if (height > r * 2.2) mesh.scale.y = height / (r * 2);
    this.group.add(mesh);
    this.colliders.push({
      type: "obb",
      cx: x,
      cy: Math.max(r, height / 2),
      cz: z,
      halfW: Math.max(r, thickness / 2),
      halfH: Math.max(r, height / 2),
      halfD: length / 2,
      yaw,
      kind: "wall",
    });
    return this;
  }

  ringWalls(inset = 0.4, height = 2.4): this {
    const { minX, maxX, minZ, maxZ } = this.bounds;
    const w = maxX - minX;
    const d = maxZ - minZ;
    this.wall(0, minZ + inset, w, 0, height);
    this.wall(0, maxZ - inset, w, 0, height);
    this.wall(minX + inset, 0, d, Math.PI / 2, height);
    this.wall(maxX - inset, 0, d, Math.PI / 2, height);
    return this;
  }

  ramp(x: number, z: number, width: number, length: number, height: number, yaw = 0, color?: number): this {
    const geo = new THREE.BoxGeometry(width, 0.4, length, 1, 1, 4);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const lz = pos.getZ(i);
      const t = (lz + length / 2) / length;
      pos.setY(i, pos.getY(i) + t * height);
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    paint(geo, color ?? this.theme.trim);
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.position.set(x, 0.05, z);
    mesh.rotation.y = yaw;
    this.group.add(mesh);
    this.ramps.push({ type: "ramp", cx: x, cz: z, halfW: width / 2, halfD: length / 2, yaw, height });
    return this;
  }

  zone(kind: Zone["kind"], minX: number, maxX: number, minZ: number, maxZ: number, color?: number): this {
    this.zones.push({ kind, minX, maxX, minZ, maxZ });
    const w = maxX - minX;
    const d = maxZ - minZ;
    const geo = new THREE.PlaneGeometry(w, d);
    geo.rotateX(-Math.PI / 2);
    paint(geo, color ?? (kind === "ice" ? 0xbae6fd : kind === "boost" ? 0xfacc15 : kind === "water" ? 0x22a6e6 : 0xd6a15c));
    const mesh = new THREE.Mesh(geo, kind === "water" ? lambertAlpha : lambert);
    mesh.position.set((minX + maxX) / 2, 0.06, (minZ + maxZ) / 2);
    this.group.add(mesh);
    return this;
  }

  pool(cx: number, cz: number, w: number, d: number, color = 0x2eb8e6): this {
    this.zone("water", cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2, color);
    const rim = 0.7;
    this.roundedWall(cx, cz - d / 2, w, 0, 0.9, rim, 0xf4d35e);
    this.roundedWall(cx, cz + d / 2, w, 0, 0.9, rim, 0xf4d35e);
    this.roundedWall(cx - w / 2, cz, d, Math.PI / 2, 0.9, rim, 0xf4d35e);
    this.roundedWall(cx + w / 2, cz, d, Math.PI / 2, 0.9, rim, 0xf4d35e);
    return this;
  }

  slide(from: THREE.Vector3, mid: THREE.Vector3, to: THREE.Vector3, color = 0xff5b7a, radius = 1.15): this {
    const curve = new THREE.CatmullRomCurve3([from, mid, to]);
    const geo = new THREE.TubeGeometry(curve, 28, radius, 10, false);
    paint(geo, color, 0.02);
    const mesh = new THREE.Mesh(geo, lambert);
    this.group.add(mesh);
    return this;
  }

  ribbon(from: THREE.Vector3, mid: THREE.Vector3, to: THREE.Vector3, color = 0xff4d6d, width = 2.4): this {
    const curve = new THREE.CatmullRomCurve3([from, mid, to]);
    const pts = curve.getPoints(14);
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i]!;
      const b = pts[i + 1]!;
      const dir = b.clone().sub(a);
      const len = Math.max(0.2, dir.length());
      const geo = new THREE.CapsuleGeometry(0.22, len, 3, 8);
      paint(geo, color, 0.02);
      const mesh = new THREE.Mesh(geo, lambert);
      mesh.position.copy(a).lerp(b, 0.5);
      mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
      mesh.scale.set(width, 1, 0.55);
      this.group.add(mesh);
    }
    return this;
  }

  island(cx: number, cz: number, r = 7.5, color = 0xf4d35e): this {
    const deck = new THREE.CylinderGeometry(r, r * 1.05, 0.55, 20);
    paint(deck, color, 0.03);
    const mesh = new THREE.Mesh(deck, lambert);
    mesh.position.set(cx, 0.28, cz);
    this.group.add(mesh);
    this.sphere(cx + r * 0.2, 0.7, cz - r * 0.1, r * 0.35, 0xffe08a);
    this.colliders.push({ type: "circle", x: cx, z: cz, r: r * 0.55, minY: 0, maxY: 1.2, kind: "solid" });
    return this;
  }

  curb(x: number, z: number, length: number, yaw: number, color = 0xff8a3d): this {
    return this.roundedWall(x, z, length, yaw, 1.35, 1.35, color);
  }

  hill(x: number, z: number, r: number, color: number): this {
    const geo = new THREE.SphereGeometry(r, 14, 10);
    paint(geo, color, 0.03);
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.position.set(x, r * 0.22, z);
    mesh.scale.y = 0.45;
    this.group.add(mesh);
    return this;
  }

  blocks(x: number, z: number, count: number, yaw: number, color: number): this {
    for (let i = 0; i < count; i++) {
      const along = (i - (count - 1) / 2) * 1.7;
      const px = x + Math.sin(yaw) * along;
      const pz = z + Math.cos(yaw) * along;
      this.box(px, 0.7, pz, 1.55, 1.4, 1.55, color, { yaw, kind: "solid" });
    }
    return this;
  }

  palm(x: number, z: number): this {
    const trunk = new THREE.CapsuleGeometry(0.22, 2.4, 4, 8);
    paint(trunk, 0xb45309, 0.04);
    const t = new THREE.Mesh(trunk, lambert);
    t.position.set(x, 1.5, z);
    this.group.add(t);
    const leafCol = [0x22c55e, 0x16a34a, 0x4ade80, 0x86efac];
    const offsets = [
      [0, 3.35, 0, 0.95],
      [0.7, 3.15, 0.2, 0.7],
      [-0.65, 3.2, 0.15, 0.7],
      [0.15, 3.2, 0.7, 0.68],
      [0.1, 3.25, -0.7, 0.68],
      [0.45, 3.7, -0.35, 0.55],
      [-0.4, 3.65, 0.4, 0.55],
    ];
    offsets.forEach(([ox, oy, oz, r], i) => {
      const leaf = new THREE.SphereGeometry(r, 10, 8);
      paint(leaf, leafCol[i % leafCol.length], 0.04);
      const m = new THREE.Mesh(leaf, lambert);
      m.position.set(x + ox, oy, z + oz);
      this.group.add(m);
    });
    this.colliders.push({ type: "circle", x, z, r: 0.45, minY: 0, maxY: 3.4, kind: "solid" });
    return this;
  }

  stripes(cx: number, cz: number, w: number, d: number, yaw = 0): this {
    const geo = new THREE.PlaneGeometry(w, d);
    geo.rotateX(-Math.PI / 2);
    paint(geo, 0xf8fafc, 0.01);
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.position.set(cx, 0.08, cz);
    mesh.rotation.y = yaw;
    this.group.add(mesh);
    return this;
  }

  spawn(x: number, z: number, yaw = 0, y = 0): this {
    this.spawns.push({ x, y, z, yaw });
    return this;
  }

  pickup(x: number, z: number): this {
    this.pickups.push({ x, z });
    return this;
  }

  waypoint(x: number, z: number): this {
    this.waypoints.push({ x, z });
    return this;
  }

  cylinder(x: number, y: number, z: number, r: number, h: number, color: number, collider = true): this {
    const geo = new THREE.CylinderGeometry(r, r, h, 12);
    paint(geo, color);
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.position.set(x, y, z);
    this.group.add(mesh);
    if (collider) {
      this.colliders.push({ type: "circle", x, z, r, minY: y - h / 2, maxY: y + h / 2, kind: "solid" });
    }
    return this;
  }

  sphere(x: number, y: number, z: number, r: number, color: number): this {
    const geo = new THREE.SphereGeometry(r, 12, 10);
    paint(geo, color);
    const mesh = new THREE.Mesh(geo, lambert);
    mesh.position.set(x, y, z);
    this.group.add(mesh);
    return this;
  }

  scatter(count: number, make: (i: number, x: number, z: number) => void): this {
    for (let i = 0; i < count; i++) {
      const x = (Math.sin(i * 12.9898 + count) * 43758.5453) % 1;
      const z = (Math.sin(i * 78.233 + count) * 24634.6345) % 1;
      const px = (Math.abs(x) * 2 - 1) * (this.bounds.maxX - 8);
      const pz = (Math.abs(z) * 2 - 1) * (this.bounds.maxZ - 8);
      make(i, px, pz);
    }
    return this;
  }

  instanceCones(positions: { x: number; z: number }[], color: number, r = 0.55, h = 1.6): this {
    const geo = new THREE.SphereGeometry(r, 10, 8);
    paint(geo, color);
    const mesh = new THREE.InstancedMesh(geo, lambert, positions.length);
    const dummy = new THREE.Object3D();
    positions.forEach((p, i) => {
      dummy.position.set(p.x, r * 0.85, p.z);
      dummy.scale.set(1, h / (r * 2), 1);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      this.colliders.push({ type: "circle", x: p.x, z: p.z, r: r * 0.8, minY: 0, maxY: h, kind: "solid" });
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.frustumCulled = false;
    this.group.add(mesh);
    this.instanced.push(mesh);
    return this;
  }

  skyTint(): this {
    return this;
  }
}

function makeBox(w: number, h: number, d: number, color: number): THREE.Mesh {
  const geo = new THREE.BoxGeometry(w, h, d);
  paint(geo, color, 0.035);
  return new THREE.Mesh(geo, lambert);
}

function checkerPaint(geo: THREE.BufferGeometry, a: number, b: number, cell: number): void {
  const ca = new THREE.Color(a);
  const cb = new THREE.Color(b);
  const pos = geo.attributes.position;
  const arr = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i += 3) {
    const cx = (pos.getX(i) + pos.getX(i + 1) + pos.getX(i + 2)) / 3;
    const cz = (pos.getZ(i) + pos.getZ(i + 1) + pos.getZ(i + 2)) / 3;
    const gx = Math.floor((cx + 200) / cell);
    const gz = Math.floor((cz + 200) / cell);
    const c = (gx + gz) % 2 === 0 ? ca : cb;
    for (let k = 0; k < 3; k++) {
      const idx = (i + k) * 3;
      arr[idx] = c.r;
      arr[idx + 1] = c.g;
      arr[idx + 2] = c.b;
    }
  }
  geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
}

function colorGround(geo: THREE.BufferGeometry, a: number, b: number): void {
  const ca = new THREE.Color(a);
  const cb = new THREE.Color(b);
  const pos = geo.attributes.position;
  const arr = new Float32Array(pos.count * 3);
  const mix = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const t = 0.5 + 0.5 * Math.sin(x * 0.11) * Math.cos(z * 0.09);
    mix.copy(ca).lerp(cb, t);
    arr[i * 3] = mix.r;
    arr[i * 3 + 1] = mix.g;
    arr[i * 3 + 2] = mix.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
}

export function disposeGroup(group: THREE.Object3D): void {
  group.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = mesh.material;
    if (Array.isArray(mat)) mat.forEach((m) => m !== lambert && m !== lambertAlpha && m !== toon && m.dispose());
    else if (mat && mat !== lambert && mat !== lambertAlpha && mat !== toon) mat.dispose();
  });
}

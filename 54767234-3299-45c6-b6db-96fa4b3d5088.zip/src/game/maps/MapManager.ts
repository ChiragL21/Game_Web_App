import * as THREE from "three";
import { ARENA_FACTORIES } from "./arenas";
import { disposeGroup, type ArenaBuilder } from "./builder";
import { ASSET_FILES, cloneAsset, toGameSpace } from "../assets/AssetManager";
import type { Collider, PickupPoint, RampCollider, SpawnPoint, Waypoint, Zone } from "../physics/types";

export interface LoadedMap {
  id: string;
  name: string;
  group: THREE.Group;
  colliders: Collider[];
  ramps: RampCollider[];
  zones: Zone[];
  spawns: SpawnPoint[];
  pickups: PickupPoint[];
  waypoints: Waypoint[];
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  fog: number;
  sky: number;
}

export class MapManager {
  current: LoadedMap | null = null;
  private visual: THREE.Object3D | null = null;

  load(id: string, scene: THREE.Scene): LoadedMap {
    this.unload(scene);
    const factory = ARENA_FACTORIES[id] ?? ARENA_FACTORIES["tropical-island"];
    const built: ArenaBuilder = factory();
    scene.add(built.group);
    // Visual prototype: a model replaces the procedural visuals; gameplay colliders stay as built.
    const file = (ASSET_FILES.maps as Record<string, string>)[built.id];
    if (file) {
      cloneAsset(file).then((model) => {
        if (!model || this.current?.id !== built.id) return;
        built.group.visible = false;
        const visual = toGameSpace(model);
        visual.name = "map-visual";
        scene.add(visual);
        this.visual = visual;
      });
    }
    this.current = {
      id: built.id,
      name: built.name,
      group: built.group,
      colliders: built.colliders,
      ramps: built.ramps,
      zones: built.zones,
      spawns: built.spawns,
      pickups: built.pickups,
      waypoints: built.waypoints,
      bounds: built.bounds,
      fog: built.theme.fog,
      sky: built.theme.sky,
    };
    scene.background = new THREE.Color(built.theme.sky);
    scene.fog = new THREE.Fog(built.theme.fog, 55, 130);
    return this.current;
  }

  unload(scene: THREE.Scene): void {
    if (!this.current) return;
    scene.remove(this.current.group);
    disposeGroup(this.current.group);
    if (this.visual) scene.remove(this.visual);
    this.visual = null;
    this.current = null;
  }
}

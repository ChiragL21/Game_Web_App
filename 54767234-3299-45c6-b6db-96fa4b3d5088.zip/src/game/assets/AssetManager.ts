import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

/**
 * Central registry of replaceable 3D assets. To swap a model, change the file name here;
 * game code only refers to ids, never to file paths.
 */
export const ASSET_FILES = {
  karts: {
    blaze: "karts/scorch/scorch_detailed.glb",
    frostbite: "karts/enhanced/02_glacier.glb",
    volt: "karts/enhanced/03_spark.glb",
    shadow: "karts/enhanced/04_phantom.glb",
    titan: "karts/enhanced/05_bulwark.glb",
    rocket: "karts/enhanced/06_aero.glb",
    magneto: "karts/enhanced/07_magnetar.glb",
    vortex: "karts/enhanced/08_vortex.glb",
    bouncer: "karts/enhanced/09_bouncer.glb",
    pixel: "karts/enhanced/10_holo.glb",
  },
  weapons: {
    homing: "weapons/01_homing_rocket.glb",
    bomb: "weapons/02_bounce_bomb.glb",
    emp: "weapons/03_emp_pulse.glb",
    mine: "weapons/04_land_mine.glb",
    laser: "weapons/05_laser_cannon.glb",
    shield: "weapons/06_energy_shield.glb",
    nitro: "weapons/07_nitro_boost.glb",
    glove: "weapons/08_boxing_glove.glb",
    tornado: "weapons/09_tornado_launcher.glb",
  },
  maps: {
    "tropical-island": "maps/01_tropical_reef.glb",
  },
} as const;

const cache = new Map<string, Promise<THREE.Group>>();

function load(path: string): Promise<THREE.Group> {
  let p = cache.get(path);
  if (!p) {
    p = new GLTFLoader()
      .loadAsync(`${import.meta.env.BASE_URL}assets/${path}`)
      .then((g) => g.scene);
    cache.set(path, p);
  }
  return p;
}

/** Returns a fresh copy of a model, or null if the file can't be loaded (callers keep their fallback). */
export async function cloneAsset(path: string): Promise<THREE.Group | null> {
  try {
    return (await load(path)).clone(true);
  } catch {
    return null;
  }
}

/** Pack models are Z-up with forward along -Y; the game is Y-up with forward along +Z. */
export function toGameSpace(model: THREE.Object3D): THREE.Object3D {
  model.rotation.x = -Math.PI / 2;
  return model;
}

export type QualityLevel = "auto" | "low" | "medium" | "high";

export interface QualityState {
  level: QualityLevel;
  pixelRatio: number;
  particles: number;
  drawDistance: number;
  antialias: boolean;
}

export class QualityController {
  state: QualityState = {
    level: "auto",
    pixelRatio: 1,
    particles: 40,
    drawDistance: 90,
    antialias: false,
  };
  private frames = 0;
  private elapsed = 0;
  private currentFps = 60;
  private lowTime = 0;
  private highTime = 0;

  constructor(private cap: number = Math.min(2, window.devicePixelRatio || 1)) {
    this.apply("auto");
  }

  apply(level: QualityLevel): void {
    this.state.level = level;
    if (level === "low") this.set(1, 16, 55, false);
    else if (level === "medium") this.set(Math.min(1.5, this.cap), 32, 80, false);
    else if (level === "high") this.set(this.cap, 64, 110, true);
    else this.set(Math.min(1.6, this.cap), 40, 95, true);
  }

  sample(dt: number): QualityState {
    this.frames += 1;
    this.elapsed += dt;
    if (this.elapsed >= 0.5) {
      this.currentFps = this.frames / this.elapsed;
      this.frames = 0;
      this.elapsed = 0;
      if (this.state.level === "auto") this.adapt();
    }
    return this.state;
  }

  get fps(): number {
    return this.currentFps;
  }

  private adapt(): void {
    const fps = this.currentFps;
    if (fps < 42) {
      this.lowTime += 0.5;
      this.highTime = 0;
      if (this.lowTime > 1.5 && this.state.pixelRatio > 0.85) {
        this.set(Math.max(0.75, this.state.pixelRatio - 0.15), Math.max(12, this.state.particles - 8), 60, false);
      }
    } else if (fps > 57) {
      this.highTime += 0.5;
      this.lowTime = 0;
      if (this.highTime > 4) {
        this.set(Math.min(this.cap, this.state.pixelRatio + 0.1), Math.min(48, this.state.particles + 4), 90, false);
        this.highTime = 0;
      }
    } else {
      this.lowTime = 0;
      this.highTime = 0;
    }
  }

  private set(pr: number, particles: number, dist: number, aa: boolean): void {
    this.state.pixelRatio = pr;
    this.state.particles = particles;
    this.state.drawDistance = dist;
    this.state.antialias = aa;
  }
}

import * as THREE from "three";
import { QualityController } from "./Quality";

export class GameRenderer {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(55, 1, 0.12, 140);
  readonly renderer: THREE.WebGLRenderer;
  readonly quality: QualityController;

  constructor(canvas: HTMLCanvasElement) {
    this.quality = new QualityController();
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
      stencil: false,
    });
    this.renderer.setClearColor(0x8fd8ff, 1);
    this.renderer.setPixelRatio(Math.min(2, this.quality.state.pixelRatio));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.25;
    this.renderer.shadowMap.enabled = false;
    const hemi = new THREE.HemisphereLight(0xfff7e0, 0x7ad16a, 1.6);
    this.scene.add(hemi);
    const fill = new THREE.DirectionalLight(0xffffff, 0.8);
    fill.position.set(18, 28, 12);
    this.scene.add(fill);
    const kick = new THREE.DirectionalLight(0x9cdcff, 0.22);
    kick.position.set(-12, 10, -8);
    this.scene.add(kick);
    this.resize();
  }

  resize(): void {
    const canvas = this.renderer.domElement;
    const parent = canvas.parentElement ?? canvas;
    const w = parent.clientWidth || window.innerWidth;
    const h = parent.clientHeight || window.innerHeight;
    const pr = Math.min(2, this.quality.state.pixelRatio);
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  render(): void {
    const q = this.quality.state;
    if (this.scene.fog instanceof THREE.Fog) this.scene.fog.far = q.drawDistance + 36;
    this.camera.far = q.drawDistance + 40;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(Math.min(2, q.pixelRatio));
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    this.renderer.dispose();
  }
}

import * as THREE from "three";

const ramp = new THREE.DataTexture(new Uint8Array([90, 90, 90, 255, 210, 210, 210, 255]), 2, 1, THREE.RGBAFormat);
ramp.minFilter = THREE.NearestFilter;
ramp.magFilter = THREE.NearestFilter;
ramp.needsUpdate = true;

export const lambert = new THREE.MeshLambertMaterial({ vertexColors: true });
export const toon = new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: ramp });
export const lambertAlpha = new THREE.MeshLambertMaterial({
  vertexColors: true,
  transparent: true,
  opacity: 0.78,
  depthWrite: false,
});

export function paint(geo: THREE.BufferGeometry, color: number, variance = 0.04): void {
  const c = new THREE.Color(color);
  const n = geo.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const j = (i % 9) * 0.01;
    arr[i * 3] = clamp01(c.r + j * variance);
    arr[i * 3 + 1] = clamp01(c.g + (1 - j) * variance * 0.5);
    arr[i * 3 + 2] = clamp01(c.b - j * variance * 0.3);
  }
  geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
  geo.computeVertexNormals();
}

let pbr = false;
const pbrCache = new Map<number, THREE.MeshStandardMaterial>();

/** Showroom mode: glossy physically based surfaces. Only used by the menu preview. */
export function setPbr(on: boolean): void {
  pbr = on;
}

function pbrMat(color: number): THREE.MeshStandardMaterial {
  let m = pbrCache.get(color);
  if (!m) {
    m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.32, metalness: 0.12, envMapIntensity: 0.55 });
    pbrCache.set(color, m);
  }
  return m;
}

export function meshOf(geo: THREE.BufferGeometry, color: number, x = 0, y = 0, z = 0): THREE.Mesh {
  paint(geo, color);
  const m = new THREE.Mesh(geo, pbr ? pbrMat(color) : toon);
  m.position.set(x, y, z);
  return m;
}

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

const outlineMat = new THREE.MeshBasicMaterial({ color: 0x1e1b4b, side: THREE.BackSide });

/** Cartoon outline: a slightly larger, dark, back-face copy behind each mesh. */
export function addOutlines(root: THREE.Object3D, thickness = 1.06): void {
  const meshes: THREE.Mesh[] = [];
  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh && o.userData.outlined !== true && (o as THREE.Mesh).material === toon) meshes.push(o as THREE.Mesh);
  });
  for (const m of meshes) {
    m.userData.outlined = true;
    const shell = new THREE.Mesh(m.geometry, outlineMat);
    shell.scale.setScalar(thickness);
    shell.raycast = () => {};
    m.add(shell);
  }
}

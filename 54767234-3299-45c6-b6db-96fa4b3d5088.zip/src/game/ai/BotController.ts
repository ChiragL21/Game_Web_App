import type { GameInput } from "../input/InputManager";
import { EMPTY_INPUT } from "../input/InputManager";
import type { KartState } from "../kart/Kart";
import type { Waypoint } from "../physics/types";

export function botInput(kart: KartState, waypoints: Waypoint[], rivals: KartState[]): GameInput {
  const input: GameInput = { ...EMPTY_INPUT };
  if (!kart.alive || waypoints.length === 0) return input;
  let wp = waypoints[kart.waypoint % waypoints.length];
  const dist = Math.hypot(wp.x - kart.x, wp.z - kart.z);
  if (dist < 6) kart.waypoint = (kart.waypoint + 1) % waypoints.length;
  wp = waypoints[kart.waypoint % waypoints.length];
  const desired = Math.atan2(wp.x - kart.x, wp.z - kart.z);
  let err = desired - kart.yaw;
  while (err > Math.PI) err -= Math.PI * 2;
  while (err < -Math.PI) err += Math.PI * 2;
  input.steer = Math.max(-1, Math.min(1, err * 1.6));
  input.throttle = 0.78;
  if (Math.abs(err) > 0.7) {
    input.throttle = 0.5;
    input.drift = Math.abs(kart.speed) > 9;
  }
  const threat = rivals.find((r) => r.id !== kart.id && r.alive && Math.hypot(r.x - kart.x, r.z - kart.z) < 7);
  if (threat && kart.ammo > 0) input.fire = true;
  if (kart.nitroCharge > 0.6 && Math.abs(err) < 0.25) input.nitro = true;
  return input;
}

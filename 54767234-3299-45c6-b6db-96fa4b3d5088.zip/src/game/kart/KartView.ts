import * as THREE from "three";
import { ASSET_FILES, cloneAsset, toGameSpace } from "../assets/AssetManager";
import { KART_CATALOG } from "@shared/catalog";
import { addOutlines, meshOf, setPbr } from "../engine/materials";
import type { KartState } from "./Kart";

/** Original driver: Pip the fox — short ears, round helmet. Not a rabbit. */
export class KartView {
  readonly group = new THREE.Group();
  private wheels: THREE.Object3D[] = [];
  private body: THREE.Group;
  private shield: THREE.Mesh;
  loaded: THREE.Object3D | null = null;
  private sparkles: THREE.Group;

  constructor(kartId: string, opts: { pbr?: boolean } = {}) {
    setPbr(!!opts.pbr);
    const kit = KART_CATALOG.find((k) => k.id === kartId) ?? KART_CATALOG[0];
    const bodyC = hex(kit.body);
    const accent = hex(kit.accent);
    const trim = hex(kit.trim);
    this.body = new THREE.Group();

    const shape = kit.shape;
    const hullR = shape === "bulky" ? 0.68 : shape === "sleek" ? 0.5 : 0.58;
    const hullLen = shape === "round" ? 1.0 : shape === "bulky" ? 1.15 : 1.35;
    const hull = meshOf(new THREE.CapsuleGeometry(hullR, hullLen, 8, 14), bodyC, 0, 0.52, 0.06);
    hull.rotation.z = Math.PI / 2;
    hull.rotation.y = Math.PI / 2;
    if (shape === "round") hull.scale.set(1, 1.15, 1);
    this.body.add(hull);
    const nose = meshOf(new THREE.SphereGeometry(hullR * 0.72, 14, 10), bodyC, 0, 0.48, 0.95);
    nose.scale.set(1.15, 0.7, shape === "wedge" ? 1.4 : 0.9);
    this.body.add(nose);
    this.body.add(topper(kit.topper, kit.accent, bodyC));

    const seat = meshOf(new THREE.SphereGeometry(0.5, 14, 10), 0xf8fafc, 0, 0.78, -0.08);
    seat.scale.set(1.12, 0.38, 1.0);
    this.body.add(seat);

    const bumper = meshOf(new THREE.CapsuleGeometry(0.14, 1.05, 4, 10), accent, 0, 0.38, 1.22);
    bumper.rotation.z = Math.PI / 2;
    this.body.add(bumper);

    const spoiler = meshOf(new THREE.CapsuleGeometry(0.07, 0.92, 4, 8), accent, 0, 0.88, -0.98);
    spoiler.rotation.z = Math.PI / 2;
    this.body.add(spoiler);
    this.body.add(meshOf(new THREE.CylinderGeometry(0.06, 0.06, 0.26, 8), trim, 0.34, 0.74, -0.86));
    this.body.add(meshOf(new THREE.CylinderGeometry(0.06, 0.06, 0.26, 8), trim, -0.34, 0.74, -0.86));

    this.body.add(pipe(0.28, 0.78, -1.08, 0.18));
    this.body.add(pipe(-0.28, 0.78, -1.08, -0.18));
    this.body.add(meshOf(new THREE.SphereGeometry(0.14, 10, 8), 0xcbd5e1, 0.28, 0.9, -1.28));
    this.body.add(meshOf(new THREE.SphereGeometry(0.14, 10, 8), 0xcbd5e1, -0.28, 0.9, -1.28));

    this.body.add(fox());

    this.wheels = [
      wheel(-0.92, 0.34, 0.7, accent),
      wheel(0.92, 0.34, 0.7, accent),
      wheel(-0.92, 0.34, -0.72, accent),
      wheel(0.92, 0.34, -0.72, accent),
    ];
    this.wheels.forEach((w) => this.body.add(w));
    this.group.add(this.body);

    this.shield = new THREE.Mesh(
      new THREE.SphereGeometry(1.55, 18, 14),
      new THREE.MeshBasicMaterial({
        color: 0x7dffe0,
        transparent: true,
        opacity: 0.18,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    this.shield.position.y = 0.7;
    this.group.add(this.shield);

    this.sparkles = new THREE.Group();
    for (let i = 0; i < 10; i++) {
      const s = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.08, 0),
        new THREE.MeshBasicMaterial({ color: 0xffffff }),
      );
      s.userData.phase = i * 0.7;
      this.sparkles.add(s);
    }
    this.group.add(this.sparkles);
    this.group.scale.setScalar(1.12);
    const file = (ASSET_FILES.karts as Record<string, string>)[kit.id];
    if (file) {
      // The GLB is the kart. The code-built body stays hidden so no placeholder is shown.
      this.body.visible = false;
      cloneAsset(file).then(
        (model) => {
          if (!model) {
            console.error(`Kart model failed to load: ${file}`);
            return;
          }
          this.group.add(toGameSpace(model));
          this.loaded = model;
        },
        (err) => console.error(`Kart model failed to load: ${file}`, err),
      );
    }
    if (!opts.pbr) addOutlines(this.group);
    else this.addGlow(kit.accent);
    setPbr(false);
  }

  /** Showroom only: glowing headlights and a soft rim glow in the kart's accent colour. */
  private addGlow(accent: string): void {
    const c = new THREE.Color(accent);
    const lampMat = new THREE.MeshBasicMaterial({ color: c });
    for (const x of [0.2, -0.2]) {
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), lampMat);
      lamp.position.set(x, 0.56, 1.2);
      this.body.add(lamp);
    }
    const glow = new THREE.Mesh(
      new THREE.SphereGeometry(1.5, 24, 16),
      new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.06, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    glow.position.y = 0.7;
    this.group.add(glow);
  }

  sync(kart: KartState, dt: number, t = performance.now() / 1000): void {
    if (!kart.alive) {
      this.group.visible = false;
      return;
    }
    this.group.visible = true;
    this.group.position.set(kart.x, kart.y - 0.32, kart.z);
    this.group.rotation.y = kart.yaw;
    this.group.rotation.x = kart.pitch * 0.7;
    const spin = kart.speed * dt * 1.55;
    for (const w of this.wheels) w.rotation.x += spin;
    this.body.rotation.z = THREE.MathUtils.damp(
      this.body.rotation.z,
      -kart.speed * 0.0018 - (kart.drifting ? kart.driftDir * 0.12 : 0),
      8,
      dt,
    );
    const shielded = true;
    this.shield.visible = shielded;
    const mat = this.shield.material as THREE.MeshBasicMaterial;
    mat.opacity = shielded ? 0.16 + Math.sin(t * 6) * 0.05 : 0;
    this.sparkles.children.forEach((ch, i) => {
      const a = t * 1.6 + (ch.userData.phase as number);
      ch.position.set(Math.cos(a) * 1.35, 0.55 + Math.sin(a * 1.7) * 0.55, Math.sin(a) * 1.35);
      const s = 0.55 + Math.sin(t * 8 + i) * 0.35;
      ch.scale.setScalar(s);
      ch.visible = shielded || i < 4;
    });
  }

  dispose(): void {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
  }
}

/** Head decoration per kart. Purely visual; abilities live in the sim. */
function topper(kind: string, accent: string, body: number): THREE.Group {
  const g = new THREE.Group();
  const a = hex(accent);
  const y = 1.0;
  switch (kind) {
    case "ears":
      g.add(meshOf(new THREE.ConeGeometry(0.12, 0.38, 8), body, 0.2, y + 0.2, -0.35));
      g.add(meshOf(new THREE.ConeGeometry(0.12, 0.38, 8), body, -0.2, y + 0.2, -0.35));
      break;
    case "horns":
      g.add(meshOf(new THREE.ConeGeometry(0.08, 0.42, 8), a, 0.22, y + 0.18, -0.2));
      g.add(meshOf(new THREE.ConeGeometry(0.08, 0.42, 8), a, -0.22, y + 0.18, -0.2));
      break;
    case "halo": {
      const h = meshOf(new THREE.TorusGeometry(0.3, 0.035, 8, 20), a, 0, y + 0.5, -0.05);
      h.rotation.x = Math.PI / 2;
      g.add(h);
      break;
    }
    case "antenna":
      g.add(meshOf(new THREE.CylinderGeometry(0.03, 0.03, 0.55, 6), 0xcbd5e1, 0.12, y + 0.3, -0.3));
      g.add(meshOf(new THREE.SphereGeometry(0.08, 8, 8), a, 0.12, y + 0.6, -0.3));
      break;
    case "crown":
      for (let i = -1; i <= 1; i++) g.add(meshOf(new THREE.ConeGeometry(0.07, 0.24, 6), a, i * 0.16, y + 0.2, -0.15));
      break;
    case "hat":
      g.add(meshOf(new THREE.CylinderGeometry(0.28, 0.28, 0.06, 14), a, 0, y + 0.1, -0.1));
      g.add(meshOf(new THREE.CylinderGeometry(0.16, 0.2, 0.22, 12), a, 0, y + 0.22, -0.1));
      break;
    default:
      break;
  }
  return g;
}

function fox(): THREE.Group {
  const g = new THREE.Group();
  g.add(meshOf(new THREE.SphereGeometry(0.34, 16, 12), 0xf97316, 0, 1.12, 0.08));
  g.add(meshOf(new THREE.SphereGeometry(0.3, 16, 12), 0xffedd5, 0, 1.38, 0.16));
  const earL = meshOf(new THREE.ConeGeometry(0.1, 0.22, 8), 0xea580c, 0.16, 1.62, 0.08);
  const earR = meshOf(new THREE.ConeGeometry(0.1, 0.22, 8), 0xea580c, -0.16, 1.62, 0.08);
  g.add(earL, earR);
  const snout = meshOf(new THREE.SphereGeometry(0.12, 10, 8), 0xfff7ed, 0, 1.32, 0.38);
  g.add(snout);
  g.add(meshOf(new THREE.SphereGeometry(0.04, 8, 8), 0x1e293b, 0, 1.34, 0.5));
  g.add(meshOf(new THREE.SphereGeometry(0.07, 8, 8), 0xffffff, 0.1, 1.44, 0.36));
  g.add(meshOf(new THREE.SphereGeometry(0.07, 8, 8), 0xffffff, -0.1, 1.44, 0.36));
  g.add(meshOf(new THREE.SphereGeometry(0.035, 8, 8), 0x0f172a, 0.1, 1.44, 0.42));
  g.add(meshOf(new THREE.SphereGeometry(0.035, 8, 8), 0x0f172a, -0.1, 1.44, 0.42));
  const helm = meshOf(new THREE.SphereGeometry(0.22, 12, 10), 0x1d4ed8, 0, 1.5, 0.02);
  helm.scale.set(1.05, 0.55, 0.9);
  g.add(helm);
  return g;
}

function pipe(x: number, y: number, z: number, tilt: number): THREE.Mesh {
  const m = meshOf(new THREE.CylinderGeometry(0.08, 0.08, 0.48, 10), 0xcbd5e1, x, y, z);
  m.rotation.x = Math.PI / 2 + tilt * 0.4;
  return m;
}

function wheel(x: number, y: number, z: number, accent: number): THREE.Group {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  const tire = meshOf(new THREE.CylinderGeometry(0.42, 0.42, 0.38, 18), 0x1f2937);
  tire.rotation.z = Math.PI / 2;
  const hub = meshOf(new THREE.CylinderGeometry(0.2, 0.2, 0.42, 12), accent);
  hub.rotation.z = Math.PI / 2;
  const rim = meshOf(new THREE.TorusGeometry(0.3, 0.05, 8, 16), 0xe2e8f0);
  rim.rotation.y = Math.PI / 2;
  g.add(tire, hub, rim);
  return g;
}

function hex(c: string): number {
  return Number.parseInt(c.replace("#", ""), 16);
}

import * as THREE from "three";
import { CAMERA_BOOST_FOV, CAMERA_FOV } from "@shared/constants";
import type { KartState } from "./Kart";

export class KartCamera {
  private look = new THREE.Vector3();
  private pos = new THREE.Vector3(0, 3.2, -6);
  private snapped = false;

  follow(camera: THREE.PerspectiveCamera, kart: KartState, dt: number): void {
    const back = 8.4;
    const height = 4.55;
    const ahead = 10.5;
    const fx = Math.sin(kart.yaw);
    const fz = Math.cos(kart.yaw);
    const desired = this.pos;
    desired.set(kart.x - fx * back, kart.y + height, kart.z - fz * back);
    if (!this.snapped) {
      camera.position.copy(desired);
      this.snapped = true;
    } else {
      camera.position.lerp(desired, 1 - Math.pow(0.012, dt));
    }
    this.look.set(kart.x + fx * ahead, kart.y + 0.55, kart.z + fz * ahead);
    camera.lookAt(this.look);
    const fov = kart.boostTime > 0 ? CAMERA_BOOST_FOV : CAMERA_FOV;
    camera.fov += (fov - camera.fov) * Math.min(1, 6 * dt);
    camera.updateProjectionMatrix();
  }
}

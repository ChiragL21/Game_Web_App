import { describe, expect, it } from "vitest";
import { EMPTY_INPUT } from "@shared/input";
import { createKart, stepKart, type KartState, type WorldQuery } from "@shared/sim/kart";

const emptyWorld: WorldQuery = {
  colliders: [],
  ramps: [],
  zones: [],
  karts: [] as KartState[],
  bounds: { minX: -40, maxX: 40, minZ: -40, maxZ: 40 },
};

describe("kart controller", () => {
  it("accelerates forward and steers", () => {
    const kart = createKart({ id: "p", name: "P", kartId: "blaze" });
    emptyWorld.karts = [kart];
    for (let i = 0; i < 60; i++) {
      stepKart(kart, { ...EMPTY_INPUT, throttle: 1 }, emptyWorld);
    }
    expect(kart.speed).toBeGreaterThan(8);
    const zBefore = kart.z;
    for (let i = 0; i < 30; i++) {
      stepKart(kart, { ...EMPTY_INPUT, throttle: 1, steer: 1 }, emptyWorld);
    }
    expect(kart.yaw).not.toBe(0);
    expect(Math.abs(kart.z - zBefore) + Math.abs(kart.x)).toBeGreaterThan(1);
  });

  it("reverses when braking from rest", () => {
    const kart = createKart({ id: "p", name: "P", kartId: "frostbite" });
    emptyWorld.karts = [kart];
    for (let i = 0; i < 40; i++) stepKart(kart, { ...EMPTY_INPUT, brake: 1 }, emptyWorld);
    expect(kart.speed).toBeLessThan(-2);
  });

  it("drifts and charges nitro, then consumes nitro", () => {
    const kart = createKart({ id: "p", name: "P", kartId: "volt" });
    emptyWorld.karts = [kart];
    for (let i = 0; i < 80; i++) stepKart(kart, { ...EMPTY_INPUT, throttle: 1 }, emptyWorld);
    const charged = kart.nitroCharge;
    for (let i = 0; i < 40; i++) stepKart(kart, { ...EMPTY_INPUT, throttle: 1, steer: 1, drift: true }, emptyWorld);
    expect(kart.drifting).toBe(true);
    expect(kart.nitroCharge).toBeGreaterThan(charged);
    const before = kart.nitroCharge;
    stepKart(kart, { ...EMPTY_INPUT, throttle: 1, nitro: true }, emptyWorld);
    expect(kart.boostTime).toBeGreaterThan(0);
    expect(kart.nitroCharge).toBeLessThan(before);
  });
});

export {
  applyDamage,
  createKart,
  spawnKart,
  stepKart,
  tryRespawn,
  type KartState,
  type WorldQuery,
} from "@shared/sim/kart";

import type { GameInput } from "@shared/input";
import type { PlayerSnap, Snapshot } from "@shared/protocol";
import { GameRenderer } from "./engine/Renderer";
import { ParticlePool } from "./fx/Particles";
import { PickupCubes } from "./fx/PickupCubes";
import { InputManager } from "./input/InputManager";
import { KartCamera } from "./kart/KartCamera";
import { KartView } from "./kart/KartView";
import { MapManager } from "./maps/MapManager";
import { AudioManager } from "./audio/AudioManager";
import { createKart, stepKart, type KartState } from "@shared/sim/kart";
import { compileMap } from "@shared/sim/maps";

export interface HudState {
  health: number;
  ammo: number;
  weapon: string | null;
  cooldown: number;
  nitro: number;
  ult: number;
  ultName: string;
  timer: number;
  rank: number;
  elims: number;
  notes: string[];
  minimap: { x: number; z: number; yaw: number; others: { x: number; z: number; team: number }[] };
  fps: number;
  ping: number;
  objective: string;
  players: { name: string; elims: number; you: boolean }[];
  name: string;
}

export class GameApp {
  readonly input = new InputManager();
  readonly audio = new AudioManager();
  hud: HudState = emptyHud();
  private renderer: GameRenderer;
  private maps = new MapManager();
  private cam = new KartCamera();
  private fx: ParticlePool;
  private pickups = new PickupCubes();
  private views = new Map<string, KartView>();
  private local: KartState;
  pending: GameInput[] = [];
  private remotes = new Map<string, PlayerSnap>();
  private raf = 0;
  private acc = 0;
  private last = performance.now();
  private running = false;
  private onResize = () => this.renderer.resize();
  sendInput?: (i: GameInput) => void;
  onEnd?: (stats: { elims: number; damage: number; mapId: string }) => void;
  playerId: string;
  mapId: string;
  private compiled = compileMap("tropical-island");
  private localMode = true;
  private ended = false;
  paused = false;

  constructor(canvas: HTMLCanvasElement, opts: { playerId: string; mapId: string; kartId: string; name: string; local?: boolean; duration?: number }) {
    this.playerId = opts.playerId;
    this.mapId = opts.mapId;
    this.localMode = opts.local !== false;
    this.compiled = compileMap(opts.mapId);
    this.hud.timer = opts.duration ?? 120;
    this.renderer = new GameRenderer(canvas);
    this.fx = new ParticlePool(32);
    this.renderer.scene.add(this.fx.mesh);
    const loaded = this.maps.load(opts.mapId, this.renderer.scene);
    this.pickups.load(loaded.pickups.length ? loaded.pickups : this.compiled.pickups);
    this.renderer.scene.add(this.pickups.group);
    this.local = createKart({ id: opts.playerId, name: opts.name, kartId: opts.kartId, isBot: false });
    const spawn = loaded.spawns[0] ?? this.compiled.spawns[0]!;
    this.local.x = spawn.x;
    this.local.z = spawn.z;
    this.local.yaw = spawn.yaw;
    const view = new KartView(opts.kartId);
    this.views.set(opts.playerId, view);
    this.renderer.scene.add(view.group);
    this.input.attach(canvas.parentElement ?? document.body);
    window.addEventListener("resize", this.onResize);
  }

  start(): void {
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      const dt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      this.acc += dt;
      if (this.paused) {
        this.acc = 0;
        this.renderer.render();
        this.raf = requestAnimationFrame(loop);
        return;
      }
      const input = this.input.poll();
      this.sendInput?.(input);
      this.pending.push({ ...input });
      if (this.pending.length > 48) this.pending.shift();
      const vis = this.maps.current;
      const map = this.compiled;
      while (this.acc >= 1 / 60) {
        stepKart(this.local, input, {
          colliders: vis?.colliders.length ? vis.colliders : map.colliders,
          ramps: vis?.ramps.length ? vis.ramps : map.ramps,
          zones: vis?.zones.length ? vis.zones : map.zones,
          karts: [this.local],
          bounds: vis?.bounds ?? map.bounds,
        });
        if (this.localMode) this.hud.timer = Math.max(0, this.hud.timer - 1 / 60);
        this.acc -= 1 / 60;
      }
      if (this.localMode && this.hud.timer <= 0 && !this.ended) {
        this.ended = true;
        this.onEnd?.({ elims: this.local.elims, damage: this.local.damageDealt, mapId: this.mapId });
      }
      this.syncViews(dt);
      this.pickups.update(now / 1000);
      this.fx.setBudget(this.renderer.quality.state.particles);
      this.fx.update(dt);
      this.cam.follow(this.renderer.camera, this.local, dt);
      this.renderer.quality.sample(dt);
      this.renderer.render();
      this.refreshHud();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  applySnapshot(snap: Snapshot): void {
    const me = snap.players.find((p) => p.id === this.playerId);
    if (me) {
      this.local.x = me.x;
      this.local.y = me.y;
      this.local.z = me.z;
      this.local.yaw = me.yaw;
      this.local.pitch = me.pitch;
      this.local.speed = me.speed;
      this.local.health = me.health;
      this.local.ammo = me.ammo;
      this.local.weapon = me.weapon;
      this.local.cooldown = me.cooldown;
      this.local.nitroCharge = me.nitro;
      this.local.boostTime = me.boost;
      this.local.shield = me.shield;
      this.local.ghost = me.ghost;
      this.local.ultCharge = me.ultCharge;
      this.local.ult = me.ult;
      this.local.elims = me.elims;
      this.local.alive = me.alive;
      this.pending = this.pending.filter((p) => p.seq > snap.ackSeq);
      const map = this.compiled;
      for (const p of this.pending) {
        stepKart(this.local, p, {
          colliders: map.colliders,
          ramps: map.ramps,
          zones: map.zones,
          karts: [this.local],
          bounds: map.bounds,
        });
      }
    }
    for (const p of snap.players) {
      if (p.id === this.playerId) continue;
      this.remotes.set(p.id, p);
      if (!this.views.has(p.id)) {
        const v = new KartView(p.kartId);
        this.views.set(p.id, v);
        this.renderer.scene.add(v.group);
      }
    }
    this.hud.timer = snap.timeLeft;
    this.hud.notes = snap.notes.map((n) => n.text);
    this.hud.rank = 1 + snap.players.filter((p) => p.elims > (me?.elims ?? 0)).length;
  }

  private syncViews(dt: number): void {
    this.views.get(this.playerId)?.sync(this.local, dt);
    for (const [id, snap] of this.remotes) {
      const dummy = createKart({ id, name: snap.name, kartId: snap.kartId });
      dummy.x = snap.x;
      dummy.y = snap.y;
      dummy.z = snap.z;
      dummy.yaw = snap.yaw;
      dummy.pitch = snap.pitch;
      dummy.speed = snap.speed;
      dummy.alive = snap.alive;
      dummy.drifting = false;
      this.views.get(id)?.sync(dummy, dt);
    }
    if (this.local.boostTime > 0) this.fx.trail(this.local.x, this.local.y, this.local.z);
  }

  private refreshHud(): void {
    this.hud.health = this.local.health;
    this.hud.ammo = this.local.ammo;
    this.hud.weapon = this.local.weapon;
    this.hud.cooldown = this.local.cooldown;
    this.hud.nitro = this.local.nitroCharge;
    this.hud.ult = this.local.ultCharge;
    this.hud.ultName = this.local.ult;
    this.hud.elims = this.local.elims;
    this.hud.fps = this.renderer.quality.fps;
    this.hud.minimap = {
      x: this.local.x,
      z: this.local.z,
      yaw: this.local.yaw,
      others: [...this.remotes.values()].map((p) => ({ x: p.x, z: p.z, team: 0 })),
    };
    this.hud.name = this.local.name;
    const board = [
      { name: this.local.name, elims: this.local.elims, you: true },
      ...[...this.remotes.values()].map((p) => ({ name: p.name, elims: p.elims, you: false })),
    ].sort((a, b) => b.elims - a.elims);
    this.hud.players = board;
    this.hud.rank = 1 + board.findIndex((p) => p.you);
  }

  setQuality(level: "auto" | "low" | "medium" | "high"): void {
    this.renderer.quality.apply(level);
  }

  setInvertSteer(v: boolean): void {
    this.input.setInvertSteer(v);
  }

  dispose(): void {
    this.running = false;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    this.input.detach();
    this.maps.unload(this.renderer.scene);
    this.pickups.clear();
    this.fx.dispose();
    this.views.forEach((v) => v.dispose());
    this.renderer.dispose();
  }
}

function emptyHud(): HudState {
  return {
    health: 100,
    ammo: 0,
    weapon: null,
    cooldown: 0,
    nitro: 0,
    ult: 0,
    ultName: "shockwave",
    timer: 120,
    rank: 1,
    elims: 0,
    notes: [],
    minimap: { x: 0, z: 0, yaw: 0, others: [] },
    fps: 60,
    ping: 0,
    objective: "Wreck rivals",
    players: [],
    name: "You",
  };
}


import type { C2S, MatchResult, RoomSummary, S2C, Snapshot } from "@shared/protocol";

export class NetClient {
  private ws: WebSocket | null = null;
  rooms: RoomSummary[] = [];
  room: RoomSummary | null = null;
  playerId = "";
  profile: Record<string, unknown> | null = null;
  connected = false;
  lastError = "";
  friends: unknown[] = [];
  party: unknown = null;
  presence: unknown = {};
  onSnapshot?: (s: Snapshot) => void;
  onMatchStart?: (mapId: string, mode: string, seed: number) => void;
  onMatchEnd?: (r: MatchResult) => void;
  onRoom?: (r: RoomSummary | null) => void;
  onRtc?: (from: string, data: unknown) => void;
  onSocial?: () => void;

  connect(token: string): void {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const url = `${proto}://${location.host}/ws`;
    this.ws = new WebSocket(url);
    this.ws.onopen = () => {
      this.connected = true;
      this.send({ type: "hello", token });
    };
    this.ws.onclose = () => {
      this.connected = false;
    };
    this.ws.onerror = () => {
      this.lastError = "Server unreachable";
    };
    this.ws.onmessage = (ev) => {
      let msg: S2C;
      try {
        msg = JSON.parse(String(ev.data)) as S2C;
      } catch {
        return;
      }
      if (msg.type === "welcome") {
        this.playerId = msg.playerId;
        this.rooms = msg.rooms;
        this.profile = msg.profile as Record<string, unknown>;
      } else if (msg.type === "roomList") this.rooms = msg.rooms;
      else if (msg.type === "roomUpdate") {
        this.room = msg.room;
        this.onRoom?.(msg.room);
      } else if (msg.type === "matchStart") this.onMatchStart?.(msg.mapId, msg.mode, msg.seed);
      else if (msg.type === "snapshot") this.onSnapshot?.(msg.snap);
      else if (msg.type === "matchEnd") this.onMatchEnd?.(msg.result);
      else if (msg.type === "social") {
        this.friends = msg.friends as unknown[];
        this.party = msg.party;
        this.presence = msg.presence;
        this.onSocial?.();
      } else if (msg.type === "rtc") this.onRtc?.(msg.from, msg.data);
      else if (msg.type === "error") this.lastError = msg.message;
    };
  }

  send(msg: C2S): void {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(msg));
  }

  disconnect(): void {
    this.ws?.close();
    this.ws = null;
  }
}

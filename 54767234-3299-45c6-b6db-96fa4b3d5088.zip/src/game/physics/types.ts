export type {
  AabbCollider,
  CircleCollider,
  Collider,
  ColliderKind,
  ObbCollider,
  PickupPoint,
  RampCollider,
  SpawnPoint,
  Waypoint,
  Zone,
  ZoneKind,
} from "@shared/sim/types";

import { describe, expect, it } from "vitest";
import { collideCircleAabb, collideCircleObb, collideCircles } from "@shared/sim/collision";

describe("collision", () => {
  it("pushes a circle out of an aabb", () => {
    const hit = collideCircleAabb(5.2, 0, 1, 0, 5, -2, 2);
    expect(hit).not.toBeNull();
    expect(hit!.nx).toBeGreaterThan(0.9);
    expect(hit!.overlap).toBeGreaterThan(0.1);
  });

  it("does not collide when separated", () => {
    expect(collideCircleAabb(10, 0, 1, 0, 5, -2, 2)).toBeNull();
  });

  it("resolves kart overlap", () => {
    const hit = collideCircles(0, 0, 1, 1.2, 0, 1);
    expect(hit).not.toBeNull();
    expect(hit!.overlap).toBeCloseTo(0.8, 5);
  });

  it("handles rotated boxes", () => {
    const hit = collideCircleObb(0, 0, 1, 0, 0, 0.4, 2, Math.PI / 4);
    expect(hit).not.toBeNull();
  });
});

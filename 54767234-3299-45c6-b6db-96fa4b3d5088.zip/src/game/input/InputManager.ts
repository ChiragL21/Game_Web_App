import { EMPTY_INPUT as BASE, type GameInput as SharedInput } from "@shared/input";

export type GameInput = SharedInput;
export const EMPTY_INPUT: GameInput = { ...BASE };

type PointerKind = "joy" | "accel" | "brake" | "drift" | "nitro" | "fire" | "ult" | "left" | "right";

interface PointerBind {
  kind: PointerKind;
  id: number;
}

export class InputManager {
  readonly state: GameInput = { ...EMPTY_INPUT };
  private keys = new Set<string>();
  private binds = new Map<number, PointerBind>();
  private joyOriginX = 0;
  private joyOriginY = 0;
  private joyX = 0;
  private joyY = 0;
  private joyActive = false;
  private touchAccel = false;
  private touchBrake = false;
  private touchDrift = false;
  private touchNitro = false;
  private touchFire = false;
  private touchUlt = false;
  private touchLeft = false;
  private touchRight = false;
  gamepadEnabled = true;
  seq = 0;
  private invertSteer = false;
  private attached: HTMLElement | null = null;
  private gamepadIndex: number | null = null;
  private coarse = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;
  private joyMoved = false;
  private firePulse = 0;

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    this.keys.add(e.code);
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) {
      e.preventDefault();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
    this.resetTouch();
  };

  attach(root: HTMLElement): void {
    this.attached = root;
    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    root.addEventListener("contextmenu", prevent, { passive: false });
    root.addEventListener("touchmove", prevent, { passive: false });
  }

  detach(): void {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    this.attached?.removeEventListener("contextmenu", prevent);
    this.attached?.removeEventListener("touchmove", prevent);
    this.attached = null;
  }

  setInvertSteer(value: boolean): void {
    this.invertSteer = value;
  }

  beginPointer(kind: PointerKind, e: ReactPointer): void {
    e.preventDefault();
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    this.binds.set(e.pointerId, { kind, id: e.pointerId });
    if (kind === "joy") {
      this.joyActive = true;
      this.joyMoved = false;
      this.joyOriginX = e.clientX;
      this.joyOriginY = e.clientY;
      this.joyX = 0;
      this.joyY = 0;
    } else {
      this.setButton(kind, true);
    }
  }

  movePointer(e: ReactPointer): void {
    const bind = this.binds.get(e.pointerId);
    if (!bind || bind.kind !== "joy") return;
    const dx = e.clientX - this.joyOriginX;
    const dy = e.clientY - this.joyOriginY;
    const max = 54;
    const len = Math.hypot(dx, dy);
    const s = len > max ? max / len : 1;
    this.joyX = (dx * s) / max;
    this.joyY = (dy * s) / max;
    if (Math.hypot(this.joyX, this.joyY) > 0.18) this.joyMoved = true;
  }

  endPointer(e: ReactPointer): void {
    const bind = this.binds.get(e.pointerId);
    if (!bind) return;
    this.binds.delete(e.pointerId);
    if (bind.kind === "joy") {
      const remaining = [...this.binds.values()].some((b) => b.kind === "joy");
      if (!remaining) {
        if (!this.joyMoved) this.firePulse = 3;
        this.joyActive = false;
        this.joyX = 0;
        this.joyY = 0;
      }
    } else {
      this.setButton(bind.kind, false);
    }
  }

  poll(): GameInput {
    this.state.throttle = 0;
    this.state.brake = 0;
    this.state.steer = 0;
    this.state.drift = false;
    this.state.nitro = false;
    this.state.fire = false;
    this.state.ultimate = false;
    this.pollGamepad();
    const kbThrottle = this.keys.has("KeyW") || this.keys.has("ArrowUp") ? 1 : 0;
    const kbBrake = this.keys.has("KeyS") || this.keys.has("ArrowDown") || this.keys.has("ControlLeft") ? 1 : 0;
    let kbSteer = 0;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) kbSteer -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) kbSteer += 1;

    let steer = kbSteer;
    let throttle = kbThrottle;
    let brake = kbBrake;

    if (this.coarse) {
      throttle = Math.max(throttle, 0.92);
      if (this.joyActive) steer = this.joyX;
      if (this.joyY > 0.42) {
        throttle = 0;
        brake = Math.max(brake, Math.min(1, (this.joyY - 0.42) / 0.58));
      }
    } else if (this.joyActive) {
      steer = this.joyX;
      if (this.joyY < -0.25) throttle = Math.max(throttle, Math.min(1, (-this.joyY - 0.25) / 0.75));
      if (this.joyY > 0.45) brake = Math.max(brake, Math.min(1, (this.joyY - 0.45) / 0.55));
    }

    if (this.touchAccel) throttle = 1;
    if (this.touchBrake) brake = 1;
    if (this.touchLeft) steer -= 1;
    if (this.touchRight) steer += 1;

    if (this.invertSteer) steer = -steer;

    this.state.throttle = clamp01(Math.max(throttle, this.state.throttle));
    this.state.brake = clamp01(Math.max(brake, this.state.brake));
    this.state.steer = Math.max(-1, Math.min(1, Math.abs(steer) > 0.05 ? steer : this.state.steer));
    this.state.drift = this.keys.has("ShiftLeft") || this.keys.has("ShiftRight") || this.touchDrift || this.state.drift;
    this.state.nitro = this.keys.has("Space") || this.touchNitro || this.state.nitro;
    this.state.fire = this.keys.has("KeyE") || this.keys.has("KeyF") || this.touchFire || this.state.fire;
    if (this.firePulse > 0) {
      this.state.fire = true;
      this.firePulse -= 1;
    }
    this.state.ultimate = this.keys.has("KeyQ") || this.touchUlt || this.state.ultimate;
    this.seq += 1;
    this.state.seq = this.seq;
    return this.state;
  }

  joystickVisual(): { active: boolean; x: number; y: number } {
    return { active: this.joyActive, x: this.joyX, y: this.joyY };
  }

  private setButton(kind: PointerKind, down: boolean): void {
    if (kind === "accel") this.touchAccel = down;
    if (kind === "brake") this.touchBrake = down;
    if (kind === "drift") this.touchDrift = down;
    if (kind === "nitro") this.touchNitro = down;
    if (kind === "fire") this.touchFire = down;
    if (kind === "ult") this.touchUlt = down;
    if (kind === "left") this.touchLeft = down;
    if (kind === "right") this.touchRight = down;
  }

  private resetTouch(): void {
    this.binds.clear();
    this.joyActive = false;
    this.joyX = 0;
    this.joyY = 0;
    this.touchAccel = false;
    this.touchBrake = false;
    this.touchDrift = false;
    this.touchNitro = false;
    this.touchFire = false;
    this.touchUlt = false;
    this.touchLeft = false;
    this.touchRight = false;
  }

  private pollGamepad(): void {
    if (!this.gamepadEnabled) return;
    const pads = navigator.getGamepads?.() ?? [];
    let pad: Gamepad | null = null;
    if (this.gamepadIndex != null) pad = pads[this.gamepadIndex];
    if (!pad) {
      for (const p of pads) {
        if (p) {
          pad = p;
          this.gamepadIndex = p.index;
          break;
        }
      }
    }
    if (!pad) return;
    const ax = dead(pad.axes[0] ?? 0);
    const throttleTrig = pad.buttons[7]?.value ?? 0;
    const brakeTrig = pad.buttons[6]?.value ?? 0;
    const south = pad.buttons[0]?.pressed;
    const west = pad.buttons[2]?.pressed;
    const east = pad.buttons[1]?.pressed;
    const north = pad.buttons[3]?.pressed;
    if (Math.abs(ax) > 0.05) this.state.steer = ax;
    if (throttleTrig > 0.05) this.state.throttle = throttleTrig;
    if (brakeTrig > 0.05) this.state.brake = brakeTrig;
    if (south) this.state.nitro = true;
    if (west) this.state.drift = true;
    if (east) this.state.fire = true;
    if (north) this.state.ultimate = true;
  }
}

export type ReactPointer = {
  pointerId: number;
  clientX: number;
  clientY: number;
  preventDefault: () => void;
  stopPropagation: () => void;
  currentTarget: EventTarget;
};

function prevent(e: Event): void {
  e.preventDefault();
}

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function dead(v: number, z = 0.18): number {
  return Math.abs(v) < z ? 0 : v;
}

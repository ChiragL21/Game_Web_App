import { useEffect, useRef, useState } from "react";
import { GAME_NAME, GAME_TAGLINE } from "@shared/constants";
import { KART_CATALOG, MAP_CATALOG } from "@shared/catalog";
import { GameApp, type HudState } from "./game/GameApp";
import type { QualityLevel } from "./game/engine/Quality";
import type { ReactPointer } from "./game/input/InputManager";
import { MenuKart } from "./ui/MenuKart";
import { PauseMenu } from "./ui/PauseMenu";

type Screen =
  | "loading"
  | "menu"
  | "play"
  | "maps"
  | "karts"
  | "lobby"
  | "settings"
  | "game"
  | "results";

const emptyHud: HudState = {
  health: 100,
  ammo: 0,
  weapon: null,
  cooldown: 0,
  nitro: 0,
  ult: 0,
  ultName: "shockwave",
  timer: 120,
  rank: 1,
  elims: 0,
  notes: [],
  minimap: { x: 0, z: 0, yaw: 0, others: [] },
  fps: 60,
  ping: 0,
  objective: "Practice drive",
  players: [],
  name: "You",
};

function Wordmark() {
  return (
    <div className="wordmark" aria-label={GAME_NAME}>
      <span className="top">Turbo</span>
      <span className="bot">Rumble</span>
    </div>
  );
}

export function App() {
  const [screen, setScreen] = useState<Screen>("loading");
  const [progress, setProgress] = useState(0);
  const [name, setName] = useState(() => localStorage.getItem("tr-name") || "Racer");
  const [mapId, setMapId] = useState(MAP_CATALOG[0]!.id);
  const [kartId, setKartId] = useState(KART_CATALOG[0]!.id);
  const [quality, setQuality] = useState<QualityLevel>("auto");
  const [invert, setInvert] = useState(false);
  const [hud, setHud] = useState<HudState>(emptyHud);
  const [result, setResult] = useState({ elims: 0, damage: 0, mapId: "" });
  const [paused, setPaused] = useState(false);
  const [pauseTab, setPauseTab] = useState<"gameplay" | "graphics" | "controls">("controls");
  const [gamepad, setGamepad] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<GameApp | null>(null);

  useEffect(() => {
    let n = 0;
    const id = setInterval(() => {
      n += 10;
      setProgress(Math.min(100, n));
      if (n >= 100) {
        clearInterval(id);
        setScreen("menu");
      }
    }, 70);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    localStorage.setItem("tr-name", name);
  }, [name]);

  useEffect(() => {
    if (screen !== "game" || !canvasRef.current) return;
    const app = new GameApp(canvasRef.current, {
      playerId: "local",
      mapId,
      kartId,
      name,
      local: true,
      duration: 120,
    });
    app.setQuality(quality);
    app.setInvertSteer(invert);
    app.onEnd = (stats) => {
      setResult(stats);
      setScreen("results");
    };
    gameRef.current = app;
    setPaused(false);
    app.start();
    const hudTick = setInterval(() => setHud({ ...app.hud }), 100);
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Escape") {
        e.preventDefault();
        setPaused((p) => !p);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      clearInterval(hudTick);
      window.removeEventListener("keydown", onKey);
      app.dispose();
      gameRef.current = null;
    };
  }, [screen, mapId, kartId, name, quality, invert]);

  useEffect(() => {
    if (gameRef.current) gameRef.current.paused = paused;
  }, [paused]);

  useEffect(() => {
    if (gameRef.current) gameRef.current.input.gamepadEnabled = gamepad;
  }, [gamepad]);

  const ptr = (kind: "joy" | "accel" | "brake" | "drift" | "nitro" | "fire" | "ult" | "left" | "right") => ({
    onPointerDown: (e: React.PointerEvent) => gameRef.current?.input.beginPointer(kind, e as unknown as ReactPointer),
    onPointerMove: (e: React.PointerEvent) => gameRef.current?.input.movePointer(e as unknown as ReactPointer),
    onPointerUp: (e: React.PointerEvent) => gameRef.current?.input.endPointer(e as unknown as ReactPointer),
    onPointerCancel: (e: React.PointerEvent) => gameRef.current?.input.endPointer(e as unknown as ReactPointer),
  });

  if (screen === "loading") {
    return (
      <div className="checker loading-wrap">
        <div className="screen">
          <Wordmark />
          <div className="load-bar">
            <i style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>
    );
  }

  if (screen === "menu") {
    return (
      <div className="checker">
        <div className="side-col">
          <div className="xp-chip">
            <b>1</b>
            <span>0 / 100</span>
          </div>
          <div className="wallet">
            <div>🪙 0</div>
            <div>💎 0</div>
          </div>
          <button className="menu-card fat" onClick={() => setScreen("play")}>
            GrandPrix
          </button>
          <button className="menu-card fat" onClick={() => setScreen("karts")}>
            Customize
          </button>
        </div>
        <div className="top-right">
          <button className="chip-btn" onClick={() => setScreen("karts")}>
            Shop
          </button>
          <button className="chip-btn" onClick={() => setScreen("settings")}>
            Free
          </button>
        </div>
        <div className="screen">
          <Wordmark />
          <MenuKart kartId={kartId} />
          <button className="play-btn" onClick={() => setScreen("play")}>
            ▶ PLAY
          </button>
          <div className="subrow">
            <button className="sub-btn" onClick={() => setScreen("lobby")}>
              Create
            </button>
            <button className="sub-btn" onClick={() => setScreen("lobby")}>
              Join
            </button>
          </div>
          <p className="tiny">{GAME_TAGLINE}</p>
        </div>
      </div>
    );
  }

  if (screen === "play" || screen === "maps" || screen === "karts" || screen === "lobby" || screen === "settings" || screen === "results") {
    return (
      <div className="checker">
        <div className="screen">
          {screen === "play" && (
            <>
              <Wordmark />
              <button className="play-btn" onClick={() => setScreen("maps")}>
                Practice
              </button>
              <div className="subrow">
                <button className="sub-btn" onClick={() => setScreen("lobby")}>
                  Lobby
                </button>
                <button className="sub-btn ghost" onClick={() => setScreen("menu")}>
                  Back
                </button>
              </div>
            </>
          )}
          {screen === "maps" && (
            <>
              <h2>Pick a map</h2>
              <div className="grid">
                {MAP_CATALOG.map((m) => (
                  <button key={m.id} className={`card ${mapId === m.id ? "active" : ""}`} onClick={() => setMapId(m.id)}>
                    {m.name}
                    <div className="tiny">{m.blurb}</div>
                  </button>
                ))}
              </div>
              <div className="subrow">
                <button className="sub-btn ghost" onClick={() => setScreen("play")}>
                  Back
                </button>
                <button className="sub-btn" onClick={() => setScreen("karts")}>
                  Next
                </button>
              </div>
            </>
          )}
          {screen === "karts" && (
            <>
              <h2>Choose a kart</h2>
              <MenuKart kartId={kartId} />
              <div className="grid">
                {KART_CATALOG.map((k) => (
                  <button key={k.id} className={`card ${kartId === k.id ? "active" : ""}`} onClick={() => setKartId(k.id)}>
                    <strong>{k.name}</strong>
                    <small>{k.ability.name}: {k.ability.blurb}</small>
                  </button>
                ))}
              </div>
              <p className="ability-note">{KART_CATALOG.find((k) => k.id === kartId)?.ability.blurb}</p>
              <div className="subrow">
                <button className="sub-btn ghost" onClick={() => setScreen("menu")}>
                  Back
                </button>
                <button className="sub-btn" onClick={() => setScreen("lobby")}>
                  Lobby
                </button>
              </div>
            </>
          )}
          {screen === "lobby" && (
            <>
              <h2>Lobby</h2>
              <p className="tiny">
                {MAP_CATALOG.find((m) => m.id === mapId)?.name} · {KART_CATALOG.find((k) => k.id === kartId)?.name}
              </p>
              <input value={name} maxLength={16} onChange={(e) => setName(e.target.value)} />
              <button className="play-btn" onClick={() => setScreen("game")}>
                START
              </button>
              <button className="sub-btn ghost" onClick={() => setScreen("menu")}>
                Back
              </button>
            </>
          )}
          {screen === "settings" && (
            <>
              <h2>Settings</h2>
              <div className="subrow">
                {(["auto", "low", "medium", "high"] as QualityLevel[]).map((q) => (
                  <button key={q} className={`sub-btn ${quality === q ? "" : "ghost"}`} onClick={() => setQuality(q)}>
                    {q}
                  </button>
                ))}
              </div>
              <button className="sub-btn" onClick={() => setInvert(!invert)}>
                Invert steer {invert ? "on" : "off"}
              </button>
              <p className="tiny">WASD drive · Shift drift · Space nitro · E fire</p>
              <button className="sub-btn ghost" onClick={() => setScreen("menu")}>
                Back
              </button>
            </>
          )}
          {screen === "results" && (
            <>
              <Wordmark />
              <h2>Nice rumble!</h2>
              <p className="tiny">
                Elims {result.elims} · Damage {Math.round(result.damage)}
              </p>
              <button className="play-btn" onClick={() => setScreen("lobby")}>
                Again
              </button>
              <button className="sub-btn ghost" onClick={() => setScreen("menu")}>
                Menu
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  const joy = gameRef.current?.input.joystickVisual() ?? { active: false, x: 0, y: 0 };

  return (
    <div className="canvas-wrap" ref={wrapRef}>
      <canvas ref={canvasRef} />
      <div className="hud">
        <div className="hud-top">
          <div className="pill rank-pill">
            <span className="face">👤</span>
            {ord(hud.rank)} / {Math.max(1, hud.players.length)}
          </div>
          <div className="pill hp-pill">
            <span className="heart">❤</span>
            <div className="hp">
              <i style={{ width: `${hud.health}%` }} />
            </div>
          </div>
          <div className="pill">
            <span className="clock">🕒</span> {fmt(hud.timer)}
          </div>
        </div>
        <div className="board">
          {(hud.players.length ? hud.players : [{ name, elims: hud.elims, you: true }]).map((p) => (
            <div key={p.name} className={p.you ? "you" : ""}>
              <span>{p.name}</span>
              <span>{p.elims}</span>
            </div>
          ))}
        </div>
        <div className="stats">
          FPS: {hud.fps.toFixed(0)}
          <br />
          PING: {hud.ping}
        </div>
        <div className="hud-chips">
          <button className="hud-chip" onClick={() => setPaused(true)}>
            ⚙
          </button>
        </div>
        {hud.notes[0] ? <div className="note">{hud.notes[0]}</div> : null}
      </div>
      <div className="controls">
        <div className="joy" {...ptr("joy")}>
          <div className="knob" style={{ transform: `translate(calc(-50% + ${joy.x * 48}px), calc(-50% + ${joy.y * 48}px))` }} />
        </div>
        <button className="chev left" {...ptr("left")}>
          ◀
        </button>
        <button className="pad left-pad" aria-hidden>
          <span />
        </button>
        <button className="chev right" {...ptr("right")}>
          ▶
        </button>
        <button className="pad right-pad" {...ptr("fire")} aria-label="fire cluster">
          <span />
        </button>
        {hud.weapon ? <div className="ammo-ico">{hud.ammo}</div> : null}
        <button className="abtn accel" {...ptr("accel")}>
          GO
        </button>
        <button className="abtn fire" {...ptr("fire")}>
          FIRE
        </button>
      </div>
      {paused ? (
        <PauseMenu
          tab={pauseTab}
          onTab={setPauseTab}
          invert={invert}
          onInvert={() => {
            setInvert(!invert);
            gameRef.current?.setInvertSteer(!invert);
          }}
          quality={quality}
          onQuality={(q) => {
            setQuality(q);
            gameRef.current?.setQuality(q);
          }}
          gamepad={gamepad}
          onGamepad={() => setGamepad(!gamepad)}
          onQuit={() => setScreen("results")}
          onResume={() => setPaused(false)}
        />
      ) : null}
    </div>
  );
}

function fmt(t: number): string {
  const s = Math.max(0, Math.floor(t));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function ord(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
}

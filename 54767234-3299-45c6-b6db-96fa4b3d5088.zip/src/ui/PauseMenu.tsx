import type { QualityLevel } from "../game/engine/Quality";

type Tab = "gameplay" | "graphics" | "controls";

export function PauseMenu({
  tab,
  onTab,
  invert,
  onInvert,
  quality,
  onQuality,
  gamepad,
  onGamepad,
  onQuit,
  onResume,
}: {
  tab: Tab;
  onTab: (t: Tab) => void;
  invert: boolean;
  onInvert: () => void;
  quality: QualityLevel;
  onQuality: (q: QualityLevel) => void;
  gamepad: boolean;
  onGamepad: () => void;
  onQuit: () => void;
  onResume: () => void;
}) {
  return (
    <div className="pause-scrim" role="dialog" aria-label="Paused">
      <div className="pause-card">
        <div className="pause-tabs">
          {(["gameplay", "graphics", "controls"] as Tab[]).map((t) => (
            <button key={t} className={tab === t ? "on" : ""} onClick={() => onTab(t)}>
              {t[0]!.toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
        {tab === "gameplay" && (
          <div className="pause-body">
            <h2>Gameplay</h2>
            <label className="pause-check">
              <span>Invert steer</span>
              <input type="checkbox" checked={invert} onChange={onInvert} />
            </label>
            <p className="tiny">Press Escape to toggle this menu.</p>
          </div>
        )}
        {tab === "graphics" && (
          <div className="pause-body">
            <h2>Graphics</h2>
            <div className="row">
              {(["auto", "low", "medium", "high"] as QualityLevel[]).map((q) => (
                <button key={q} className={`sub-btn ${quality === q ? "" : "ghost"}`} onClick={() => onQuality(q)}>
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}
        {tab === "controls" && (
          <div className="pause-body">
            <h2>Controls</h2>
            <p className="tiny">Press Escape to toggle menu</p>
            <div className="ctrl-diagram">
              <div className="keys">
                <b>W</b>
                <span>
                  <b>A</b>
                  <b>S</b>
                  <b>D</b>
                </span>
                <em>Move</em>
              </div>
              <div className="keys">
                <b className="wide">Space</b>
                <em>Fire</em>
              </div>
              <div className="keys">
                <b>↑</b>
                <span>
                  <b>←</b>
                  <b>↓</b>
                  <b>→</b>
                </span>
                <em>Move</em>
              </div>
              <div className="pad-ico">
                <span>Turn · Accel · Brake · Fire</span>
              </div>
            </div>
            <label className="pause-check">
              <span>Enable Gamepad Controls</span>
              <input type="checkbox" checked={gamepad} onChange={onGamepad} />
            </label>
          </div>
        )}
        <div className="pause-actions">
          <button className="quit-btn" onClick={onQuit}>
            Quit
          </button>
          <button className="resume-btn" onClick={onResume}>
            Resume
          </button>
        </div>
      </div>
    </div>
  );
}

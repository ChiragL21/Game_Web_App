import { useEffect, useRef } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { KartView } from "../game/kart/KartView";

export function MenuKart({ kartId }: { kartId: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.95;
    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    // Lower reflection strength so the model's own colours read true; materials are not changed.
    scene.environmentIntensity = 0.45;
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 40);
    camera.position.set(2.6, 2.0, 5.2);
    camera.lookAt(0, 0.6, 0);
    const key = new THREE.DirectionalLight(0xffffff, 1.4);
    key.position.set(4, 8, 6);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xc084fc, 1.2);
    rim.position.set(-5, 3, -4);
    scene.add(rim);
    const kart = new KartView(kartId, { pbr: true });
    kart.group.position.set(0, 0, 0);
    scene.add(kart.group);
    const pad = new THREE.Mesh(
      new THREE.CylinderGeometry(2.1, 2.2, 0.12, 48),
      new THREE.MeshStandardMaterial({ color: 0x3b1d7a, roughness: 0.6, metalness: 0.05 }),
    );
    pad.position.y = -0.08;
    scene.add(pad);
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(1.95, 0.05, 12, 64),
      new THREE.MeshBasicMaterial({ color: 0xf0abfc }),
    );
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.0;
    scene.add(ring);

    let raf = 0;
    const resize = () => {
      const w = canvas.clientWidth || 320;
      const h = canvas.clientHeight || 240;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const loop = (t: number) => {
      kart.group.rotation.y = t * 0.00085;
      kart.group.position.y = Math.sin(t * 0.002) * 0.07;
      renderer.render(scene, camera);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      kart.dispose();
      pmrem.dispose();
      renderer.dispose();
    };
  }, [kartId]);

  return <canvas ref={ref} className="menu-kart" />;
}

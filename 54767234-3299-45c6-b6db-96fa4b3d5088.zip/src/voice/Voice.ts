export class VoiceChat {
  supported = typeof RTCPeerConnection !== "undefined" && !!navigator.mediaDevices?.getUserMedia;
  muted = true;
  ptt = true;
  speaking = new Set<string>();
  volumes = new Map<string, number>();
  private stream: MediaStream | null = null;
  private peers = new Map<string, RTCPeerConnection>();
  sendRtc?: (to: string, data: unknown) => void;
  peersIds: string[] = [];

  async enableMic(): Promise<boolean> {
    if (!this.supported) return false;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      this.stream.getAudioTracks().forEach((t) => (t.enabled = !this.ptt));
      this.muted = false;
      return true;
    } catch {
      return false;
    }
  }

  setPtt(down: boolean): void {
    this.stream?.getAudioTracks().forEach((t) => (t.enabled = this.ptt ? down : !this.muted));
  }

  toggleMute(): void {
    this.muted = !this.muted;
    if (!this.ptt) this.stream?.getAudioTracks().forEach((t) => (t.enabled = !this.muted));
  }

  async handleSignal(from: string, data: Record<string, unknown>): Promise<void> {
    let pc = this.peers.get(from);
    if (!pc) pc = await this.ensure(from);
    if (data.sdp && data.type === "offer") {
      await pc.setRemoteDescription(data as unknown as RTCSessionDescriptionInit);
      const ans = await pc.createAnswer();
      await pc.setLocalDescription(ans);
      this.sendRtc?.(from, ans);
    } else if (data.sdp && data.type === "answer") await pc.setRemoteDescription(data as unknown as RTCSessionDescriptionInit);
    else if (data.candidate) await pc.addIceCandidate(data as unknown as RTCIceCandidateInit);
  }

  private async ensure(id: string): Promise<RTCPeerConnection> {
    let pc = this.peers.get(id);
    if (pc) return pc;
    pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
    this.stream?.getTracks().forEach((t) => pc!.addTrack(t, this.stream!));
    pc.onicecandidate = (e) => {
      if (e.candidate) this.sendRtc?.(id, e.candidate.toJSON());
    };
    pc.ontrack = (e) => {
      const a = new Audio();
      a.srcObject = e.streams[0] ?? null;
      a.volume = this.volumes.get(id) ?? 0.8;
      void a.play().catch(() => undefined);
    };
    this.peers.set(id, pc);
    return pc;
  }

  async call(id: string): Promise<void> {
    const pc = await this.ensure(id);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    this.sendRtc?.(id, offer);
  }

  dispose(): void {
    this.stream?.getTracks().forEach((t) => t.stop());
    this.peers.forEach((p) => p.close());
    this.peers.clear();
  }
}

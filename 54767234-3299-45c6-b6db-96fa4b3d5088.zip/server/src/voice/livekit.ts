import { createHmac, randomBytes } from "node:crypto";

export function voiceConfig(): { provider: "livekit" | "mesh"; url?: string } {
  const url = process.env.LIVEKIT_URL;
  if (url && process.env.LIVEKIT_API_KEY && process.env.LIVEKIT_API_SECRET) return { provider: "livekit", url };
  return { provider: "mesh" };
}

/** Short-lived LiveKit JWT. Secrets stay on the server. */
export function mintLiveKitToken(identity: string, room: string, ttlSec = 90): string | null {
  const key = process.env.LIVEKIT_API_KEY;
  const secret = process.env.LIVEKIT_API_SECRET;
  if (!key || !secret) return null;
  const now = Math.floor(Date.now() / 1000);
  const header = b64({ alg: "HS256", typ: "JWT" });
  const payload = b64({
    iss: key,
    sub: identity,
    nbf: now - 5,
    exp: now + ttlSec,
    jti: randomBytes(8).toString("hex"),
    video: { roomJoin: true, room, canPublish: true, canSubscribe: true, canPublishData: true },
  });
  const data = `${header}.${payload}`;
  const sig = createHmac("sha256", secret).update(data).digest("base64url");
  return `${data}.${sig}`;
}

function b64(obj: unknown): string {
  return Buffer.from(JSON.stringify(obj)).toString("base64url");
}

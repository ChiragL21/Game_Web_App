import { randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import { createServer } from "node:http";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { WebSocket, WebSocketServer } from "ws";
import { MODE_CATALOG, type GameModeId } from "../../shared/catalog";
import { MAX_PACKET_BYTES, MAX_PLAYERS, SERVER_PORT, SNAPSHOT_EVERY, TICK_HZ, WS_RATE_LIMIT } from "../../shared/constants";
import type { C2S, MatchResult, RoomSummary, S2C } from "../../shared/protocol";
import { GameWorld } from "../../shared/sim/world";
import { publicProfile, Store, type Profile } from "./db/store";
import { mintLiveKitToken, voiceConfig } from "./voice/livekit";

const store = new Store();
store.load();

const parties = new Map<string, { id: string; leader: string; members: string[] }>();
const presence = new Map<string, { name: string; room?: string; online: boolean }>();
const sockets = new Map<string, Client>();

interface Client {
  ws: WebSocket;
  profile: Profile;
  roomId?: string;
  hits: number[];
  last: number;
}

class GameRoom {
  id: string;
  name: string;
  mapId: string;
  mode: GameModeId;
  hostId: string;
  code: string;
  privateRoom: boolean;
  members = new Map<string, { name: string; kartId: string; bot: boolean }>();
  status: RoomSummary["status"] = "lobby";
  world: GameWorld | null = null;
  loop: ReturnType<typeof setInterval> | null = null;
  lastActive = Date.now();

  constructor(host: Profile, name: string, mapId: string, mode: GameModeId, priv: boolean) {
    this.id = randomBytes(4).toString("hex");
    this.name = name.slice(0, 24) || "Lobby";
    this.mapId = mapId;
    this.mode = MODE_CATALOG.some((m) => m.id === mode) ? mode : "ffa";
    this.hostId = host.id;
    this.code = randomBytes(3).toString("hex");
    this.privateRoom = priv;
    this.members.set(host.id, { name: host.name, kartId: host.kartId, bot: false });
  }

  summary(): RoomSummary {
    return {
      id: this.id,
      name: this.name,
      mapId: this.mapId,
      mode: this.mode,
      hostId: this.hostId,
      players: [...this.members.entries()].map(([id, m]) => ({
        id,
        name: m.name,
        kartId: m.kartId,
        ready: true,
        bot: m.bot,
      })),
      status: this.status,
      maxPlayers: MAX_PLAYERS,
      code: this.privateRoom ? this.code : undefined,
      private: this.privateRoom,
    };
  }

  start(): void {
    if (this.status === "playing") return;
    this.world = new GameWorld({ mapId: this.mapId, mode: this.mode });
    for (const [id, m] of this.members) this.world.addPlayer(id, m.name, m.kartId, m.bot, m.bot ? 0.55 + Math.random() * 0.35 : 0.7);
    this.status = "playing";
    this.broadcast({ type: "matchStart", mapId: this.mapId, mode: this.mode, seed: this.world.seed, tick: 0 });
    let n = 0;
    this.loop = setInterval(() => {
      if (!this.world) return;
      this.world.step();
      n += 1;
      if (n % SNAPSHOT_EVERY === 0) {
        for (const id of this.members.keys()) {
          if (this.members.get(id)?.bot) continue;
          const c = sockets.get(id);
          if (!c) continue;
          send(c.ws, { type: "snapshot", snap: this.world!.snapshot(id) });
        }
      }
      if (this.world.winner || this.world.timeLeft <= 0) this.end();
    }, 1000 / TICK_HZ);
  }

  end(): void {
    if (this.loop) clearInterval(this.loop);
    this.loop = null;
    this.status = "ended";
    const w = this.world;
    if (!w) return;
    const placements = [...w.karts]
      .sort((a, b) => b.elims - a.elims || b.damageDealt - a.damageDealt)
      .map((k) => ({
        id: k.id,
        name: k.name,
        elims: k.elims,
        damage: Math.round(k.damageDealt),
        streak: k.streak,
        bounty: k.bounty,
        alive: k.alive,
      }));
    const mvpId = placements[0]?.id ?? "";
    const result: MatchResult = { placements, mvpId, duration: w.duration - w.timeLeft, mapId: w.map.id };
    this.broadcast({ type: "matchEnd", result });
    const humans = w.karts.filter((k) => !k.isBot);
    for (const k of humans) {
      const win = k.id === mvpId || (typeof w.winner === "string" && w.winner.includes(k.team === 0 ? "0" : "1") && w.winner.startsWith("team"));
      store.grantMatch(k.id, k.elims, k.id === mvpId || win, this.mode === "ffa" || this.mode === "tdm");
    }
    for (let i = 0; i < humans.length; i++) {
      for (let j = i + 1; j < humans.length; j++) store.playedTogether(humans[i]!.id, humans[j]!.id);
    }
  }

  fillBots(n: number): void {
    const names = ["Pulse", "Nix", "Quill", "Juno", "Vex", "Poe", "Rook", "Ada"];
    let added = 0;
    while (this.members.size < MAX_PLAYERS && added < n) {
      const id = `bot-${randomBytes(3).toString("hex")}`;
      this.members.set(id, { name: `AI · ${names[added % names.length]}`, kartId: "volt", bot: true });
      added += 1;
    }
  }

  broadcast(msg: S2C): void {
    for (const id of this.members.keys()) {
      const c = sockets.get(id);
      if (c) send(c.ws, msg);
    }
  }
}

const rooms = new Map<string, GameRoom>();
const mmQueue: { userId: string; mode: GameModeId; mapId: string }[] = [];

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  next();
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, rooms: rooms.size, players: sockets.size, voice: voiceConfig().provider, uptime: process.uptime() });
});

app.post("/api/register", (req, res) => {
  try {
    const { name, password } = req.body ?? {};
    res.json(store.register(String(name ?? ""), String(password ?? "")));
  } catch (e) {
    res.status(400).json({ error: "register failed" });
    void e;
  }
});

app.post("/api/login", (req, res) => {
  try {
    const { name, password } = req.body ?? {};
    res.json(store.login(String(name ?? ""), String(password ?? "")));
  } catch {
    res.status(401).json({ error: "invalid credentials" });
  }
});

app.post("/api/guest", (_req, res) => {
  res.json(store.guest());
});

app.get("/api/me", (req, res) => {
  const u = auth(req.headers.authorization);
  if (!u) return res.status(401).json({ error: "auth" });
  res.json(publicProfile(u));
});

app.get("/api/profile/:id", (req, res) => {
  const p = store.publicOf(req.params.id);
  if (!p) return res.status(404).json({ error: "missing" });
  res.json(p);
});

app.get("/api/leaderboard", (_req, res) => res.json(store.leaderboard()));

app.get("/api/friends", (req, res) => {
  const u = auth(req.headers.authorization);
  if (!u) return res.status(401).json({ error: "auth" });
  res.json({ friends: store.friendsOf(u.id), recent: store.recent(u.id) });
});

app.post("/api/cosmetics/equip", (req, res) => {
  const u = auth(req.headers.authorization);
  if (!u) return res.status(401).json({ error: "auth" });
  try {
    store.equip(u.id, String(req.body?.id ?? ""));
    res.json(publicProfile(store.profile(u.id)!));
  } catch {
    res.status(400).json({ error: "locked" });
  }
});

app.post("/api/voice/token", (req, res) => {
  const u = auth(req.headers.authorization);
  if (!u) return res.status(401).json({ error: "auth" });
  const roomId = String(req.body?.roomId ?? "");
  const room = rooms.get(roomId);
  if (!room || !room.members.has(u.id)) return res.status(403).json({ error: "not in room" });
  const cfg = voiceConfig();
  if (cfg.provider === "livekit") {
    const token = mintLiveKitToken(u.id, `tr-${roomId}`, 90);
    return res.json({ provider: "livekit", url: cfg.url, token, ttl: 90 });
  }
  res.json({ provider: "mesh", ttl: 0 });
});

app.get("/invite/:code", (req, res) => {
  const room = [...rooms.values()].find((r) => r.code === req.params.code);
  if (!room) return res.status(404).send("Invite expired");
  res.redirect(`/?join=${room.id}&code=${room.code}`);
});

const dist = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "dist");
if (existsSync(dist)) app.use(express.static(dist));

const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/ws", maxPayload: MAX_PACKET_BYTES });

wss.on("connection", (ws) => {
  let client: Client | null = null;
  ws.on("message", (raw) => {
    const bytes = Buffer.isBuffer(raw) ? raw.byteLength : Buffer.byteLength(String(raw));
    if (bytes > MAX_PACKET_BYTES) return ws.close();
    let msg: C2S;
    try {
      msg = JSON.parse(String(raw)) as C2S;
    } catch {
      return send(ws, { type: "error", message: "malformed" });
    }
    if (!client) {
      if (msg.type !== "hello" || typeof msg.token !== "string") return send(ws, { type: "error", message: "auth required" });
      const profile = store.userFromToken(msg.token);
      if (!profile) return send(ws, { type: "error", message: "invalid session" });
      const prev = sockets.get(profile.id);
      if (prev && prev.ws !== ws) prev.ws.close();
      client = { ws, profile, hits: [], last: Date.now() };
      sockets.set(profile.id, client);
      presence.set(profile.id, { name: profile.name, online: true, room: prev?.roomId });
      if (prev?.roomId) {
        client.roomId = prev.roomId;
        const room = rooms.get(prev.roomId);
        if (room?.status === "playing") send(ws, { type: "matchStart", mapId: room.mapId, mode: room.mode, seed: room.world?.seed ?? 0, tick: room.world?.tick ?? 0 });
      }
      send(ws, { type: "welcome", playerId: profile.id, rooms: publicRooms(), profile: publicProfile(profile) });
      pushSocial(profile.id);
      return;
    }
    if (!rate(client)) return send(ws, { type: "error", message: "rate" });
    handle(client, msg);
  });
  ws.on("close", () => {
    if (!client) return;
    presence.set(client.profile.id, { name: client.profile.name, online: false, room: client.roomId });
    sockets.delete(client.profile.id);
  });
});

function handle(c: Client, msg: C2S): void {
  try {
    switch (msg.type) {
      case "createRoom": {
        const room = new GameRoom(c.profile, msg.name, msg.mapId, msg.mode as GameModeId, !!msg.privateRoom);
        rooms.set(room.id, room);
        c.roomId = room.id;
        presence.set(c.profile.id, { name: c.profile.name, online: true, room: room.id });
        room.broadcast({ type: "roomUpdate", room: room.summary() });
        break;
      }
      case "joinRoom": {
        const room = msg.code
          ? [...rooms.values()].find((r) => r.code === msg.code)
          : rooms.get(String(msg.roomId ?? ""));
        if (!room) throw new Error("room not found");
        if (room.privateRoom && msg.code !== room.code) throw new Error("invalid invite");
        if (room.members.size >= MAX_PLAYERS) throw new Error("full");
        room.members.set(c.profile.id, { name: c.profile.name, kartId: c.profile.kartId, bot: false });
        c.roomId = room.id;
        room.broadcast({ type: "roomUpdate", room: room.summary() });
        break;
      }
      case "findMatch": {
        mmQueue.push({ userId: c.profile.id, mode: msg.mode as GameModeId, mapId: msg.mapId });
        matchmake();
        break;
      }
      case "leaveRoom":
        leave(c);
        break;
      case "setKart":
        store.setKart(c.profile.id, msg.kartId);
        c.profile.kartId = msg.kartId;
        if (c.roomId) {
          const r = rooms.get(c.roomId);
          const m = r?.members.get(c.profile.id);
          if (m) m.kartId = msg.kartId;
          r?.broadcast({ type: "roomUpdate", room: r.summary() });
        }
        break;
      case "setMode": {
        const r = rooms.get(c.roomId ?? "");
        if (!r || r.hostId !== c.profile.id) throw new Error("host only");
        r.mode = msg.mode as GameModeId;
        r.mapId = msg.mapId;
        r.broadcast({ type: "roomUpdate", room: r.summary() });
        break;
      }
      case "startMatch": {
        const r = rooms.get(c.roomId ?? "");
        if (!r || r.hostId !== c.profile.id) throw new Error("host only");
        r.start();
        break;
      }
      case "rematch": {
        const r = rooms.get(c.roomId ?? "");
        if (!r || r.hostId !== c.profile.id) throw new Error("host only");
        r.status = "lobby";
        r.world = null;
        r.broadcast({ type: "roomUpdate", room: r.summary() });
        break;
      }
      case "fillBots": {
        const r = rooms.get(c.roomId ?? "");
        if (!r || r.hostId !== c.profile.id) throw new Error("host only");
        r.fillBots(Math.max(0, Math.min(8, msg.count | 0)));
        r.broadcast({ type: "roomUpdate", room: r.summary() });
        break;
      }
      case "input": {
        const r = rooms.get(c.roomId ?? "");
        if (!r?.world || r.status !== "playing") return;
        if (!r.members.has(c.profile.id)) return;
        r.world.setInput(c.profile.id, msg);
        break;
      }
      case "chat": {
        const text = QUICK.has(msg.text) ? msg.text : "";
        if (!text) return;
        const r = rooms.get(c.roomId ?? "");
        r?.world?.note("pickup", `${c.profile.name}: ${text}`);
        break;
      }
      case "emote":
        rooms.get(c.roomId ?? "")?.world?.note("pickup", `${c.profile.name} ${msg.id}`);
        break;
      case "friendRequest":
        store.requestFriend(c.profile.id, msg.userId);
        pushSocial(c.profile.id);
        pushSocial(msg.userId);
        break;
      case "friendRespond":
        store.respondFriend(c.profile.id, msg.userId, msg.accept);
        pushSocial(c.profile.id);
        pushSocial(msg.userId);
        break;
      case "friendRemove":
        store.removeFriend(c.profile.id, msg.userId);
        pushSocial(c.profile.id);
        break;
      case "partyCreate": {
        const p = { id: randomBytes(4).toString("hex"), leader: c.profile.id, members: [c.profile.id] };
        parties.set(p.id, p);
        pushSocial(c.profile.id);
        break;
      }
      case "partyInvite": {
        const p = [...parties.values()].find((x) => x.members.includes(c.profile.id) && x.leader === c.profile.id);
        if (!p || p.members.length >= 5) throw new Error("party");
        if (!store.friendsOf(c.profile.id).some((f) => f.id === msg.userId && f.status === "accepted")) throw new Error("friends only");
        p.members.push(msg.userId);
        p.members.forEach(pushSocial);
        break;
      }
      case "partyJoin": {
        const p = parties.get(msg.partyId);
        if (!p || p.members.length >= 5) throw new Error("party");
        if (!p.members.includes(c.profile.id)) p.members.push(c.profile.id);
        p.members.forEach(pushSocial);
        break;
      }
      case "partyLeave": {
        for (const p of parties.values()) {
          p.members = p.members.filter((m) => m !== c.profile.id);
          if (p.leader === c.profile.id) p.leader = p.members[0] ?? "";
          if (!p.members.length) parties.delete(p.id);
          else p.members.forEach(pushSocial);
        }
        pushSocial(c.profile.id);
        break;
      }
      case "rtc": {
        const target = sockets.get(msg.to);
        if (!target) return;
        const r = rooms.get(c.roomId ?? "");
        if (!r?.members.has(msg.to) && !sameParty(c.profile.id, msg.to)) return;
        send(target.ws, { type: "rtc", from: c.profile.id, data: msg.data });
        break;
      }
      case "ping":
        send(c.ws, { type: "pong", t: msg.t });
        break;
      default:
        break;
    }
  } catch (e) {
    send(c.ws, { type: "error", message: e instanceof Error ? e.message : "error" });
  }
}

function matchmake(): void {
  const by = new Map<string, typeof mmQueue>();
  for (const q of mmQueue) {
    const k = `${q.mode}:${q.mapId}`;
    const list = by.get(k) ?? [];
    list.push(q);
    by.set(k, list);
  }
  mmQueue.length = 0;
  for (const [k, list] of by) {
    const leftover: typeof mmQueue = [];
    while (list.length) {
      const batch = list.splice(0, MAX_PLAYERS);
      if (batch.length < 1) continue;
      const host = store.profile(batch[0]!.userId);
      if (!host) continue;
      const [mode, mapId] = k.split(":") as [GameModeId, string];
      const room = new GameRoom(host, "Match", mapId, mode, false);
      rooms.set(room.id, room);
      for (const b of batch) {
        const p = store.profile(b.userId);
        if (!p) continue;
        room.members.set(p.id, { name: p.name, kartId: p.kartId, bot: false });
        const c = sockets.get(p.id);
        if (c) c.roomId = room.id;
      }
      if (room.members.size < 4) room.fillBots(4 - room.members.size);
      room.broadcast({ type: "roomUpdate", room: room.summary() });
      room.start();
    }
    leftover.forEach((x) => mmQueue.push(x));
  }
}

function leave(c: Client): void {
  const r = rooms.get(c.roomId ?? "");
  if (!r) return;
  r.members.delete(c.profile.id);
  c.roomId = undefined;
  if (r.hostId === c.profile.id) r.hostId = [...r.members.keys()].find((id) => !r.members.get(id)?.bot) ?? r.hostId;
  if (![...r.members.values()].some((m) => !m.bot)) {
    if (r.loop) clearInterval(r.loop);
    rooms.delete(r.id);
  } else r.broadcast({ type: "roomUpdate", room: r.summary() });
  send(c.ws, { type: "roomUpdate", room: null });
}

function publicRooms(): RoomSummary[] {
  return [...rooms.values()].filter((r) => !r.privateRoom && r.status === "lobby").map((r) => r.summary());
}

function pushSocial(id: string): void {
  const c = sockets.get(id);
  if (!c) return;
  const party = [...parties.values()].find((p) => p.members.includes(id)) ?? null;
  send(c.ws, {
    type: "social",
    friends: store.friendsOf(id),
    party,
    presence: Object.fromEntries(presence),
  });
}

function sameParty(a: string, b: string): boolean {
  return [...parties.values()].some((p) => p.members.includes(a) && p.members.includes(b));
}

function rate(c: Client): boolean {
  const now = Date.now();
  c.hits = c.hits.filter((t) => now - t < 1000);
  c.hits.push(now);
  return c.hits.length <= WS_RATE_LIMIT;
}

function send(ws: WebSocket, msg: S2C): void {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}

function auth(header?: string): Profile | null {
  const token = header?.startsWith("Bearer ") ? header.slice(7) : "";
  return token ? store.userFromToken(token) : null;
}

const QUICK = new Set(["Nice one!", "Incoming!", "Need backup!", "GG", "On my way!", "Thanks!"]);

validateEnv();
server.listen(SERVER_PORT, () => {
  console.log(`Turbo Rumble server :${SERVER_PORT} voice=${voiceConfig().provider}`);
});

function validateEnv(): void {
  const need = ["PORT", "LIVEKIT_URL", "LIVEKIT_API_KEY", "LIVEKIT_API_SECRET", "SESSION_SECRET"];
  const missing = need.filter((k) => !process.env[k] && k !== "PORT");
  if (missing.length) console.warn("Optional env not set:", missing.join(", "), "(mesh voice fallback, local sessions)");
}

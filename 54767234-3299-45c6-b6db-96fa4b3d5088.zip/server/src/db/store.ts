import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { COSMETICS, RANK_TIERS, tierFor, type RankTier } from "../../../shared/catalog";
import { NAME_MAX_LEN } from "../../../shared/constants";

const dataPath = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "data", "store.json");

export interface Profile {
  id: string;
  name: string;
  pass: string;
  salt: string;
  avatar: string;
  level: number;
  xp: number;
  wins: number;
  matches: number;
  elims: number;
  mmr: number;
  cosmetics: string[];
  equipped: string;
  kartId: string;
  missions: Record<string, number>;
  achievements: string[];
  seasonXp: number;
  createdAt: number;
}

export interface FriendEdge {
  a: string;
  b: string;
  status: "pending" | "accepted";
  from: string;
}

export interface Party {
  id: string;
  leader: string;
  members: string[];
}

interface DbShape {
  profiles: Profile[];
  friends: FriendEdge[];
  sessions: { token: string; userId: string; exp: number }[];
  recently: { a: string; b: string; t: number }[];
}

export class Store {
  private db: DbShape = { profiles: [], friends: [], sessions: [], recently: [] };

  load(): void {
    try {
      this.db = JSON.parse(readFileSync(dataPath, "utf8")) as DbShape;
    } catch {
      mkdirSync(dirname(dataPath), { recursive: true });
      this.save();
    }
  }

  save(): void {
    mkdirSync(dirname(dataPath), { recursive: true });
    writeFileSync(dataPath, JSON.stringify(this.db));
  }

  sanitizeName(name: string): string {
    return name.replace(/[^\w\s\-]/g, "").trim().slice(0, NAME_MAX_LEN) || "Racer";
  }

  register(name: string, password: string): { token: string; profile: Profile } {
    const clean = this.sanitizeName(name);
    if (this.db.profiles.some((p) => p.name.toLowerCase() === clean.toLowerCase())) throw new Error("name taken");
    if (password.length < 4) throw new Error("password too short");
    const salt = randomBytes(16).toString("hex");
    const pass = scryptSync(password, salt, 32).toString("hex");
    const profile: Profile = {
      id: randomBytes(8).toString("hex"),
      name: clean,
      pass,
      salt,
      avatar: "blaze",
      level: 1,
      xp: 0,
      wins: 0,
      matches: 0,
      elims: 0,
      mmr: 1000,
      cosmetics: ["default"],
      equipped: "default",
      kartId: "blaze",
      missions: { daily_play: 0, weekly_elims: 0 },
      achievements: [],
      seasonXp: 0,
      createdAt: Date.now(),
    };
    this.db.profiles.push(profile);
    const token = this.issue(profile.id);
    this.save();
    return { token, profile: publicProfile(profile) as unknown as Profile };
  }

  guest(): { token: string; profile: Profile } {
    return this.register(`Guest${randomBytes(2).toString("hex")}`, randomBytes(8).toString("hex"));
  }

  login(name: string, password: string): { token: string; profile: Profile } {
    const p = this.db.profiles.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (!p) throw new Error("invalid credentials");
    const hash = scryptSync(password, p.salt, 32);
    const ok = timingSafeEqual(hash, Buffer.from(p.pass, "hex"));
    if (!ok) throw new Error("invalid credentials");
    return { token: this.issue(p.id), profile: publicProfile(p) as unknown as Profile };
  }

  issue(userId: string): string {
    const token = randomBytes(24).toString("hex");
    this.db.sessions = this.db.sessions.filter((s) => s.exp > Date.now());
    this.db.sessions.push({ token, userId, exp: Date.now() + 7 * 864e5 });
    this.save();
    return token;
  }

  userFromToken(token: string): Profile | null {
    const s = this.db.sessions.find((x) => x.token === token && x.exp > Date.now());
    if (!s) return null;
    const p = this.db.profiles.find((x) => x.id === s.userId);
    return p ?? null;
  }

  profile(id: string): Profile | undefined {
    return this.db.profiles.find((p) => p.id === id);
  }

  publicOf(id: string): ReturnType<typeof publicProfile> | null {
    const p = this.profile(id);
    return p ? publicProfile(p) : null;
  }

  grantMatch(id: string, elims: number, win: boolean, ranked: boolean): Profile | null {
    const p = this.profile(id);
    if (!p) return null;
    p.matches += 1;
    p.elims += elims;
    if (win) p.wins += 1;
    const xp = 40 + elims * 12 + (win ? 60 : 0);
    p.xp += xp;
    p.seasonXp += xp;
    p.missions.daily_play = (p.missions.daily_play ?? 0) + 1;
    p.missions.weekly_elims = (p.missions.weekly_elims ?? 0) + elims;
    while (p.xp >= p.level * 120) {
      p.xp -= p.level * 120;
      p.level += 1;
      for (const c of COSMETICS) {
        if (c.unlock <= p.level && !p.cosmetics.includes(c.id)) p.cosmetics.push(c.id);
      }
    }
    if (p.wins >= 1) addAch(p, "first-win");
    if (p.elims >= 10) addAch(p, "wreck-10");
    if (p.level >= 5) addAch(p, "level-5");
    if (ranked) p.mmr = Math.max(0, p.mmr + (win ? 22 : -14) + Math.min(8, elims));
    this.save();
    return p;
  }

  friendsOf(id: string): { id: string; name: string; status: string }[] {
    return this.db.friends
      .filter((f) => f.a === id || f.b === id)
      .map((f) => {
        const other = f.a === id ? f.b : f.a;
        const p = this.profile(other);
        return { id: other, name: p?.name ?? "?", status: f.status };
      });
  }

  requestFriend(from: string, to: string): void {
    if (from === to) throw new Error("invalid");
    if (!this.profile(to)) throw new Error("unknown user");
    if (this.db.friends.some((f) => pair(f, from, to))) throw new Error("already listed");
    this.db.friends.push({ a: from, b: to, status: "pending", from });
    this.save();
  }

  respondFriend(me: string, other: string, accept: boolean): void {
    const f = this.db.friends.find((x) => pair(x, me, other) && x.status === "pending" && x.from !== me);
    if (!f) throw new Error("no request");
    if (!accept) this.db.friends = this.db.friends.filter((x) => x !== f);
    else f.status = "accepted";
    this.save();
  }

  removeFriend(me: string, other: string): void {
    this.db.friends = this.db.friends.filter((x) => !pair(x, me, other));
    this.save();
  }

  playedTogether(a: string, b: string): void {
    this.db.recently = this.db.recently.filter((r) => !(pairLike(r.a, r.b, a, b)));
    this.db.recently.unshift({ a, b, t: Date.now() });
    this.db.recently = this.db.recently.slice(0, 80);
    this.save();
  }

  recent(id: string): { id: string; name: string }[] {
    return this.db.recently
      .filter((r) => r.a === id || r.b === id)
      .map((r) => {
        const o = r.a === id ? r.b : r.a;
        return { id: o, name: this.profile(o)?.name ?? "?" };
      });
  }

  leaderboard(): { id: string; name: string; mmr: number; tier: RankTier; wins: number; elims: number }[] {
    return [...this.db.profiles]
      .sort((a, b) => b.mmr - a.mmr)
      .slice(0, 50)
      .map((p) => ({ id: p.id, name: p.name, mmr: p.mmr, tier: tierFor(p.mmr), wins: p.wins, elims: p.elims }));
  }

  equip(id: string, cosmetic: string): void {
    const p = this.profile(id);
    if (!p || !p.cosmetics.includes(cosmetic)) throw new Error("locked");
    p.equipped = cosmetic;
    this.save();
  }

  setKart(id: string, kartId: string): void {
    const p = this.profile(id);
    if (!p) return;
    p.kartId = kartId;
    this.save();
  }
}

function publicProfile(p: Profile) {
  return {
    id: p.id,
    name: p.name,
    avatar: p.avatar,
    level: p.level,
    xp: p.xp,
    wins: p.wins,
    matches: p.matches,
    elims: p.elims,
    winRate: p.matches ? p.wins / p.matches : 0,
    mmr: p.mmr,
    tier: tierFor(p.mmr),
    cosmetics: p.cosmetics,
    equipped: p.equipped,
    kartId: p.kartId,
    missions: p.missions,
    achievements: p.achievements,
    seasonXp: p.seasonXp,
    season: { name: "Season 1 — Spark Circuit", weeks: 8, ends: p.createdAt + 8 * 7 * 864e5 },
    ranks: RANK_TIERS,
  };
}

function addAch(p: Profile, id: string): void {
  if (!p.achievements.includes(id)) p.achievements.push(id);
}

function pair(f: FriendEdge, a: string, b: string): boolean {
  return (f.a === a && f.b === b) || (f.a === b && f.b === a);
}

function pairLike(a: string, b: string, x: string, y: string): boolean {
  return (a === x && b === y) || (a === y && b === x);
}

export function hashInvite(code: string): string {
  return createHash("sha256").update(code).digest("hex").slice(0, 12);
}

void publicProfile;
export { publicProfile };

export interface GameInput {
  seq: number;
  throttle: number;
  brake: number;
  steer: number;
  drift: boolean;
  nitro: boolean;
  fire: boolean;
  ultimate: boolean;
}

export const EMPTY_INPUT: GameInput = {
  seq: 0,
  throttle: 0,
  brake: 0,
  steer: 0,
  drift: false,
  nitro: false,
  fire: false,
  ultimate: false,
};

export function clampInput(raw: Partial<GameInput>, seq: number): GameInput {
  const n = (v: unknown, min: number, max: number) => {
    const x = typeof v === "number" && Number.isFinite(v) ? v : 0;
    return Math.max(min, Math.min(max, x));
  };
  return {
    seq: Number.isFinite(seq) ? seq : 0,
    throttle: n(raw.throttle, 0, 1),
    brake: n(raw.brake, 0, 1),
    steer: n(raw.steer, -1, 1),
    drift: !!raw.drift,
    nitro: !!raw.nitro,
    fire: !!raw.fire,
    ultimate: !!raw.ultimate,
  };
}

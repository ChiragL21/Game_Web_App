export const GAME_NAME = "Turbo Rumble";
export const GAME_TAGLINE = "Drift. Boost. Brawl.";

export const FIXED_DT = 1 / 60;
export const MAX_PHYSICS_STEPS = 5;
export const WORLD_SIZE = 80;
export const TICK_HZ = 60;
export const SNAPSHOT_HZ = 20;
export const SNAPSHOT_EVERY = TICK_HZ / SNAPSHOT_HZ;

export const KART_RADIUS = 0.95;
export const KART_HEIGHT = 0.72;

export const MAX_SPEED = 22;
export const REVERSE_SPEED = 8;
export const ACCEL = 28;
export const REVERSE_ACCEL = 16;
export const BRAKE_DECEL = 38;
export const COAST_DRAG = 4.2;
export const STEER_RATE = 2.35;
export const DRIFT_STEER = 3.1;
export const DRIFT_GRIP = 0.72;
export const NITRO_MAX_SPEED = 32;
export const NITRO_ACCEL = 40;
export const NITRO_DURATION = 1.35;
export const BOOST_PAD_DURATION = 0.7;
export const KNOCKBACK_DECAY = 6.5;
export const CAMERA_FOV = 54;
export const CAMERA_BOOST_FOV = 64;

export const MATCH_SECONDS = 120;
export const MAX_PLAYERS = 10;
export const BOT_COUNT_QUICK = 0;
export const SPAWN_PROTECT = 1.6;
export const DAMAGE_HIT_CAP = 45;
export const DAMAGE_DPS_CAP = 90;
export const MAX_PACKET_BYTES = 24_576;
export const INPUT_HISTORY = 48;

export const SERVER_PORT = 3001;
export const NAME_MAX_LEN = 16;
export const WS_RATE_LIMIT = 64;
export const PLAYER_TIMEOUT_MS = 12_000;
export const ROOM_IDLE_MS = 180_000;

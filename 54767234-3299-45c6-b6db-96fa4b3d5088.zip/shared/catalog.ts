import type { WeaponId } from "./protocol";

export type KartShape = "wedge" | "round" | "bulky" | "sleek";
export type KartTopper = "none" | "ears" | "horns" | "halo" | "antenna" | "crown" | "hat";

export interface KartCatalogItem {
  id: string;
  name: string;
  accent: string;
  body: string;
  trim: string;
  handling: number;
  topSpeed: number;
  armor: number;
  shape: KartShape;
  topper: KartTopper;
  ability: { id: string; name: string; blurb: string };
}

/** Original kart roster. Names, abilities and style direction come from the design sheet. */
export const KART_CATALOG: KartCatalogItem[] = [
  { id: "blaze", name: "Scorch", accent: "#fde047", body: "#dc2626", trim: "#f8fafc", handling: 0.72, topSpeed: 0.8, armor: 0.7, shape: "wedge", topper: "ears", ability: { id: "flame-dash", name: "Flame Dash", blurb: "Burst forward with fire and leave a burning trail" } },
  { id: "frostbite", name: "Glacier", accent: "#67e8f9", body: "#0284c7", trim: "#e0f2fe", handling: 0.86, topSpeed: 0.74, armor: 0.62, shape: "sleek", topper: "antenna", ability: { id: "ice-trail", name: "Ice Trail", blurb: "Create a slippery ice path slowing enemies" } },
  { id: "volt", name: "Voltax", accent: "#38bdf8", body: "#facc15", trim: "#111827", handling: 0.7, topSpeed: 0.92, armor: 0.58, shape: "round", topper: "antenna", ability: { id: "chain-shock", name: "Chain Shock", blurb: "Zap nearby karts in a short radius" } },
  { id: "shadow", name: "Phantom", accent: "#c084fc", body: "#2e1065", trim: "#0f0a1a", handling: 0.78, topSpeed: 0.78, armor: 0.74, shape: "sleek", topper: "ears", ability: { id: "phase-shift", name: "Phase Shift", blurb: "Briefly become intangible and avoid damage" } },
  { id: "titan", name: "Bulwark", accent: "#a3e635", body: "#4d7c0f", trim: "#1c1917", handling: 0.6, topSpeed: 0.7, armor: 0.92, shape: "bulky", topper: "none", ability: { id: "force-shield", name: "Force Shield", blurb: "Activate a strong shield that blocks attacks" } },
  { id: "rocket", name: "Skybolt", accent: "#f97316", body: "#f8fafc", trim: "#dc2626", handling: 0.8, topSpeed: 0.9, armor: 0.56, shape: "wedge", topper: "hat", ability: { id: "rocket-jump", name: "Rocket Jump", blurb: "Leap over obstacles and opponents" } },
  { id: "magneto", name: "Magnetar", accent: "#f0abfc", body: "#be185d", trim: "#fdf2f8", handling: 0.82, topSpeed: 0.76, armor: 0.6, shape: "round", topper: "horns", ability: { id: "pickup-magnet", name: "Pickup Magnet", blurb: "Attract nearby weapon boxes" } },
  { id: "vortex", name: "Twister", accent: "#5eead4", body: "#7c3aed", trim: "#2dd4bf", handling: 0.88, topSpeed: 0.72, armor: 0.6, shape: "round", topper: "halo", ability: { id: "mini-tornado", name: "Mini Tornado", blurb: "Create a small vortex that pulls enemies" } },
  { id: "bouncer", name: "Bouncer", accent: "#fde68a", body: "#2563eb", trim: "#f8fafc", handling: 0.74, topSpeed: 0.74, armor: 0.78, shape: "bulky", topper: "hat", ability: { id: "mega-bounce", name: "Mega Bounce", blurb: "A powerful shockwave that knocks enemies away" } },
  { id: "pixel", name: "Spectra", accent: "#22d3ee", body: "#db2777", trim: "#67e8f9", handling: 0.84, topSpeed: 0.78, armor: 0.6, shape: "wedge", topper: "crown", ability: { id: "decoy-clone", name: "Decoy Clone", blurb: "Spawn a moving hologram to confuse enemies" } },
];

export interface MapCatalogItem {
  id: string;
  name: string;
  blurb: string;
  accent: string;
}

export type GameModeId =
  | "ffa"
  | "tdm"
  | "coin"
  | "survival"
  | "ctf"
  | "race"
  | "koth"
  | "boss"
  | "chaos"
  | "shrink";

export const MODE_CATALOG: { id: GameModeId; name: string; blurb: string }[] = [
  { id: "ffa", name: "Free For All", blurb: "Every kart for themselves" },
  { id: "tdm", name: "Team Deathmatch", blurb: "Two crews, one scoreboard" },
  { id: "coin", name: "Coin Rush", blurb: "Grab orbs, magnet helps" },
  { id: "survival", name: "Survival", blurb: "No respawns. Last kart wins" },
  { id: "ctf", name: "Capture the Flag", blurb: "Steal and score" },
  { id: "race", name: "Race and Battle", blurb: "Three laps, weapons allowed" },
  { id: "koth", name: "King of the Arena", blurb: "Hold the center pad" },
  { id: "boss", name: "Boss Battle", blurb: "Team up against a heavy AI" },
  { id: "chaos", name: "Weapon Chaos", blurb: "Faster boxes, hotter loadouts" },
  { id: "shrink", name: "Shrinking Arena", blurb: "The walls close in" },
];

export const RANK_TIERS = ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Master", "Grandmaster"] as const;
export type RankTier = (typeof RANK_TIERS)[number];

export function tierFor(mmr: number): RankTier {
  if (mmr >= 2200) return "Grandmaster";
  if (mmr >= 1900) return "Master";
  if (mmr >= 1600) return "Diamond";
  if (mmr >= 1400) return "Platinum";
  if (mmr >= 1200) return "Gold";
  if (mmr >= 1000) return "Silver";
  return "Bronze";
}

export const COSMETICS = [
  { id: "default", slot: "skin", name: "Factory", unlock: 0 },
  { id: "sunset", slot: "skin", name: "Sunset Wrap", unlock: 3 },
  { id: "midnight", slot: "skin", name: "Midnight", unlock: 8 },
  { id: "chrome", slot: "wheels", name: "Chrome Discs", unlock: 5 },
  { id: "spike", slot: "wheels", name: "Spike Caps", unlock: 12 },
  { id: "spark", slot: "trail", name: "Spark Trail", unlock: 4 },
  { id: "ribbon", slot: "trail", name: "Ribbon Trail", unlock: 10 },
  { id: "blaze", slot: "engine", name: "Blaze Exhaust", unlock: 6 },
  { id: "horn-brass", slot: "horn", name: "Brass Horn", unlock: 2 },
  { id: "plate-ace", slot: "nameplate", name: "Ace Plate", unlock: 15 },
] as const;

export const QUICK_CHAT = ["Nice one!", "Incoming!", "Need backup!", "GG", "On my way!", "Thanks!"] as const;

export const MAP_CATALOG: MapCatalogItem[] = [
  { id: "tropical-island", name: "Tropical Reef", blurb: "Beaches, lagoon bridge, jungle cut-throughs", accent: "#2dd4bf" },
  { id: "neon-city", name: "Neo Circuit", blurb: "Grid streets, overpass, alley shortcuts", accent: "#e879f9" },
  { id: "desert-canyon", name: "Canyon Drift", blurb: "Mesa ramps and a tight slot canyon", accent: "#fb923c" },
  { id: "frozen-arena", name: "Frostpeak", blurb: "Icy oval, slick lake, snowbank walls", accent: "#7dd3fc" },
  { id: "industrial-zone", name: "Mech Factory", blurb: "Yards, containers, hazard boost lanes", accent: "#fbbf24" },
  { id: "toyland", name: "Toy Kingdom", blurb: "Block city, rainbow ramps, playset loops", accent: "#f472b6" },
];

/** Visual identity per weapon. Gameplay numbers live in sim/weapons.ts. */
export const WEAPON_STYLE: Record<WeaponId, { name: string; color: string; size: number }> = {
  homing: { name: "Homing Rocket", color: "#f87171", size: 0.3 },
  bomb: { name: "Bounce Bomb", color: "#1f2937", size: 0.34 },
  mine: { name: "Land Mine", color: "#facc15", size: 0.26 },
  emp: { name: "EMP Pulse", color: "#60a5fa", size: 0.42 },
  laser: { name: "Laser Cannon", color: "#e879f9", size: 0.18 },
  shield: { name: "Energy Shield", color: "#67e8f9", size: 0.4 },
  nitro: { name: "Nitro Boost", color: "#4ade80", size: 0.24 },
  glove: { name: "Boxing Glove", color: "#ef4444", size: 0.32 },
  tornado: { name: "Tornado Launcher", color: "#7dd3fc", size: 0.36 },
  bounce: { name: "Bouncing Explosive", color: "#fb923c", size: 0.3 },
};

/** Weapon box tiers from the design sheet. */
export const BOX_TIERS = {
  common: { name: "Common", color: "#38bdf8", chance: "High" },
  rare: { name: "Rare", color: "#c084fc", chance: "Medium" },
  golden: { name: "Golden", color: "#fbbf24", chance: "Low" },
} as const;

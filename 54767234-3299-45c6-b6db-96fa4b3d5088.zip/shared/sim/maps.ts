import type { Collider, Mechanism, PickupPoint, RampCollider, SpawnPoint, Waypoint, Zone } from "./types";

export interface CompiledMap {
  id: string;
  name: string;
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  colliders: Collider[];
  ramps: RampCollider[];
  zones: Zone[];
  spawns: SpawnPoint[];
  pickups: PickupPoint[];
  waypoints: Waypoint[];
  mechanisms: Mechanism[];
  events: Array<"meteor" | "tornado" | "lightning" | "water" | "boulders" | "gravity">;
}

function empty(id: string, name: string): CompiledMap {
  return {
    id,
    name,
    bounds: { minX: -40, maxX: 40, minZ: -40, maxZ: 40 },
    colliders: [],
    ramps: [],
    zones: [],
    spawns: [],
    pickups: [],
    waypoints: [],
    mechanisms: [],
    events: [],
  };
}

function ring(m: CompiledMap, inset = 0.3, h = 2.6): void {
  const { minX, maxX, minZ, maxZ } = m.bounds;
  const w = maxX - minX;
  const d = maxZ - minZ;
  obb(m, 0, h / 2, minZ + inset, 0.35, h / 2, w / 2, 0, "wall");
  obb(m, 0, h / 2, maxZ - inset, 0.35, h / 2, w / 2, 0, "wall");
  obb(m, minX + inset, h / 2, 0, d / 2, h / 2, 0.35, Math.PI / 2, "wall");
  obb(m, maxX - inset, h / 2, 0, d / 2, h / 2, 0.35, Math.PI / 2, "wall");
}

function obb(
  m: CompiledMap,
  cx: number,
  cy: number,
  cz: number,
  halfD: number,
  halfH: number,
  halfW: number,
  yaw: number,
  kind: "wall" | "solid" | "hazard" = "solid",
): void {
  m.colliders.push({ type: "obb", cx, cy, cz, halfW, halfH, halfD, yaw, kind });
}

function wall(m: CompiledMap, x: number, z: number, length: number, yaw: number, h = 2.2, thick = 0.7): void {
  obb(m, x, h / 2, z, length / 2, h / 2, thick / 2, yaw, "wall");
}

function ramp(m: CompiledMap, x: number, z: number, w: number, len: number, h: number, yaw: number): void {
  m.ramps.push({ type: "ramp", cx: x, cz: z, halfW: w / 2, halfD: len / 2, yaw, height: h });
}

function circ(m: CompiledMap, x: number, z: number, r: number, h = 3): void {
  m.colliders.push({ type: "circle", x, z, r, minY: 0, maxY: h, kind: "solid" });
}

function loop(m: CompiledMap, r: number): void {
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    m.waypoints.push({ x: Math.sin(a) * r, z: Math.cos(a) * r });
  }
}

function mech(m: CompiledMap, kind: Mechanism["kind"], x: number, z: number, w = 4, d = 4, yaw = 0): void {
  const item: Mechanism = { kind, x, z, w, d, yaw, hp: kind === "destructible" ? 40 : 0, t: 0, on: true };
  if (kind === "rotating" || kind === "platform" || kind === "destructible") {
    item.collider = { type: "obb", cx: x, cy: 1.2, cz: z, halfW: w / 2, halfH: 1.2, halfD: d / 2, yaw, kind: "solid" };
    m.colliders.push(item.collider);
  }
  if (kind === "jump") m.zones.push({ kind: "jump", minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
  if (kind === "conveyor" || kind === "tunnel") {
    m.zones.push({
      kind: kind === "tunnel" ? "boost" : "conveyor",
      minX: x - w / 2,
      maxX: x + w / 2,
      minZ: z - d / 2,
      maxZ: z + d / 2,
      dirX: Math.sin(yaw),
      dirZ: Math.cos(yaw),
    });
  }
  m.mechanisms.push(item);
}

function tropical(): CompiledMap {
  const m = empty("tropical-island", "Tropical Island");
  m.zones.push({ kind: "water", minX: -16, maxX: 16, minZ: -10, maxZ: 10 });
  obb(m, 0, 0.9, 0, 1.6, 0.8, 9, 0);
  ramp(m, -22, -18, 6, 12, 3.2, 0.4);
  ramp(m, 20, 16, 6, 11, 2.8, -2.2);
  obb(m, -8, 1.6, -22, 1.5, 1.6, 5, 0);
  obb(m, 14, 1.4, 24, 2, 1.4, 4, 0);
  wall(m, -28, 0, 22, Math.PI / 2);
  wall(m, 28, 8, 18, Math.PI / 2);
  [
    [-18, -28],
    [-12, 30],
    [24, -22],
    [30, 12],
    [-30, 18],
    [8, -32],
  ].forEach(([x, z]) => circ(m, x, z, 1.1, 3.4));
  ring(m);
  loop(m, 28);
  spawns(m);
  pick(m, [-20, 0], [20, 0], [0, -24], [0, 24], [-12, 18], [16, -16]);
  mech(m, "jump", -22, 8, 5, 5);
  mech(m, "shortcut", 0, 32, 8, 3);
  m.events = ["water", "lightning"];
  return m;
}

function neon(): CompiledMap {
  const m = empty("neon-city", "Neon City");
  m.zones.push({ kind: "boost", minX: -3, maxX: 3, minZ: -30, maxZ: 30 });
  for (const x of [-24, 0, 24]) for (const z of [-24, 24]) obb(m, x, 4, z, 5, 4, 5, 0);
  obb(m, 0, 6, 0, 4, 6, 4, 0);
  ramp(m, -12, 0, 5, 14, 4, Math.PI / 2);
  ramp(m, 12, 0, 5, 14, 4, -Math.PI / 2);
  wall(m, -8, -8, 14, 0.2, 2, 0.5);
  wall(m, 8, 8, 14, 0.2, 2, 0.5);
  obb(m, -32, 2, 0, 8, 2, 2, 0);
  obb(m, 32, 2, 0, 8, 2, 2, 0);
  ring(m);
  for (const x of [-30, -15, 0, 15, 30]) for (const z of [-30, -15, 0, 15, 30]) m.waypoints.push({ x, z });
  spawns(m);
  pick(m, [-16, -16], [16, 16], [-16, 16], [16, -16], [0, 20], [0, -20]);
  mech(m, "platform", 0, -12, 8, 3);
  mech(m, "conveyor", 0, 0, 6, 50, 0);
  m.events = ["lightning", "meteor"];
  return m;
}

function desert(): CompiledMap {
  const m = empty("desert-canyon", "Desert Canyon");
  m.zones.push({ kind: "sand", minX: -12, maxX: 12, minZ: -12, maxZ: 12 });
  obb(m, 0, 4, 0, 8, 4, 8, 0);
  ramp(m, -18, 0, 8, 16, 8, Math.PI / 2);
  ramp(m, 18, 0, 8, 16, 8, -Math.PI / 2);
  wall(m, -10, -28, 30, 0, 6, 3);
  wall(m, 10, 28, 30, 0, 6, 3);
  wall(m, -26, 10, 24, Math.PI / 2, 7, 4);
  wall(m, 26, -12, 22, Math.PI / 2, 7, 4);
  ring(m, 0.3, 3.5);
  loop(m, 32);
  spawns(m);
  pick(m, [-30, 0], [30, 0], [0, -36], [0, 36], [-22, 22], [22, -22]);
  mech(m, "trap", 0, -32, 8, 6);
  mech(m, "jump", 22, 12, 5, 5);
  m.events = ["boulders", "meteor"];
  return m;
}

function frozen(): CompiledMap {
  const m = empty("frozen-arena", "Frozen Arena");
  m.zones.push({ kind: "ice", minX: -22, maxX: 22, minZ: -22, maxZ: 22 });
  circ(m, 0, 0, 3.4, 4.8);
  ramp(m, -26, -8, 7, 14, 3.5, 0.5);
  ramp(m, 26, 8, 7, 14, 3.5, 3.6);
  obb(m, -30, 1.6, 20, 1.5, 1.6, 4, 0);
  obb(m, 28, 1.6, -22, 1.5, 1.6, 4, 0);
  ring(m, 0.2, 2.8);
  loop(m, 30);
  spawns(m);
  pick(m, [-16, 0], [16, 0], [0, -16], [0, 16], [24, 24], [-24, -24]);
  mech(m, "rotating", 16, -16, 10, 2.4);
  m.events = ["tornado", "gravity"];
  return m;
}

function industrial(): CompiledMap {
  const m = empty("industrial-zone", "Industrial Zone");
  m.zones.push({ kind: "boost", minX: 16, maxX: 22, minZ: -28, maxZ: 28 });
  m.zones.push({ kind: "boost", minX: -22, maxX: -16, minZ: -28, maxZ: 28 });
  for (let i = 0; i < 6; i++) {
    const z = -24 + i * 9;
    obb(m, -8, 1.6, z, 1.2, 1.6, 2.7, 0);
    obb(m, 8, 1.6, z + 4, 1.2, 1.6, 2.7, 0);
  }
  obb(m, 0, 3, 0, 5, 3, 5, 0);
  ramp(m, 0, -18, 6, 12, 4, 0);
  wall(m, 0, 32, 28, 0, 4, 1.2);
  ring(m, 0.2, 3);
  for (const x of [-30, 0, 30]) for (const z of [-30, 0, 30]) m.waypoints.push({ x, z });
  spawns(m);
  pick(m, [-19, 0], [19, 12], [0, 20], [-12, -20], [12, -8], [0, -28]);
  mech(m, "destructible", 12, 12, 3, 3);
  mech(m, "destructible", -12, -8, 3, 3);
  mech(m, "tunnel", 19, 0, 6, 20, 0);
  m.events = ["meteor", "boulders"];
  return m;
}

function toyland(): CompiledMap {
  const m = empty("toyland", "Toyland");
  obb(m, -16, 2, -16, 4, 2, 4, 0);
  obb(m, 16, 2.5, -12, 3, 2.5, 3, 0);
  obb(m, -14, 1.5, 18, 3, 1.5, 5, 0);
  obb(m, 18, 2, 18, 3.5, 2, 3.5, 0);
  circ(m, 0, 0, 4, 4);
  ramp(m, -28, 0, 8, 16, 4.5, Math.PI / 2);
  ramp(m, 28, 0, 8, 16, 4.5, -Math.PI / 2);
  ramp(m, 0, -28, 8, 14, 3.8, 0);
  ring(m, 0.2, 2.4);
  loop(m, 26);
  spawns(m);
  pick(m, [-22, 10], [22, -10], [0, 22], [0, -22], [12, 0], [-12, 0]);
  mech(m, "jump", 0, 28, 6, 6);
  mech(m, "rotating", -20, -20, 8, 2);
  m.events = ["gravity", "tornado"];
  return m;
}

function spawns(m: CompiledMap): void {
  const pts: SpawnPoint[] = [
    { x: -34, y: 0, z: -34, yaw: 0.7, team: 0 },
    { x: 34, y: 0, z: -34, yaw: 2.4, team: 0 },
    { x: -34, y: 0, z: 34, yaw: -0.6, team: 1 },
    { x: 34, y: 0, z: 34, yaw: 3.5, team: 1 },
    { x: 0, y: 0, z: -36, yaw: 0, team: 0 },
    { x: 0, y: 0, z: 36, yaw: Math.PI, team: 1 },
    { x: -36, y: 0, z: 0, yaw: Math.PI / 2, team: 0 },
    { x: 36, y: 0, z: 0, yaw: -Math.PI / 2, team: 1 },
    { x: -20, y: 0, z: 0, yaw: Math.PI / 2, team: 0 },
    { x: 20, y: 0, z: 0, yaw: -Math.PI / 2, team: 1 },
  ];
  m.spawns.push(...pts);
}

function pick(m: CompiledMap, ...pts: [number, number][]): void {
  pts.forEach(([x, z]) => m.pickups.push({ x, z }));
}

const FACTORIES: Record<string, () => CompiledMap> = {
  "tropical-island": tropical,
  "neon-city": neon,
  "desert-canyon": desert,
  "frozen-arena": frozen,
  "industrial-zone": industrial,
  toyland,
};

export function compileMap(id: string): CompiledMap {
  return (FACTORIES[id] ?? tropical)();
}

export const MAP_IDS = Object.keys(FACTORIES);

import type { WeaponId } from "../protocol";

export interface WeaponDef {
  id: WeaponId;
  name: string;
  rarity: number;
  ammo: [number, number, number];
  cd: [number, number, number];
  dmg: [number, number, number];
}

export const WEAPONS: WeaponDef[] = [
  { id: "homing", name: "Homing Missile", rarity: 0.12, ammo: [1, 2, 2], cd: [0.8, 0.7, 0.55], dmg: [22, 28, 34] },
  { id: "bomb", name: "Bomb", rarity: 0.12, ammo: [1, 2, 2], cd: [0.7, 0.6, 0.5], dmg: [24, 30, 36] },
  { id: "mine", name: "Land Mine", rarity: 0.11, ammo: [2, 3, 4], cd: [0.4, 0.35, 0.3], dmg: [20, 26, 32] },
  { id: "emp", name: "EMP", rarity: 0.1, ammo: [1, 1, 2], cd: [1.1, 1, 0.85], dmg: [6, 8, 10] },
  { id: "laser", name: "Laser Cannon", rarity: 0.1, ammo: [3, 4, 5], cd: [0.35, 0.28, 0.22], dmg: [14, 18, 22] },
  { id: "shield", name: "Energy Shield", rarity: 0.1, ammo: [1, 1, 1], cd: [0.2, 0.2, 0.2], dmg: [0, 0, 0] },
  { id: "nitro", name: "Nitro Boost", rarity: 0.1, ammo: [1, 2, 2], cd: [0.2, 0.2, 0.2], dmg: [0, 0, 0] },
  { id: "glove", name: "Boxing Glove", rarity: 0.09, ammo: [3, 4, 5], cd: [0.45, 0.38, 0.3], dmg: [16, 20, 26] },
  { id: "tornado", name: "Tornado", rarity: 0.08, ammo: [1, 1, 2], cd: [1, 0.9, 0.75], dmg: [8, 10, 12] },
  { id: "bounce", name: "Bouncing Explosive", rarity: 0.08, ammo: [1, 2, 2], cd: [0.7, 0.6, 0.5], dmg: [18, 24, 30] },
];

export const ULTIMATES = [
  { id: "ghost", name: "Ghost Mode", duration: 2.4, cd: 14 },
  { id: "shockwave", name: "Shockwave", duration: 0.35, cd: 12 },
  { id: "dash", name: "Teleport Dash", duration: 0.2, cd: 11 },
  { id: "magnet", name: "Magnet", duration: 3.2, cd: 13 },
  { id: "overdrive", name: "Overdrive", duration: 3.5, cd: 14 },
  { id: "decoy", name: "Decoy", duration: 4, cd: 12 },
] as const;

export function rollWeapon(gold: boolean, rng: () => number): { id: WeaponId; level: number } {
  const pool = gold ? WEAPONS.filter((w) => w.rarity <= 0.11) : WEAPONS;
  let t = rng();
  let acc = 0;
  const sum = pool.reduce((s, w) => s + w.rarity, 0);
  for (const w of pool) {
    acc += w.rarity / sum;
    if (t <= acc) return { id: w.id, level: gold ? 2 : 1 };
  }
  return { id: "bomb", level: gold ? 2 : 1 };
}

export function weaponDef(id: WeaponId): WeaponDef {
  return WEAPONS.find((w) => w.id === id) ?? WEAPONS[0];
}

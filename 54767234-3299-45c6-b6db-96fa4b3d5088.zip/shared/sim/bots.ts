import { EMPTY_INPUT, type GameInput } from "../input";
import type { KartState } from "./kart";
import type { Waypoint } from "./types";
import type { GameWorld } from "./world";

export function botInput(world: GameWorld, kart: KartState): GameInput {
  const input: GameInput = { ...EMPTY_INPUT, seq: world.tick };
  if (!kart.alive) return input;
  const skill = kart.botSkill;
  const wps = world.map.waypoints;
  if (wps.length) {
    let wp = wps[kart.waypoint % wps.length] as Waypoint;
    if (Math.hypot(wp.x - kart.x, wp.z - kart.z) < 6) kart.waypoint = (kart.waypoint + 1) % wps.length;
    wp = wps[kart.waypoint % wps.length]!;
    let targetX = wp.x;
    let targetZ = wp.z;
    if (world.mode === "coin") {
      const c = world.coins.find((o) => o.live);
      if (c) {
        targetX = c.x;
        targetZ = c.z;
      }
    }
    if (world.mode === "koth") {
      targetX = 0;
      targetZ = 0;
    }
    if (world.mode === "ctf" && world.flag && !kart.carrying) {
      targetX = world.flag.x;
      targetZ = world.flag.z;
    }
    const desired = Math.atan2(targetX - kart.x, targetZ - kart.z);
    let err = desired - kart.yaw;
    while (err > Math.PI) err -= Math.PI * 2;
    while (err < -Math.PI) err += Math.PI * 2;
    input.steer = Math.max(-1, Math.min(1, err * (1.2 + skill)));
    input.throttle = 0.45 + skill * 0.5;
    if (Math.abs(err) > 0.75) {
      input.throttle *= 0.65;
      input.drift = Math.abs(kart.speed) > 8;
    }
  } else input.throttle = 0.6;

  const threat = world.karts.find(
    (r) => r.id !== kart.id && r.alive && Math.hypot(r.x - kart.x, r.z - kart.z) < 9 + skill * 4,
  );
  if (threat && kart.ammo > 0 && Math.random() < 0.08 + skill * 0.1) input.fire = true;
  if (kart.nitroCharge > 0.55 && Math.random() < 0.02 + skill * 0.03) input.nitro = true;
  if (kart.ultCharge >= 1 && threat && Math.random() < 0.04) input.ultimate = true;
  return input;
}

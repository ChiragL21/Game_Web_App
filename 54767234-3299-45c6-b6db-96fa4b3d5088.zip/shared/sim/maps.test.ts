import { describe, expect, it } from "vitest";
import { compileMap, MAP_IDS } from "./maps";

describe("map compile", () => {
  it("builds all six arenas with spawns, pickups, and bounds", () => {
    expect(MAP_IDS.sort()).toEqual(
      ["desert-canyon", "frozen-arena", "industrial-zone", "neon-city", "toyland", "tropical-island"].sort(),
    );
    for (const id of MAP_IDS) {
      const m = compileMap(id);
      expect(m.spawns.length).toBeGreaterThanOrEqual(6);
      expect(m.pickups.length).toBeGreaterThanOrEqual(4);
      expect(m.colliders.length).toBeGreaterThan(4);
      expect(m.bounds.maxX - m.bounds.minX).toBeGreaterThanOrEqual(79);
      compileMap(id);
    }
  });
});

import { DAMAGE_HIT_CAP, FIXED_DT, KART_HEIGHT, MAX_PLAYERS, SPAWN_PROTECT } from "../constants";
import type { GameModeId } from "../catalog";
import { clampInput, type GameInput } from "../input";
import type { EventId, Note, NoteKind, PlayerSnap, Snapshot, UltimateId, WeaponId } from "../protocol";
import { botInput } from "./bots";
import { collideCircleObb } from "./collision";
import { applyDamage, createKart, spawnKart, stepKart, tryRespawn, type KartState } from "./kart";
import { compileMap, type CompiledMap } from "./maps";
import { hudFor, modeDuration, teamsFor, tickMode, winnerCheck } from "./modes";
import { rollWeapon, ULTIMATES, weaponDef } from "./weapons";
import type { Mechanism } from "./types";

export interface Proj {
  id: number;
  kind: string;
  owner: string;
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  yaw: number;
  life: number;
  dmg: number;
  bounces: number;
  homing: boolean;
  emp: boolean;
  armed: boolean;
}

export interface BoxPad {
  i: number;
  x: number;
  z: number;
  live: boolean;
  gold: boolean;
  respawn: number;
}

let projId = 1;

export class GameWorld {
  tick = 0;
  timeLeft: number;
  duration: number;
  map: CompiledMap;
  mode: GameModeId;
  karts: KartState[] = [];
  inputs = new Map<string, GameInput>();
  acks = new Map<string, number>();
  projectiles: Proj[] = [];
  pickups: BoxPad[] = [];
  coins: BoxPad[] = [];
  events: { id: EventId; warn: number; t: number; cd: number }[] = [];
  notes: Note[] = [];
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  flag: { x: number; z: number; carrier: string } | null = null;
  winner: string | null = null;
  seed: number;
  rng: () => number;

  constructor(opts: { mapId: string; mode: GameModeId; seed?: number }) {
    this.mode = opts.mode;
    this.seed = opts.seed ?? (Date.now() % 1_000_000);
    this.rng = mulberry(this.seed);
    this.map = compileMap(opts.mapId);
    this.bounds = { ...this.map.bounds };
    this.duration = modeDuration(opts.mode);
    this.timeLeft = this.duration;
    this.map.pickups.forEach((p, i) => this.pickups.push({ i, x: p.x, z: p.z, live: true, gold: this.rng() < 0.12, respawn: 0 }));
    if (opts.mode === "coin") {
      for (let i = 0; i < 10; i++) {
        this.coins.push({ i, x: (this.rng() - 0.5) * 60, z: (this.rng() - 0.5) * 60, live: true, gold: false, respawn: 0 });
      }
    }
    if (opts.mode === "ctf") this.flag = { x: 0, z: 0, carrier: "" };
    if (opts.mode === "koth") this.map.zones.push({ kind: "koth", minX: -8, maxX: 8, minZ: -8, maxZ: 8 });
    for (const ev of this.map.events) this.events.push({ id: ev, warn: 0, t: 0, cd: 18 + this.rng() * 12 });
  }

  addPlayer(id: string, name: string, kartId: string, bot = false, skill = 0.7): KartState {
    if (this.karts.length >= MAX_PLAYERS) throw new Error("room full");
    const team = teamsFor(this.mode) ? ((this.karts.length % 2) as 0 | 1) : 0;
    const ult = ULTIMATES[this.karts.length % ULTIMATES.length]!.id as UltimateId;
    const kart = createKart({
      id,
      name: bot && !name.startsWith("AI") ? `AI · ${name}` : name,
      kartId,
      isBot: bot,
      botSkill: skill,
      team,
      ult,
      maxHealth: bot && this.mode === "boss" && !this.karts.some((k) => k.maxHealth >= 300) ? 360 : 100,
    });
    if (kart.maxHealth > 100) kart.health = kart.maxHealth;
    const spawn = this.map.spawns[this.karts.length % this.map.spawns.length]!;
    spawnKart(kart, spawn, SPAWN_PROTECT);
    this.karts.push(kart);
    return kart;
  }

  setInput(id: string, raw: Partial<GameInput>): void {
    const prev = this.acks.get(id) ?? -1;
    const seq = typeof raw.seq === "number" ? raw.seq : prev + 1;
    if (seq <= prev) return;
    this.inputs.set(id, clampInput(raw, seq));
    this.acks.set(id, seq);
  }

  note(kind: string, text: string): void {
    this.notes.push({ kind: kind as NoteKind, text, t: 2.4 });
    if (this.notes.length > 8) this.notes.shift();
  }

  step(dt = FIXED_DT): void {
    if (this.winner) return;
    this.tick += 1;
    this.timeLeft = Math.max(0, this.timeLeft - dt);
    this.stepMechanisms(dt);
    this.stepEvents(dt);
    for (const kart of this.karts) {
      const input = kart.isBot ? botInput(this, kart) : (this.inputs.get(kart.id) ?? clampInput({}, this.acks.get(kart.id) ?? 0));
      stepKart(kart, input, {
        colliders: this.map.colliders,
        ramps: this.map.ramps,
        zones: this.map.zones,
        karts: this.karts,
        bounds: this.bounds,
      }, dt);
      if (kart.wantFire) this.fire(kart);
      if (kart.wantUlt) this.castUlt(kart);
      this.vacuumPickups(kart, dt);
    }
    this.stepProjectiles(dt);
    this.stepPickups(dt);
    tickMode(this, dt);
    for (const k of this.karts) tryRespawn(k, this.map.spawns, this.mode === "survival");
    this.notes.forEach((n) => (n.t -= dt));
    this.notes = this.notes.filter((n) => n.t > 0);
    this.winner = winnerCheck(this);
  }

  private vacuumPickups(kart: KartState, dt: number): void {
    if (!kart.alive) return;
    const range = kart.magnet > 0 ? 6 : 1.55;
    for (const p of this.pickups) {
      if (!p.live) continue;
      if (Math.hypot(p.x - kart.x, p.z - kart.z) > range) continue;
      p.live = false;
      p.respawn = this.mode === "chaos" ? 1.6 : 6.5;
      this.giveWeapon(kart, p.gold);
    }
    for (const c of this.coins) {
      if (!c.live) continue;
      if (Math.hypot(c.x - kart.x, c.z - kart.z) > range) continue;
      c.live = false;
      c.respawn = 4;
      kart.coins += 1;
    }
    void dt;
  }

  private giveWeapon(kart: KartState, gold: boolean): void {
    const roll = rollWeapon(gold, this.rng);
    if (kart.weapon === roll.id) kart.weaponLevel = Math.min(3, kart.weaponLevel + 1);
    else {
      kart.lastWeapon = kart.weapon;
      kart.weapon = roll.id;
      kart.weaponLevel = roll.level;
    }
    const def = weaponDef(kart.weapon);
    const lv = kart.weaponLevel - 1;
    kart.ammo = def.ammo[lv] ?? 1;
    this.note("pickup", `${kart.name} got ${def.name} L${kart.weaponLevel}${gold ? " ★" : ""}`);
  }

  private fire(kart: KartState): void {
    if (!kart.weapon || kart.ammo <= 0) return;
    const def = weaponDef(kart.weapon);
    const lv = Math.max(0, kart.weaponLevel - 1);
    kart.ammo -= 1;
    kart.cooldown = def.cd[lv] ?? 0.5;
    kart.wantFire = false;
    const fx = Math.sin(kart.yaw);
    const fz = Math.cos(kart.yaw);
    const dmg = def.dmg[lv] ?? 10;
    const comboEmpHoming = kart.lastWeapon === "emp" && kart.weapon === "homing";
    const comboMineEmp = kart.lastWeapon === "emp" && kart.weapon === "mine";
    const comboTornadoBoom = kart.lastWeapon === "bounce" && kart.weapon === "tornado";
    if (comboEmpHoming || comboMineEmp || comboTornadoBoom) this.note("combo", `${kart.name} combo!`);

    if (kart.weapon === "shield") {
      kart.shield = 35 + lv * 12;
      kart.shieldTime = 3.2;
      if (kart.boostTime > 0) kart.shield += 12;
      return;
    }
    if (kart.weapon === "nitro") {
      kart.boostTime = Math.max(kart.boostTime, 1.6 + lv * 0.3);
      return;
    }
    if (kart.weapon === "emp") {
      for (const o of this.karts) {
        if (o.id === kart.id || !o.alive) continue;
        if (Math.hypot(o.x - kart.x, o.z - kart.z) < 12 + lv * 2) {
          o.emp = 2.4 + lv * 0.4;
          applyDamage(o, dmg, 1, kart.id);
        }
      }
      this.projectiles.forEach((p) => {
        if (p.homing && Math.hypot(p.x - kart.x, p.z - kart.z) < 16) p.homing = false;
      });
      return;
    }
    if (kart.weapon === "glove") {
      for (const o of this.karts) {
        if (o.id === kart.id || !o.alive) continue;
        const dx = o.x - kart.x;
        const dz = o.z - kart.z;
        if (Math.hypot(dx, dz) < 2.6 && dx * fx + dz * fz > 0) {
          const dead = applyDamage(o, dmg * (kart.boostTime > 0 ? 1.35 : 1), 1, kart.id);
          o.kbX += fx * 16;
          o.kbZ += fz * 16;
          this.onHit(kart, o, dead);
        }
      }
      return;
    }
    if (kart.weapon === "laser") {
      this.projectiles.push({
        id: projId++,
        kind: "laser",
        owner: kart.id,
        x: kart.x + fx * 1.4,
        y: kart.y,
        z: kart.z + fz * 1.4,
        vx: fx * 48,
        vz: fz * 48,
        yaw: kart.yaw,
        life: 0.28,
        dmg,
        bounces: 0,
        homing: false,
        emp: false,
        armed: true,
      });
      return;
    }
    const kind = kart.weapon === "mine" ? "mine" : kart.weapon === "bomb" ? "bomb" : kart.weapon === "tornado" ? "tornado" : kart.weapon === "bounce" ? "bounce" : "homing";
    this.projectiles.push({
      id: projId++,
      kind,
      owner: kart.id,
      x: kart.x + (kind === "mine" ? -fx * 1.6 : fx * 1.6),
      y: KART_HEIGHT,
      z: kart.z + (kind === "mine" ? -fz * 1.6 : fz * 1.6),
      vx: kind === "mine" ? 0 : fx * (kind === "bomb" ? 14 : 26),
      vz: kind === "mine" ? 0 : fz * (kind === "bomb" ? 14 : 26),
      yaw: kart.yaw,
      life: kind === "mine" ? 12 : kind === "tornado" ? 2.6 : 2.2,
      dmg: dmg * (comboTornadoBoom && kind === "tornado" ? 1.4 : 1),
      bounces: kind === "bounce" ? 4 : 0,
      homing: kind === "homing",
      emp: comboEmpHoming || comboMineEmp,
      armed: kind !== "mine",
    });
    if (kart.ammo <= 0) kart.weapon = null;
  }

  private castUlt(kart: KartState): void {
    const spec = ULTIMATES.find((u) => u.id === kart.ult)!;
    kart.ultCharge = 0;
    kart.ultCd = spec.cd;
    kart.ultTime = spec.duration;
    kart.wantUlt = false;
    if (kart.ult === "ghost") kart.ghost = spec.duration;
    if (kart.ult === "overdrive") {
      kart.overdrive = spec.duration;
      kart.boostTime = spec.duration;
    }
    if (kart.ult === "magnet") kart.magnet = spec.duration;
    if (kart.ult === "decoy") kart.decoy = spec.duration;
    if (kart.ult === "dash") {
      const fx = Math.sin(kart.yaw);
      const fz = Math.cos(kart.yaw);
      kart.x += fx * 12;
      kart.z += fz * 12;
      kart.spawnProtect = Math.max(kart.spawnProtect, 0.35);
    }
    if (kart.ult === "shockwave") {
      for (const o of this.karts) {
        if (o.id === kart.id || !o.alive) continue;
        const d = Math.hypot(o.x - kart.x, o.z - kart.z);
        if (d < 11) {
          const dead = applyDamage(o, 18, 1, kart.id);
          const s = 14 / Math.max(1, d);
          o.kbX += ((o.x - kart.x) / Math.max(d, 0.2)) * s;
          o.kbZ += ((o.z - kart.z) / Math.max(d, 0.2)) * s;
          this.onHit(kart, o, dead);
        }
      }
    }
    this.note("event", `${kart.name} used ${spec.name}`);
  }

  private stepProjectiles(dt: number): void {
    for (const p of this.projectiles) {
      p.life -= dt;
      if (p.kind === "mine" && !p.armed) p.armed = p.life < 11.5;
      if (p.homing) {
        let best: KartState | null = null;
        let bestD = 22;
        for (const k of this.karts) {
          if (!k.alive || k.id === p.owner || k.ghost > 0 || k.spawnProtect > 0) continue;
          const d = Math.hypot(k.x - p.x, k.z - p.z);
          if (d < bestD) {
            bestD = d;
            best = k;
          }
        }
        if (best) {
          const desired = Math.atan2(best.x - p.x, best.z - p.z);
          let err = desired - p.yaw;
          while (err > Math.PI) err -= Math.PI * 2;
          while (err < -Math.PI) err += Math.PI * 2;
          const turn = Math.max(-2.1, Math.min(2.1, err)) * dt;
          p.yaw += turn;
          const spd = Math.hypot(p.vx, p.vz) || 26;
          p.vx = Math.sin(p.yaw) * spd;
          p.vz = Math.cos(p.yaw) * spd;
        }
      }
      if (p.kind === "tornado") {
        for (const k of this.karts) {
          if (!k.alive || k.id === p.owner) continue;
          const d = Math.hypot(k.x - p.x, k.z - p.z);
          if (d < 5) {
            k.kbX += ((p.x - k.x) / Math.max(d, 0.2)) * 10 * dt;
            k.kbZ += ((p.z - k.z) / Math.max(d, 0.2)) * 10 * dt;
            const dead = applyDamage(k, p.dmg * dt, 1, p.owner);
            const owner = this.karts.find((x) => x.id === p.owner);
            if (owner) this.onHit(owner, k, dead);
          }
        }
      } else if (p.kind !== "mine" || p.armed) {
        p.x += p.vx * dt;
        p.z += p.vz * dt;
      }
      if (p.bounces > 0) {
        for (const col of this.map.colliders) {
          if (col.type !== "obb") continue;
          const hit = collideCircleObb(p.x, p.z, 0.3, col.cx, col.cz, col.halfW, col.halfD, col.yaw);
          if (hit) {
            const dot = p.vx * hit.nx + p.vz * hit.nz;
            p.vx -= 2 * dot * hit.nx;
            p.vz -= 2 * dot * hit.nz;
            p.bounces -= 1;
            p.x += hit.nx * 0.4;
            p.z += hit.nz * 0.4;
            break;
          }
        }
      }
      for (const k of this.karts) {
        if (!k.alive || k.id === p.owner || k.ghost > 0) continue;
        const r = p.kind === "mine" ? 1.7 : p.kind === "bomb" ? 2.4 : 1.1;
        if (Math.hypot(k.x - p.x, k.z - p.z) < r && (p.kind !== "mine" || p.armed)) {
          const dead = applyDamage(k, Math.min(DAMAGE_HIT_CAP, p.dmg), 1, p.owner);
          if (p.emp) k.emp = Math.max(k.emp, 2);
          k.kbX += Math.sign(p.vx || k.x - p.x) * 8;
          k.kbZ += Math.sign(p.vz || k.z - p.z) * 8;
          const owner = this.karts.find((x) => x.id === p.owner);
          if (owner) this.onHit(owner, k, dead);
          if (p.kind !== "tornado") p.life = 0;
        }
      }
    }
    this.projectiles = this.projectiles.filter((p) => p.life > 0);
  }

  private onHit(attacker: KartState, victim: KartState, killed: boolean): void {
    attacker.damageDealt += 1;
    attacker.ultCharge = Math.min(1, attacker.ultCharge + 0.08);
    if (!killed) {
      if (Math.hypot(attacker.x - victim.x, attacker.z - victim.z) < 2.2) this.note("nearmiss", "Near miss!");
      return;
    }
    attacker.elims += 1;
    attacker.streak += 1;
    attacker.bounty = Math.min(5, attacker.streak);
    attacker.ultCharge = Math.min(1, attacker.ultCharge + 0.25);
    if (victim.lastKiller === attacker.id) this.note("nemesis", `${attacker.name} is a nemesis`);
    if (attacker.lastKiller === victim.id) this.note("revenge", `${attacker.name} revenge!`);
    if (victim.bounty > 0) this.note("bounty", `${attacker.name} claimed a bounty`);
    if (attacker.streak === 2) this.note("double", "Double down!");
    if (attacker.streak === 3) this.note("triple", "Triple wreck!");
    if (attacker.streak >= 4) this.note("streak", `${attacker.name} streak ${attacker.streak}`);
    this.note("elim", `${attacker.name} wrecked ${victim.name}`);
  }

  private stepPickups(dt: number): void {
    for (const p of this.pickups) {
      if (p.live) continue;
      p.respawn -= dt;
      if (p.respawn <= 0) {
        p.live = true;
        p.gold = this.rng() < (this.mode === "chaos" ? 0.28 : 0.12);
      }
    }
    for (const c of this.coins) {
      if (c.live) continue;
      c.respawn -= dt;
      if (c.respawn <= 0) {
        c.live = true;
        c.x = (this.rng() - 0.5) * 60;
        c.z = (this.rng() - 0.5) * 60;
      }
    }
  }

  private stepMechanisms(dt: number): void {
    for (const m of this.map.mechanisms) {
      m.t += dt;
      if (m.kind === "rotating" && m.collider) {
        m.yaw += dt * 0.6;
        m.collider.yaw = m.yaw;
      }
      if (m.kind === "platform" && m.collider) {
        m.collider.cz = m.z + Math.sin(m.t) * 6;
        m.z = m.collider.cz;
      }
      if (m.kind === "trap") {
        m.on = Math.floor(m.t / 3) % 2 === 0;
        if (!m.on) {
          for (const k of this.karts) {
            if (Math.abs(k.x - m.x) < m.w / 2 && Math.abs(k.z - m.z) < m.d / 2) applyDamage(k, 22 * dt, 1, "");
          }
        }
      }
      if (m.kind === "destructible" && m.collider && m.hp > 0) {
        for (const p of this.projectiles) {
          if (Math.hypot(p.x - m.x, p.z - m.z) < 2.2) {
            m.hp -= 12;
            p.life = 0;
          }
        }
        if (m.hp <= 0) {
          m.on = false;
          this.map.colliders = this.map.colliders.filter((c) => c !== m.collider);
          m.collider = undefined;
        }
      }
    }
  }

  private stepEvents(dt: number): void {
    for (const ev of this.events) {
      if (ev.t > 0) {
        ev.t -= dt;
        this.applyEvent(ev.id, dt);
        continue;
      }
      if (ev.warn > 0) {
        ev.warn -= dt;
        if (ev.warn <= 0) {
          ev.t = 6;
          this.note("event", eventName(ev.id));
        }
        continue;
      }
      ev.cd -= dt;
      if (ev.cd <= 0) {
        ev.warn = 2.2;
        ev.cd = 22 + this.rng() * 10;
        this.note("event", `Incoming: ${eventName(ev.id)}`);
      }
    }
  }

  private applyEvent(id: EventId, dt: number): void {
    if (id === "meteor" && this.tick % 20 === 0) {
      this.projectiles.push({
        id: projId++,
        kind: "meteor",
        owner: "event",
        x: (this.rng() - 0.5) * 50,
        y: 8,
        z: (this.rng() - 0.5) * 50,
        vx: 0,
        vz: 0,
        yaw: 0,
        life: 1.2,
        dmg: 24,
        bounces: 0,
        homing: false,
        emp: false,
        armed: true,
      });
    }
    if (id === "tornado") {
      for (const k of this.karts) {
        k.kbX += Math.sin(this.tick * 0.05) * 8 * dt;
        k.kbZ += Math.cos(this.tick * 0.05) * 8 * dt;
      }
    }
    if (id === "lightning" && this.tick % 45 === 0) {
      const k = this.karts[Math.floor(this.rng() * this.karts.length)];
      if (k?.alive && k.spawnProtect <= 0) applyDamage(k, 16, 1, "event");
    }
    if (id === "water") {
      this.map.zones.forEach((z) => {
        if (z.kind === "water") {
          z.minX -= 2 * dt;
          z.maxX += 2 * dt;
        }
      });
    }
    if (id === "boulders" && this.tick % 30 === 0) {
      this.projectiles.push({
        id: projId++,
        kind: "bounce",
        owner: "event",
        x: -38,
        y: 1,
        z: (this.rng() - 0.5) * 40,
        vx: 18,
        vz: 0,
        yaw: Math.PI / 2,
        life: 4,
        dmg: 20,
        bounces: 2,
        homing: false,
        emp: false,
        armed: true,
      });
    }
    if (id === "gravity") {
      for (const k of this.karts) k.inverted = Math.max(k.inverted, 0.4);
    }
  }

  snapshot(forId: string): Snapshot {
    return {
      tick: this.tick,
      timeLeft: this.timeLeft,
      ackSeq: this.acks.get(forId) ?? 0,
      mapId: this.map.id,
      players: this.karts.map(toSnap),
      projectiles: this.projectiles.map((p) => ({ id: p.id, kind: p.kind, x: p.x, y: p.y, z: p.z, yaw: p.yaw })),
      pickups: this.pickups.map((p) => ({ i: p.i, x: p.x, z: p.z, gold: p.gold, live: p.live })),
      events: this.events.filter((e) => e.warn > 0 || e.t > 0).map((e) => ({ id: e.id, warn: e.warn, t: e.t })),
      mechanisms: this.map.mechanisms.map((m, i) => ({ i, x: m.x, z: m.z, yaw: m.yaw, on: m.on })),
      notes: this.notes.slice(-4),
    };
  }

  hud(): ReturnType<typeof hudFor> {
    return hudFor(this);
  }
}

function toSnap(k: KartState): PlayerSnap {
  return {
    id: k.id,
    name: k.name,
    kartId: k.kartId,
    x: k.x,
    y: k.y,
    z: k.z,
    yaw: k.yaw,
    pitch: k.pitch,
    speed: k.speed,
    vx: k.vx,
    vz: k.vz,
    health: k.health,
    ammo: k.ammo,
    weapon: k.weapon,
    weaponLevel: k.weaponLevel,
    cooldown: k.cooldown,
    nitro: k.nitroCharge,
    boost: k.boostTime,
    shield: k.shield,
    ghost: k.ghost,
    emp: k.emp,
    ult: k.ult,
    ultCharge: k.ultCharge,
    ultTime: k.ultTime,
    ultCd: k.ultCd,
    elims: k.elims,
    damage: k.damageDealt,
    streak: k.streak,
    bounty: k.bounty,
    alive: k.alive,
    protect: k.spawnProtect,
    decoy: k.decoy > 0,
  };
}

function eventName(id: EventId): string {
  return ({
    meteor: "Meteor Shower",
    tornado: "Tornado",
    lightning: "Lightning Storm",
    water: "Rising Water",
    boulders: "Boulder Rush",
    gravity: "Gravity Flip",
  })[id];
}

function mulberry(seed: number): () => number {
  let s = seed | 0;
  return () => {
    s += 0x6d2b79f5;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type { Mechanism, WeaponId };

import type { GameModeId } from "../catalog";
import type { KartState } from "./kart";
import type { CompiledMap } from "./maps";

export interface ModeWorld {
  mode: GameModeId;
  tick: number;
  timeLeft: number;
  duration: number;
  karts: KartState[];
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  map: CompiledMap;
  coins: { live: boolean; x: number; z: number }[];
  flag: { x: number; z: number; carrier: string } | null;
  note: (kind: string, text: string) => void;
}

export function modeDuration(mode: GameModeId): number {
  if (mode === "survival" || mode === "boss") return 180;
  if (mode === "race") return 210;
  if (mode === "ctf" || mode === "koth") return 150;
  return 120;
}

export function teamsFor(mode: GameModeId): boolean {
  return mode === "tdm" || mode === "ctf" || mode === "boss";
}

export function tickMode(world: ModeWorld, dt: number): void {
  const { mode, karts } = world;
  if (mode === "koth") {
    for (const k of karts) {
      if (k.alive && Math.hypot(k.x, k.z) < 8) k.koth += dt;
    }
  }
  if (mode === "shrink") {
    const t = 1 - world.timeLeft / Math.max(1, world.duration);
    const span = 40 - t * 18;
    world.bounds.minX = -span;
    world.bounds.maxX = span;
    world.bounds.minZ = -span;
    world.bounds.maxZ = span;
  }
  if (mode === "coin") {
    for (const k of karts) {
      if (!k.alive || k.magnet <= 0) continue;
      for (const p of world.coins) {
        if (!p.live) continue;
        const dx = k.x - p.x;
        const dz = k.z - p.z;
        const d = Math.hypot(dx, dz) || 1;
        p.x += (dx / d) * 18 * dt;
        p.z += (dz / d) * 18 * dt;
      }
    }
  }
  if (mode === "race") {
    const wps = world.map.waypoints;
    if (wps.length) {
      for (const k of karts) {
        if (!k.alive) continue;
        const wp = wps[k.checkpoint % wps.length];
        if (wp && Math.hypot(k.x - wp.x, k.z - wp.z) < 7) {
          k.checkpoint += 1;
          if (k.checkpoint % wps.length === 0) k.laps += 1;
        }
      }
    }
  }
  if (mode === "ctf" && world.flag) {
    if (world.flag.carrier) {
      const c = karts.find((k) => k.id === world.flag!.carrier);
      if (c?.alive) {
        world.flag.x = c.x;
        world.flag.z = c.z;
        const homeZ = c.team === 0 ? -34 : 34;
        if (Math.abs(c.z - homeZ) < 6 && Math.abs(c.x) < 10) {
          c.captures += 1;
          c.carrying = false;
          world.flag.carrier = "";
          world.flag.x = 0;
          world.flag.z = 0;
          world.note("pickup", `${c.name} captured the flag`);
        }
      } else world.flag.carrier = "";
    } else {
      for (const k of karts) {
        if (k.alive && Math.hypot(k.x - world.flag.x, k.z - world.flag.z) < 1.8) {
          k.carrying = true;
          world.flag.carrier = k.id;
          world.note("pickup", `${k.name} grabbed the flag`);
          break;
        }
      }
    }
  }
}

export function winnerCheck(world: ModeWorld): string | null {
  const humans = world.karts.filter((k) => !k.isBot);
  if (world.mode === "survival") {
    const alive = world.karts.filter((k) => k.alive);
    if (alive.length <= 1 && world.tick > 120) return alive[0]?.id ?? "none";
  }
  if (world.mode === "race") {
    const done = world.karts.find((k) => k.laps >= 3);
    if (done) return done.id;
  }
  if (world.mode === "boss") {
    const boss = world.karts.find((k) => k.isBot && k.maxHealth >= 300);
    if (boss && !boss.alive) return humans[0]?.id ?? "team";
    if (humans.length && humans.every((h) => !h.alive) && world.tick > 60) return boss?.id ?? "boss";
  }
  if (world.timeLeft > 0) return null;
  if (world.mode === "tdm") {
    const a = world.karts.filter((k) => k.team === 0).reduce((s, k) => s + k.elims, 0);
    const b = world.karts.filter((k) => k.team === 1).reduce((s, k) => s + k.elims, 0);
    return a >= b ? "team-0" : "team-1";
  }
  if (world.mode === "ctf") {
    const a = world.karts.filter((k) => k.team === 0).reduce((s, k) => s + k.captures, 0);
    const b = world.karts.filter((k) => k.team === 1).reduce((s, k) => s + k.captures, 0);
    return a >= b ? "team-0" : "team-1";
  }
  if (world.mode === "coin") return [...world.karts].sort((x, y) => y.coins - x.coins)[0]?.id ?? null;
  if (world.mode === "koth") return [...world.karts].sort((x, y) => y.koth - x.koth)[0]?.id ?? null;
  return [...world.karts].sort((x, y) => y.elims - x.elims || y.damageDealt - x.damageDealt)[0]?.id ?? null;
}

export function hudFor(world: ModeWorld): { objective: string; extra: string } {
  const m = world.mode;
  if (m === "coin") return { objective: "Collect coins", extra: "" };
  if (m === "survival") return { objective: "Last kart standing", extra: "" };
  if (m === "ctf") return { objective: "Capture the flag", extra: "" };
  if (m === "race") return { objective: "3 laps + combat", extra: "" };
  if (m === "koth") return { objective: "Hold the crown pad", extra: "" };
  if (m === "boss") return { objective: "Take down the boss", extra: "" };
  if (m === "chaos") return { objective: "Weapon chaos FFA", extra: "" };
  if (m === "shrink") return { objective: "Arena is shrinking", extra: "" };
  if (m === "tdm") return { objective: "Team battle", extra: "" };
  return { objective: "Free for all", extra: "" };
}

import {
  ACCEL,
  BRAKE_DECEL,
  COAST_DRAG,
  DAMAGE_HIT_CAP,
  DRIFT_GRIP,
  DRIFT_STEER,
  FIXED_DT,
  KNOCKBACK_DECAY,
  KART_HEIGHT,
  MAX_SPEED,
  NITRO_ACCEL,
  NITRO_DURATION,
  NITRO_MAX_SPEED,
  REVERSE_ACCEL,
  REVERSE_SPEED,
  SPAWN_PROTECT,
  STEER_RATE,
} from "../constants";
import { KART_CATALOG, type KartCatalogItem } from "../catalog";
import { EMPTY_INPUT, type GameInput } from "../input";
import type { UltimateId, WeaponId } from "../protocol";
import { collideCircles, rampHeight, resolveCollider } from "./collision";
import type { Collider, RampCollider, SpawnPoint, Zone } from "./types";

export interface KartState {
  id: string;
  name: string;
  kartId: string;
  isBot: boolean;
  botSkill: number;
  team: 0 | 1;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  speed: number;
  vx: number;
  vz: number;
  kbX: number;
  kbZ: number;
  drifting: boolean;
  driftDir: number;
  nitroCharge: number;
  boostTime: number;
  health: number;
  maxHealth: number;
  ammo: number;
  weapon: WeaponId | null;
  weaponLevel: number;
  lastWeapon: WeaponId | null;
  cooldown: number;
  shield: number;
  shieldTime: number;
  emp: number;
  ghost: number;
  overdrive: number;
  magnet: number;
  decoy: number;
  spawnProtect: number;
  inverted: number;
  ult: UltimateId;
  ultCharge: number;
  ultTime: number;
  ultCd: number;
  elims: number;
  damageDealt: number;
  deaths: number;
  coins: number;
  captures: number;
  laps: number;
  checkpoint: number;
  koth: number;
  streak: number;
  bounty: number;
  lastKiller: string;
  lastHurtBy: string;
  nemesis: string;
  dpsAcc: number;
  dpsT: number;
  alive: boolean;
  respawn: number;
  waypoint: number;
  fireHeld: boolean;
  ultHeld: boolean;
  wantFire: boolean;
  wantUlt: boolean;
  carrying: boolean;
  cosmetics: string;
}

export function createKart(partial: Partial<KartState> & Pick<KartState, "id" | "name" | "kartId">): KartState {
  return {
    isBot: false,
    botSkill: 0.7,
    team: 0,
    x: 0,
    y: KART_HEIGHT,
    z: 0,
    yaw: 0,
    pitch: 0,
    speed: 0,
    vx: 0,
    vz: 0,
    kbX: 0,
    kbZ: 0,
    drifting: false,
    driftDir: 0,
    nitroCharge: 0.35,
    boostTime: 0,
    health: 100,
    maxHealth: 100,
    ammo: 0,
    weapon: null,
    weaponLevel: 1,
    lastWeapon: null,
    cooldown: 0,
    shield: 0,
    shieldTime: 0,
    emp: 0,
    ghost: 0,
    overdrive: 0,
    magnet: 0,
    decoy: 0,
    spawnProtect: SPAWN_PROTECT,
    inverted: 0,
    ult: "shockwave",
    ultCharge: 0.2,
    ultTime: 0,
    ultCd: 0,
    elims: 0,
    damageDealt: 0,
    deaths: 0,
    coins: 0,
    captures: 0,
    laps: 0,
    checkpoint: 0,
    koth: 0,
    streak: 0,
    bounty: 0,
    lastKiller: "",
    lastHurtBy: "",
    nemesis: "",
    dpsAcc: 0,
    dpsT: 0,
    alive: true,
    respawn: 0,
    waypoint: 0,
    fireHeld: false,
    ultHeld: false,
    wantFire: false,
    wantUlt: false,
    carrying: false,
    cosmetics: "default",
    ...partial,
  };
}

export function spawnKart(kart: KartState, spawn: SpawnPoint, protect = SPAWN_PROTECT): void {
  kart.x = spawn.x;
  kart.y = spawn.y + KART_HEIGHT;
  kart.z = spawn.z;
  kart.yaw = spawn.yaw;
  kart.pitch = 0;
  kart.speed = 0;
  kart.vx = 0;
  kart.vz = 0;
  kart.kbX = 0;
  kart.kbZ = 0;
  kart.boostTime = 0;
  kart.drifting = false;
  kart.spawnProtect = protect;
  kart.carrying = false;
}

export interface WorldQuery {
  colliders: Collider[];
  ramps: RampCollider[];
  zones: Zone[];
  karts: KartState[];
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  extraVx?: number;
  extraVz?: number;
}

function spec(kart: KartState): KartCatalogItem {
  return KART_CATALOG.find((k) => k.id === kart.kartId) ?? KART_CATALOG[0];
}

export function zoneAt(x: number, z: number, zones: Zone[]): Zone | null {
  for (const zone of zones) {
    if (x >= zone.minX && x <= zone.maxX && z >= zone.minZ && z <= zone.maxZ) return zone;
  }
  return null;
}

export function stepKart(kart: KartState, input: GameInput, world: WorldQuery, dt = FIXED_DT): void {
  tickStatus(kart, dt);
  if (!kart.alive) {
    kart.respawn -= dt;
    kart.speed = 0;
    return;
  }

  const kit = spec(kart);
  const handling = 0.75 + kit.handling * 0.4;
  const armor = 0.85 + kit.armor * 0.3;
  const topMul = 0.82 + kit.topSpeed * 0.28;
  const boosting = kart.boostTime > 0 || kart.overdrive > 0;
  const maxSpeed = (boosting ? NITRO_MAX_SPEED : MAX_SPEED) * topMul * (kart.overdrive > 0 ? 1.12 : 1);
  const accel = (boosting ? NITRO_ACCEL : ACCEL) * (0.9 + kit.topSpeed * 0.2);

  if (input.nitro && kart.emp <= 0 && kart.nitroCharge >= 0.28 && kart.boostTime <= 0) {
    kart.nitroCharge = Math.max(0, kart.nitroCharge - 0.28);
    kart.boostTime = NITRO_DURATION;
  }

  const zone = zoneAt(kart.x, kart.z, world.zones);
  let grip = 1;
  if (zone?.kind === "ice") grip = 0.45;
  if (zone?.kind === "sand" || zone?.kind === "water") grip = 0.62;
  if (zone?.kind === "boost" && kart.boostTime < 0.2) kart.boostTime = 0.7;
  if (zone?.kind === "jump") {
    kart.speed = Math.max(kart.speed, 16);
    kart.y = Math.max(kart.y, 3.2);
  }
  if (zone?.kind === "conveyor") {
    kart.speed = Math.min(maxSpeed + 6, kart.speed + 18 * dt);
  }

  let throttle = input.throttle;
  let brake = input.brake;
  let steer = kart.inverted > 0 ? -input.steer : input.steer;
  if (kart.emp > 0) {
    throttle *= 0.7;
    steer *= 0.75;
  }

  if (throttle > 0.05) kart.speed += accel * throttle * dt;
  else if (brake > 0.05) {
    if (kart.speed > 1.2) kart.speed -= BRAKE_DECEL * brake * dt;
    else kart.speed -= REVERSE_ACCEL * brake * dt;
  } else {
    if (kart.speed > 0) kart.speed = Math.max(0, kart.speed - COAST_DRAG * dt);
    else kart.speed = Math.min(0, kart.speed + COAST_DRAG * dt);
  }

  kart.speed = Math.max(-REVERSE_SPEED, Math.min(maxSpeed, kart.speed));
  if (zone?.kind === "water") kart.speed *= 1 - 1.6 * dt;
  if (zone?.kind === "sand") kart.speed *= 1 - 0.7 * dt;

  const canDrift = input.drift && Math.abs(kart.speed) > 8 && Math.abs(steer) > 0.12 && kart.emp <= 0;
  if (canDrift) {
    kart.drifting = true;
    kart.driftDir = Math.sign(steer) || kart.driftDir || 1;
    kart.nitroCharge = Math.min(1, kart.nitroCharge + dt * 0.28);
    grip *= DRIFT_GRIP;
  } else {
    if (kart.drifting && kart.nitroCharge > 0.85) kart.boostTime = Math.max(kart.boostTime, 0.45);
    kart.drifting = false;
    kart.driftDir = 0;
  }

  const steerScale = handling * (0.35 + 0.65 * Math.min(1, Math.abs(kart.speed) / 12));
  const rate = kart.drifting ? DRIFT_STEER : STEER_RATE;
  kart.yaw += steer * rate * steerScale * Math.sign(kart.speed || 1) * dt;
  if (kart.drifting) kart.yaw += kart.driftDir * 0.55 * dt;

  const fx = Math.sin(kart.yaw);
  const fz = Math.cos(kart.yaw);
  const lx = Math.cos(kart.yaw);
  const lz = -Math.sin(kart.yaw);
  const slip = kart.drifting ? 0.42 * kart.driftDir : 0;
  kart.vx = fx * kart.speed + lx * slip * Math.abs(kart.speed) * (1 - grip) + (world.extraVx ?? 0) + (zone?.dirX ?? 0) * 10;
  kart.vz = fz * kart.speed + lz * slip * Math.abs(kart.speed) * (1 - grip) + (world.extraVz ?? 0) + (zone?.dirZ ?? 0) * 10;
  kart.kbX *= Math.max(0, 1 - KNOCKBACK_DECAY * dt);
  kart.kbZ *= Math.max(0, 1 - KNOCKBACK_DECAY * dt);
  kart.x += (kart.vx + kart.kbX) * dt;
  kart.z += (kart.vz + kart.kbZ) * dt;

  let groundY = KART_HEIGHT;
  let rampPitch = 0;
  for (const ramp of world.ramps) {
    const h = rampHeight(kart.x, kart.z, ramp);
    if (h != null && h + KART_HEIGHT > groundY) {
      groundY = h + KART_HEIGHT;
      rampPitch = Math.atan2(ramp.height, ramp.halfD * 2);
    }
  }
  kart.y += (groundY - kart.y) * Math.min(1, 12 * dt);
  kart.pitch += (rampPitch - kart.pitch) * Math.min(1, 10 * dt);

  if (kart.ghost <= 0) {
    for (const col of world.colliders) {
      const hit = resolveCollider(kart.x, kart.z, kart.y, col);
      if (!hit) continue;
      kart.x += hit.nx * hit.overlap;
      kart.z += hit.nz * hit.overlap;
      const into = kart.vx * hit.nx + kart.vz * hit.nz;
      if (into < 0) {
        kart.vx -= into * hit.nx * 1.4;
        kart.vz -= into * hit.nz * 1.4;
        kart.speed *= 0.72;
      }
      if (hit.kind === "hazard") applyDamage(kart, 8 * dt * 8, armor, "");
    }
  }

  const b = world.bounds;
  kart.x = Math.max(b.minX + 1.2, Math.min(b.maxX - 1.2, kart.x));
  kart.z = Math.max(b.minZ + 1.2, Math.min(b.maxZ - 1.2, kart.z));

  if (kart.ghost <= 0) {
    for (const other of world.karts) {
      if (other.id === kart.id || !other.alive || other.ghost > 0) continue;
      const hit = collideCircles(kart.x, kart.z, 0.95, other.x, other.z, 0.95);
      if (!hit) continue;
      kart.x += hit.nx * hit.overlap * 0.5;
      kart.z += hit.nz * hit.overlap * 0.5;
      other.x -= hit.nx * hit.overlap * 0.5;
      other.z -= hit.nz * hit.overlap * 0.5;
      const rel = Math.abs(kart.speed) + Math.abs(other.speed);
      const nitroRam = kart.boostTime > 0 ? 1.8 : 1;
      const knock = Math.min(18, 3 + rel * 0.35) * nitroRam;
      kart.kbX += hit.nx * knock * 0.55;
      kart.kbZ += hit.nz * knock * 0.55;
      other.kbX -= hit.nx * knock * 0.55;
      other.kbZ -= hit.nz * knock * 0.55;
      if (rel > 10 && kart.spawnProtect <= 0 && other.spawnProtect <= 0) {
        const dmg = Math.min(DAMAGE_HIT_CAP, (rel - 8) * 1.4 * nitroRam);
        applyDamage(other, dmg, 0.85 + spec(other).armor * 0.3, kart.id);
        kart.damageDealt += dmg;
      }
    }
  }

  kart.cooldown = Math.max(0, kart.cooldown - dt);
  const fire = input.fire && !kart.fireHeld;
  const ult = input.ultimate && !kart.ultHeld;
  kart.fireHeld = input.fire;
  kart.ultHeld = input.ultimate;
  kart.wantFire = fire && kart.ammo > 0 && kart.cooldown <= 0 && kart.alive && kart.emp <= 0;
  kart.wantUlt = ult && kart.ultCharge >= 1 && kart.ultCd <= 0 && kart.alive;
}

export function tickStatus(kart: KartState, dt: number): void {
  if (kart.boostTime > 0) kart.boostTime -= dt;
  if (kart.shieldTime > 0) kart.shieldTime -= dt;
  else kart.shield = 0;
  if (kart.emp > 0) kart.emp -= dt;
  if (kart.ghost > 0) kart.ghost -= dt;
  if (kart.overdrive > 0) kart.overdrive -= dt;
  if (kart.magnet > 0) kart.magnet -= dt;
  if (kart.decoy > 0) kart.decoy -= dt;
  if (kart.spawnProtect > 0) kart.spawnProtect -= dt;
  if (kart.inverted > 0) kart.inverted -= dt;
  if (kart.ultTime > 0) kart.ultTime -= dt;
  if (kart.ultCd > 0) kart.ultCd -= dt;
  kart.dpsT += dt;
  if (kart.dpsT > 1) {
    kart.dpsAcc = 0;
    kart.dpsT = 0;
  }
}

export function applyDamage(kart: KartState, amount: number, armor = 1, from = ""): boolean {
  if (!kart.alive || kart.spawnProtect > 0 || kart.ghost > 0) return false;
  let dmg = Math.min(DAMAGE_HIT_CAP, amount / armor);
  if (kart.dpsAcc + dmg > 90) dmg = Math.max(0, 90 - kart.dpsAcc);
  kart.dpsAcc += dmg;
  if (kart.shield > 0) {
    const use = Math.min(kart.shield, dmg);
    kart.shield -= use;
    dmg -= use;
  }
  if (dmg <= 0) return false;
  kart.health -= dmg;
  if (from) kart.lastHurtBy = from;
  if (kart.health <= 0) {
    kart.health = 0;
    kart.alive = false;
    kart.respawn = 2.4;
    kart.speed = 0;
    kart.deaths += 1;
    kart.streak = 0;
    kart.lastKiller = from;
    kart.carrying = false;
    return true;
  }
  return false;
}

export function tryRespawn(kart: KartState, spawns: SpawnPoint[], survival = false): void {
  if (kart.alive || kart.respawn > 0 || survival) return;
  const pool = spawns.filter((s) => s.team == null || s.team === kart.team);
  const spawn = pool[Math.floor(Math.random() * pool.length)] ?? spawns[0];
  if (!spawn) return;
  spawnKart(kart, spawn);
  kart.alive = true;
  kart.health = kart.maxHealth;
}

export { EMPTY_INPUT };

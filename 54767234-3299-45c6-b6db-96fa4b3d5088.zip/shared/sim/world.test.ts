import { describe, expect, it } from "vitest";
import { GameWorld } from "./world";

describe("GameWorld", () => {
  it("steps karts and records snapshots", () => {
    const w = new GameWorld({ mapId: "tropical-island", mode: "ffa", seed: 1 });
    w.addPlayer("a", "Ada", "blaze");
    w.addPlayer("b", "Bea", "aqua");
    w.setInput("a", { seq: 1, throttle: 1, steer: 0, brake: 0, drift: false, nitro: false, fire: false, ultimate: false });
    for (let i = 0; i < 90; i++) w.step();
    const snap = w.snapshot("a");
    expect(snap.players).toHaveLength(2);
    expect(snap.tick).toBe(90);
    const ada = w.karts[0]!;
    expect(Math.abs(ada.x) + Math.abs(ada.z)).toBeGreaterThan(2);
  });

  it("rejects stale input sequences", () => {
    const w = new GameWorld({ mapId: "toyland", mode: "ffa", seed: 2 });
    w.addPlayer("a", "Ada", "volt");
    w.setInput("a", { seq: 5, throttle: 1 });
    w.setInput("a", { seq: 4, throttle: 0 });
    expect(w.acks.get("a")).toBe(5);
  });

  it("grants weapons from pickups on the server", () => {
    const w = new GameWorld({ mapId: "neon-city", mode: "chaos", seed: 3 });
    const p = w.addPlayer("a", "Ada", "lime");
    const box = w.pickups[0]!;
    p.x = box.x;
    p.z = box.z;
    w.step();
    expect(p.weapon || p.ammo >= 0).toBeTruthy();
  });
});

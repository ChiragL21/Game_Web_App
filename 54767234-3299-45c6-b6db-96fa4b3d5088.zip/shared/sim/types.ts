export type ColliderKind = "wall" | "solid" | "hazard";

export interface AabbCollider {
  type: "aabb";
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  kind: ColliderKind;
}

export interface ObbCollider {
  type: "obb";
  cx: number;
  cy: number;
  cz: number;
  halfW: number;
  halfH: number;
  halfD: number;
  yaw: number;
  kind: ColliderKind;
  mech?: number;
}

export interface RampCollider {
  type: "ramp";
  cx: number;
  cz: number;
  halfW: number;
  halfD: number;
  yaw: number;
  height: number;
}

export interface CircleCollider {
  type: "circle";
  x: number;
  z: number;
  r: number;
  minY: number;
  maxY: number;
  kind: ColliderKind;
}

export type Collider = AabbCollider | ObbCollider | RampCollider | CircleCollider;

export type ZoneKind = "ice" | "sand" | "boost" | "water" | "jump" | "conveyor" | "koth" | "goalA" | "goalB";

export interface Zone {
  kind: ZoneKind;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  dirX?: number;
  dirZ?: number;
}

export interface SpawnPoint {
  x: number;
  y: number;
  z: number;
  yaw: number;
  team?: 0 | 1;
}

export interface PickupPoint {
  x: number;
  z: number;
}

export interface Waypoint {
  x: number;
  z: number;
}

export type MechKind =
  | "jump"
  | "conveyor"
  | "rotating"
  | "platform"
  | "trap"
  | "tunnel"
  | "destructible"
  | "shortcut";

export interface Mechanism {
  kind: MechKind;
  x: number;
  z: number;
  w: number;
  d: number;
  yaw: number;
  hp: number;
  t: number;
  on: boolean;
  collider?: ObbCollider;
}

import { KART_RADIUS } from "../constants";
import type { Collider, RampCollider } from "./types";

export interface Hit {
  nx: number;
  nz: number;
  overlap: number;
  kind: "wall" | "solid" | "hazard" | "kart";
}

function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}

export function collideCircleAabb(
  px: number,
  pz: number,
  r: number,
  minX: number,
  maxX: number,
  minZ: number,
  maxZ: number,
): Hit | null {
  const cx = clamp(px, minX, maxX);
  const cz = clamp(pz, minZ, maxZ);
  let dx = px - cx;
  let dz = pz - cz;
  const d2 = dx * dx + dz * dz;
  if (d2 > r * r) return null;

  if (d2 < 1e-8) {
    const left = px - minX;
    const right = maxX - px;
    const top = pz - minZ;
    const bottom = maxZ - pz;
    const m = Math.min(left, right, top, bottom);
    if (m === left) return { nx: -1, nz: 0, overlap: r + left, kind: "wall" };
    if (m === right) return { nx: 1, nz: 0, overlap: r + right, kind: "wall" };
    if (m === top) return { nx: 0, nz: -1, overlap: r + top, kind: "wall" };
    return { nx: 0, nz: 1, overlap: r + bottom, kind: "wall" };
  }

  const d = Math.sqrt(d2);
  return { nx: dx / d, nz: dz / d, overlap: r - d, kind: "wall" };
}

export function collideCircleObb(
  px: number,
  pz: number,
  r: number,
  cx: number,
  cz: number,
  halfW: number,
  halfD: number,
  yaw: number,
): Hit | null {
  const dx = px - cx;
  const dz = pz - cz;
  const c = Math.cos(-yaw);
  const s = Math.sin(-yaw);
  const lx = dx * c - dz * s;
  const lz = dx * s + dz * c;
  const closestX = clamp(lx, -halfW, halfW);
  const closestZ = clamp(lz, -halfD, halfD);
  const ox = lx - closestX;
  const oz = lz - closestZ;
  const d2 = ox * ox + oz * oz;
  if (d2 > r * r) return null;

  let nx: number;
  let nz: number;
  let overlap: number;
  if (d2 < 1e-8) {
    const left = lx + halfW;
    const right = halfW - lx;
    const top = lz + halfD;
    const bottom = halfD - lz;
    const m = Math.min(left, right, top, bottom);
    if (m === left) {
      nx = -1;
      nz = 0;
      overlap = r + left;
    } else if (m === right) {
      nx = 1;
      nz = 0;
      overlap = r + right;
    } else if (m === top) {
      nx = 0;
      nz = -1;
      overlap = r + top;
    } else {
      nx = 0;
      nz = 1;
      overlap = r + bottom;
    }
  } else {
    const d = Math.sqrt(d2);
    nx = ox / d;
    nz = oz / d;
    overlap = r - d;
  }
  const c2 = Math.cos(yaw);
  const s2 = Math.sin(yaw);
  return { nx: nx * c2 - nz * s2, nz: nx * s2 + nz * c2, overlap, kind: "wall" };
}

export function collideCircles(
  ax: number,
  az: number,
  ar: number,
  bx: number,
  bz: number,
  br: number,
): Hit | null {
  const dx = ax - bx;
  const dz = az - bz;
  const d2 = dx * dx + dz * dz;
  const min = ar + br;
  if (d2 >= min * min) return null;
  const d = Math.sqrt(d2) || 0.0001;
  return { nx: dx / d, nz: dz / d, overlap: min - d, kind: "kart" };
}

export function rampHeight(px: number, pz: number, ramp: RampCollider): number | null {
  const dx = px - ramp.cx;
  const dz = pz - ramp.cz;
  const c = Math.cos(-ramp.yaw);
  const s = Math.sin(-ramp.yaw);
  const lx = dx * c - dz * s;
  const lz = dx * s + dz * c;
  if (Math.abs(lx) > ramp.halfW || Math.abs(lz) > ramp.halfD) return null;
  const t = (lz + ramp.halfD) / (ramp.halfD * 2);
  return t * ramp.height;
}

export function resolveCollider(px: number, pz: number, py: number, collider: Collider): Hit | null {
  if (collider.type === "ramp") return null;
  const top = collider.type === "circle" ? collider.maxY : collider.type === "aabb" ? collider.maxY : collider.cy + collider.halfH;
  const bot = collider.type === "circle" ? collider.minY : collider.type === "aabb" ? collider.minY : collider.cy - collider.halfH;
  if (py + 0.4 < bot || py > top + 0.2) return null;
  let hit: Hit | null = null;
  if (collider.type === "aabb") hit = collideCircleAabb(px, pz, KART_RADIUS, collider.minX, collider.maxX, collider.minZ, collider.maxZ);
  else if (collider.type === "obb") hit = collideCircleObb(px, pz, KART_RADIUS, collider.cx, collider.cz, collider.halfW, collider.halfD, collider.yaw);
  else hit = collideCircles(px, pz, KART_RADIUS, collider.x, collider.z, collider.r);
  if (hit) hit.kind = collider.kind;
  return hit;
}

export function rayObb(
  ox: number,
  oz: number,
  dx: number,
  dz: number,
  max: number,
  col: Extract<Collider, { type: "obb" }>,
): number | null {
  const len = Math.hypot(dx, dz) || 1;
  dx /= len;
  dz /= len;
  for (let t = 0; t < max; t += 0.6) {
    const hit = collideCircleObb(ox + dx * t, oz + dz * t, 0.2, col.cx, col.cz, col.halfW, col.halfD, col.yaw);
    if (hit) return t;
  }
  return null;
}

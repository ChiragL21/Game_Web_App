import type { GameInput } from "./input";

export type RoomStatus = "lobby" | "playing" | "ended";

export type WeaponId =
  | "homing"
  | "bomb"
  | "mine"
  | "emp"
  | "laser"
  | "shield"
  | "nitro"
  | "glove"
  | "tornado"
  | "bounce";

export type UltimateId = "ghost" | "shockwave" | "dash" | "magnet" | "overdrive" | "decoy";

export type EventId = "meteor" | "tornado" | "lightning" | "water" | "boulders" | "gravity";

export type NoteKind =
  | "elim"
  | "bounty"
  | "revenge"
  | "nemesis"
  | "streak"
  | "double"
  | "triple"
  | "nearmiss"
  | "pickup"
  | "event"
  | "mvp"
  | "combo";

export interface RoomPlayer {
  id: string;
  name: string;
  kartId: string;
  ready: boolean;
  bot?: boolean;
}

export interface RoomSummary {
  id: string;
  name: string;
  mapId: string;
  mode: string;
  hostId: string;
  players: RoomPlayer[];
  status: RoomStatus;
  maxPlayers: number;
  code?: string;
  private?: boolean;
  bots?: number;
}

export interface PlayerSnap {
  id: string;
  name: string;
  kartId: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  speed: number;
  vx: number;
  vz: number;
  health: number;
  ammo: number;
  weapon: WeaponId | null;
  weaponLevel: number;
  cooldown: number;
  nitro: number;
  boost: number;
  shield: number;
  ghost: number;
  emp: number;
  ult: UltimateId;
  ultCharge: number;
  ultTime: number;
  ultCd: number;
  elims: number;
  damage: number;
  streak: number;
  bounty: number;
  alive: boolean;
  protect: number;
  decoy: boolean;
}

export interface ProjSnap {
  id: number;
  kind: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
}

export interface PickupSnap {
  i: number;
  x: number;
  z: number;
  gold: boolean;
  live: boolean;
}

export interface EventSnap {
  id: EventId;
  warn: number;
  t: number;
}

export interface MechSnap {
  i: number;
  x: number;
  z: number;
  yaw: number;
  on: boolean;
}

export interface Note {
  kind: NoteKind;
  text: string;
  t: number;
}

export interface Snapshot {
  tick: number;
  timeLeft: number;
  ackSeq: number;
  mapId: string;
  players: PlayerSnap[];
  projectiles: ProjSnap[];
  pickups: PickupSnap[];
  events: EventSnap[];
  mechanisms: MechSnap[];
  notes: Note[];
}

export interface MatchResult {
  placements: {
    id: string;
    name: string;
    elims: number;
    damage: number;
    streak: number;
    bounty: number;
    alive: boolean;
  }[];
  mvpId: string;
  duration: number;
  mapId: string;
}

export type C2S =
  | { type: "hello"; token: string }
  | { type: "createRoom"; name: string; mapId: string; mode: string; privateRoom?: boolean }
  | { type: "joinRoom"; roomId?: string; code?: string }
  | { type: "findMatch"; mapId: string; mode: string }
  | { type: "leaveRoom" }
  | { type: "setKart"; kartId: string }
  | { type: "setMode"; mode: string; mapId: string }
  | { type: "startMatch" }
  | { type: "rematch" }
  | { type: "fillBots"; count: number }
  | { type: "input"; seq: number; throttle: number; steer: number; brake: number; drift: boolean; nitro: boolean; fire: boolean; ultimate: boolean }
  | { type: "emote"; id: string }
  | { type: "chat"; text: string }
  | { type: "friendRequest"; userId: string }
  | { type: "friendRespond"; userId: string; accept: boolean }
  | { type: "friendRemove"; userId: string }
  | { type: "partyCreate" }
  | { type: "partyInvite"; userId: string }
  | { type: "partyJoin"; partyId: string }
  | { type: "partyLeave" }
  | { type: "rtc"; to: string; data: unknown }
  | { type: "ping"; t: number };

export type S2C =
  | { type: "welcome"; playerId: string; rooms: RoomSummary[]; profile: unknown }
  | { type: "roomList"; rooms: RoomSummary[] }
  | { type: "roomUpdate"; room: RoomSummary | null }
  | { type: "matchStart"; mapId: string; mode: string; seed: number; tick: number }
  | { type: "snapshot"; snap: Snapshot }
  | { type: "matchEnd"; result: MatchResult }
  | { type: "social"; friends: unknown; party: unknown; presence: unknown }
  | { type: "rtc"; from: string; data: unknown }
  | { type: "error"; message: string }
  | { type: "pong"; t: number };

export type NetMessage = C2S | S2C | { type: "ping"; t: number };

export type { GameInput };

# Turbo Rumble — Project Status

**Brand:** Turbo Rumble. Original identity. Not affiliated with Smash Karts or any other commercial kart title.

**GitHub:** https://github.com/ChiragL21/Game_Web_App.git (`origin`). **Push still blocked** (2026-11-07): `gh` is not installed; `git push` returns `remote: Repository not found`. This environment is not logged in as **ChiragL21**. Sign in as that account, then `git push -u origin HEAD`. No force-push. No tokens requested.

**Visual pass (original Turbo Rumble, not Smash Karts assets):** blue checkerboard loading + Turbo/Rumble wordmark; main menu with spinning 3D kart, huge yellow PLAY, Create/Join; in-game heart/rank/timer pills, left scoreboard, right circular joystick, chunky pickup cubes, brighter map palettes. Browser-checked on localhost.

**Process:** Strict priority P0→P14. A box is checked only if the feature is **implemented and tested**. Unchecked items are incomplete or untested. Nothing from Phases 1–3 is omitted from this list.

## Audit

- [x] Repository audited: started as an empty/incomplete git workspace without a bootable UI (`App.tsx` was missing). Scaffolding existed for kart step, collision, six visual arenas, input, renderer, and later-phase stubs. Those stubs are **not** accepted as complete for P1+.

## Priority tracker

| Pri | Layer | Status |
| --- | --- | --- |
| P0 | Playable local foundation | Driveable locally; remaining checklist items below |
| P1 | Server-authoritative multiplayer | Incomplete |
| P2 | Combat weapons | Incomplete |
| P3 | Ultimates | Incomplete |
| P4 | Dynamic arenas + mechanisms | Incomplete |
| P5 | Competitive systems | Incomplete |
| P6 | Game modes | Incomplete |
| P7 | Bots + matchmaking | Incomplete |
| P8 | Social | Incomplete |
| P9 | Profiles / progression | Incomplete |
| P10 | 3D garage / cosmetics | Incomplete |
| P11 | Voice | Incomplete |
| P12 | UI polish | Incomplete |
| P13 | Security review + hardening | Incomplete |
| P14 | Performance, production, E2E | Incomplete |

---

## COMPLETE FEATURE CHECKLIST

### Phase 1 — P0

- [x] Audit documented (this file; keep updated)
- [x] TS + Vite + React + Three.js + Node + WebSocket architecture, modular systems (`tsc --noEmit` pass)
- [x] Arcade kart accel / decel (unit + browser throttle)
- [x] Steering / turning (unit)
- [x] Brake / reverse (unit)
- [x] Drifting (unit)
- [x] Nitro / speed boosts (unit)
- [x] Friction / damping (unit / coast in stepKart)
- [ ] Basic collisions — implemented; wall/kart hits not yet browser-verified
- [ ] Knockback support — implemented in sim; not browser-verified
- [x] Camera follow, smoothing, FOV (browser: chase cam tracked the kart)
- [x] Fixed simulation timestep; physics split from render
- [ ] Mobile virtual joystick — code present; desktop viewport hid controls
- [ ] Mobile accel button — code present; not touch-tested
- [ ] Mobile brake/reverse button — code present; not touch-tested
- [ ] Mobile drift button — code present; not touch-tested
- [ ] Mobile weapon/action button — code present; not touch-tested
- [ ] Multitouch — code present; not device-tested
- [ ] Touch cancel / pointer handling — code present; not device-tested
- [x] Responsive HUD (browser)
- [ ] Portrait and landscape layouts — CSS exists; landscape not device-tested
- [ ] Safe-area support — CSS env() present; not device-tested
- [ ] Mobile viewport; no scroll / unwanted gestures — meta + CSS present; not device-tested
- [x] Desktop keyboard (browser KeyW drive)
- [ ] Gamepad — mapped in InputManager; no pad connected
- [x] Stylised low-poly, unlit/lightweight shaders (browser)
- [x] Instancing (palms/cones in arenas)
- [x] Object pooling (particles)
- [x] Lazy map load/unload (MapManager load/unload; six maps compile in unit tests)
- [ ] Efficient particles — pooled; not profiled
- [ ] Adaptive quality — implemented; not load-tested on weak devices
- [x] No expensive real-time shadows / heavy post
- [x] Map: Tropical Island — compiled + driven in browser
- [x] Map: Neon City — compile unit test (spawns/pickups/bounds); not driven
- [x] Map: Desert Canyon — compile unit test; not driven
- [x] Map: Frozen Arena — compile unit test; not driven
- [x] Map: Industrial Zone — compile unit test; not driven
- [x] Map: Toyland — compile unit test; not driven
- [x] Screen: loading (browser)
- [x] Screen: main menu (browser)
- [x] Screen: play menu (browser)
- [x] Screen: game lobby (browser)
- [x] Screen: map selection (browser)
- [x] Screen: kart selection (browser)
- [ ] Screen: settings — implemented; not clicked this pass
- [x] HUD: health
- [x] HUD: weapon / ammo
- [x] HUD: cooldowns
- [x] HUD: match timer
- [x] HUD: position / rank
- [x] HUD: eliminations
- [x] HUD: minimap
- [x] HUD: team information slot (Solo)
- [ ] Screen: match results — implemented; not reached via timer this pass
- [x] Driveable in browser (P0 gate)

### Phase 2 — P1–P5 (and related)

- [ ] Max 10 players / room
- [ ] WebSocket connect / disconnect
- [ ] Room create / join
- [ ] Membership validation
- [ ] Spawn + player IDs
- [ ] Match start / end
- [ ] State sync
- [ ] Reconnection
- [ ] Room cleanup
- [ ] Matchmaking hooks
- [ ] Server-authoritative movement
- [ ] Server-authoritative collisions
- [ ] Server-authoritative damage / knockback / hits
- [ ] Server-authoritative pickups / elims / scores / results
- [ ] Clients send sequenced inputs only (not trusted poses)
- [ ] Client prediction
- [ ] Server reconciliation
- [ ] Remote interpolation
- [ ] Snapshots ~15–20 Hz
- [ ] Server sim ~60 Hz
- [ ] Jitter handling
- [ ] Timeouts
- [ ] Message validation
- [ ] Packet size limits
- [ ] Rate limits
- [ ] Independent clients (not fake local net)
- [ ] Weapon: Homing Missile (pickup, ammo, CD, activation, dmg, knockback, projectile, lifetime, collision, VFX, SFX, rarity)
- [ ] Weapon: Bomb (same columns)
- [ ] Weapon: Land Mine
- [ ] Weapon: EMP
- [ ] Weapon: Laser Cannon
- [ ] Weapon: Energy Shield
- [ ] Weapon: Nitro Boost
- [ ] Weapon: Boxing Glove
- [ ] Weapon: Tornado
- [ ] Weapon: Bouncing Explosive
- [ ] Normal mystery boxes
- [ ] Rare golden mystery boxes
- [ ] Weapon evolution L1–L3
- [ ] Combo: EMP + Homing
- [ ] Combo: Nitro + Ram
- [ ] Combo: Mine + EMP
- [ ] Combo: Shield + Boost
- [ ] Combo: Tornado + Explosive
- [ ] Ultimate: Ghost Mode (charge, duration, CD, VFX, HUD, audio, server)
- [ ] Ultimate: Shockwave
- [ ] Ultimate: Teleport Dash
- [ ] Ultimate: Magnet
- [ ] Ultimate: Overdrive
- [ ] Ultimate: Decoy
- [ ] Event: Meteor Shower (warning, duration, CD, map config, fair placement, VFX/audio, server)
- [ ] Event: Tornado
- [ ] Event: Lightning Storm
- [ ] Event: Rising Water
- [ ] Event: Boulder Rush
- [ ] Event: Gravity Flip
- [ ] Mechanism: jump pads
- [ ] Mechanism: speed tunnels
- [ ] Mechanism: rotating bridges
- [ ] Mechanism: moving platforms
- [ ] Mechanism: trap doors
- [ ] Mechanism: conveyor belts
- [ ] Mechanism: hidden shortcuts
- [ ] Mechanism: destructible objects (multiplayer-consistent)
- [ ] Bounty
- [ ] Revenge
- [ ] Nemesis
- [ ] Kill streaks
- [ ] Double / triple kills
- [ ] Near-miss
- [ ] MVP
- [ ] Match recap
- [ ] Spawn protection
- [ ] Weapon balance / fair pickups
- [ ] Damage caps
- [ ] Cooldown validation / anti-spam
- [ ] No P2W
- [ ] Homing has counterplay (not unavoidable)
- [ ] Pooled VFX: weapons, trails, explosions, damage, shield, ultimates, events, elims, streaks, pickups, win/lose
- [ ] Mute / volume; autoplay-safe audio
- [ ] Test independent clients 2 / 5 / 10 if feasible
- [ ] Latency 20–250 ms / loss / jitter tests
- [ ] Invalid input tests
- [ ] Metrics: tick, bandwidth, snapshot rate, reconcile error, FPS, memory

### Phase 3 — P6–P14

- [ ] Friends: add / request
- [ ] Friends: accept / reject / remove
- [ ] Friends: online status
- [ ] Friends: recently played
- [ ] Friends: profiles
- [ ] Party: max 5, create, invite, leader, join/leave
- [ ] Party: group matchmaking
- [ ] Party: status, disconnect / reconnect
- [ ] Private rooms: create, codes, invite links
- [ ] Private rooms: settings, map, mode, rematch, leader controls
- [ ] Private rooms: server ACL
- [ ] Voice: WebRTC + SFU; LiveKit evaluated
- [ ] Voice: separate from gameplay WebSocket
- [ ] Voice: all-player + team
- [ ] Voice: PTT, mute, per-player volume, speaking indicators
- [ ] Voice: reconnect, permissions, mic request
- [ ] Voice: short-lived backend tokens; no frontend secrets
- [ ] Voice: mute / block / report
- [ ] Voice: graceful fallback if unsupported
- [ ] Profile: username, avatar, level, XP, wins, elims, matches, win rate, achievements, ranked stats
- [ ] XP / levels (server-validated)
- [ ] Daily / weekly missions
- [ ] Achievements
- [ ] Season ~6–8 weeks + seasonal rewards
- [ ] Leaderboards
- [ ] Ranked MM
- [ ] Tiers: Bronze, Silver, Gold, Platinum, Diamond, Master, Grandmaster
- [ ] 3D garage live preview
- [ ] Cosmetics: colours, skins, wheels, decals, trails, engine FX, horns, victory anims, nameplates
- [ ] Cosmetic unlock via play/season; no combat advantage
- [ ] GameModeManager
- [ ] Mode: FFA
- [ ] Mode: TDM
- [ ] Mode: Coin Rush
- [ ] Mode: Survival
- [ ] Mode: CTF
- [ ] Mode: Race and Battle
- [ ] Mode: King of the Arena
- [ ] Mode: Boss Battle
- [ ] Mode: Weapon Chaos
- [ ] Mode: Shrinking Arena
- [ ] Each mode: rules, objectives, scoring, win, duration, HUD, server validation, results
- [ ] Server bots: drive, pickups, weapons, avoid, objectives, react, difficulty
- [ ] Bots clearly labelled AI; fair stats
- [ ] Matchmaking: player counts, capacity, parties, mode, map, start conditions
- [ ] UI polish: emotes, horns, quick chat, celebrations, rivalries, recap, seasonal events, achievements
- [ ] Tournaments / spectator (if practical)
- [ ] Mobile + desktop UI consistency
- [ ] Security: auth/sessions, room ACL, no impersonation
- [ ] Security: authoritative gameplay; validate inputs/weapons/XP
- [ ] Security: rate limits; anti-replay; no client secrets; sanitize; HTTPS/WSS; env validation; logging
- [ ] Do **not** claim vulnerability-free without independent review
- [ ] Performance notes (FPS, memory, load, bandwidth, tick, battery; low-end devices if unavailable, say so)
- [ ] Production deploy docs (CDN, HTTPS, WS, DB, SFU, secrets, health, monitoring, backups)
- [ ] E2E independent clients
- [ ] Honest remaining blockers

---

## Test log

- `npx vitest run`: 11 passed (collision, kart accel/steer/reverse/drift/nitro, six map compiles, world snapshot/seq/pickups)
- `npx tsc --noEmit`: pass after splitting Vite/Vitest config
- Browser http://localhost:5173/: loading → play → maps → karts → lobby → Start drive. Tropical Island rendered at 60 fps. Keyboard throttle moved the Ember Hatch; chase camera followed onto the lagoon bridge. Timer counted down (2:00 → 1:45).
- Maps other than Tropical Island: compile tests only, not in-session drives.
- Mobile/gamepad: not tested on a phone or pad.

## Known bugs

- Git push to origin fails until ChiragL21 authenticates (`Repository not found` on a private repo from a Guest session).
- Desktop HUD hides on-screen sticks (`mobile-only`); fine for mouse/keyboard, untested on touch.
- Visual arena geometry and `compileMap` physics are parallel datasets; mismatches possible.

## Remaining (do not skip)

All Phase 2–3 checklist boxes above stay incomplete. Next priority after leftover P0 device/collision verification: **P1 server-authoritative multiplayer**.
